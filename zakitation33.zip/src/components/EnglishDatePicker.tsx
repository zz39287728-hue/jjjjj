import React, { useState, useRef, useEffect } from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, X } from 'lucide-react';

interface EnglishDatePickerProps {
  value: string; // Format: YYYY-MM-DD
  onChange: (date: string) => void;
  className?: string;
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;
  id?: string;
}

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const SHORT_MONTHS = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

const DAYS_OF_WEEK = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

export const EnglishDatePicker: React.FC<EnglishDatePickerProps> = ({
  value,
  onChange,
  className = '',
  placeholder = 'YYYY-MM-DD',
  disabled = false,
  id,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const popoverRef = useRef<HTMLDivElement>(null);

  // Parse initial date
  const parseDate = (dateStr: string) => {
    if (!dateStr) return new Date();
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      if (!isNaN(year) && !isNaN(month) && !isNaN(day)) {
        return new Date(year, month, day);
      }
    }
    return new Date();
  };

  const selectedDate = value ? parseDate(value) : null;
  const [viewDate, setViewDate] = useState<Date>(() => selectedDate || new Date());
  const [mode, setMode] = useState<'days' | 'months' | 'years'>('days');

  // Sync view date when value changes or calendar opens
  useEffect(() => {
    if (isOpen && value) {
      setViewDate(parseDate(value));
      setMode('days');
    }
  }, [isOpen, value]);

  // Close on outside click (for desktop anchored popover)
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      if (
        containerRef.current && 
        !containerRef.current.contains(event.target as Node) &&
        popoverRef.current &&
        !popoverRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('touchstart', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, [isOpen]);

  const currentYear = viewDate.getFullYear();
  const currentMonth = viewDate.getMonth();

  const handlePrevMonth = (e: React.MouseEvent) => {
    e.stopPropagation();
    setViewDate(new Date(currentYear, currentMonth - 1, 1));
  };

  const handleNextMonth = (e: React.MouseEvent) => {
    e.stopPropagation();
    setViewDate(new Date(currentYear, currentMonth + 1, 1));
  };

  const handleSelectDay = (day: number) => {
    const y = currentYear;
    const m = String(currentMonth + 1).padStart(2, '0');
    const d = String(day).padStart(2, '0');
    const formatted = `${y}-${m}-${d}`;
    onChange(formatted);
    setIsOpen(false);
  };

  const handleSelectToday = () => {
    const today = new Date();
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, '0');
    const d = String(today.getDate()).padStart(2, '0');
    const formatted = `${y}-${m}-${d}`;
    onChange(formatted);
    setViewDate(today);
    setIsOpen(false);
  };

  // Calendar days calculation
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayIndex = new Date(currentYear, currentMonth, 1).getDay(); // 0 is Sunday
  const daysInPrevMonth = new Date(currentYear, currentMonth, 0).getDate();

  const today = new Date();
  const isToday = (day: number) => {
    return (
      today.getFullYear() === currentYear &&
      today.getMonth() === currentMonth &&
      today.getDate() === day
    );
  };

  const isSelected = (day: number) => {
    if (!selectedDate) return false;
    return (
      selectedDate.getFullYear() === currentYear &&
      selectedDate.getMonth() === currentMonth &&
      selectedDate.getDate() === day
    );
  };

  // Generate year options (range from 2020 to 2035)
  const years = Array.from({ length: 16 }, (_, i) => 2020 + i);

  // Calendar content component
  const CalendarBody = () => (
    <div
      dir="ltr"
      lang="en"
      style={{ fontFamily: 'ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}
      className="select-none text-gray-900 dark:text-gray-100"
    >
      {/* Header Controls */}
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-gray-100 dark:border-gray-700/60">
        {mode === 'days' ? (
          <button
            type="button"
            onClick={handlePrevMonth}
            className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 transition-colors"
            title="Previous month"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        ) : (
          <div className="w-7" />
        )}

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setMode(mode === 'months' ? 'days' : 'months')}
            className={`font-semibold text-sm px-2.5 py-1 rounded-lg transition-colors ${
              mode === 'months' 
                ? 'bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300' 
                : 'hover:bg-gray-100 dark:hover:bg-gray-700'
            }`}
          >
            {MONTH_NAMES[currentMonth]}
          </button>
          <button
            type="button"
            onClick={() => setMode(mode === 'years' ? 'days' : 'years')}
            className={`font-semibold text-sm px-2.5 py-1 rounded-lg transition-colors ${
              mode === 'years' 
                ? 'bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300' 
                : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-indigo-600 dark:text-indigo-400'
            }`}
          >
            {currentYear}
          </button>
        </div>

        {mode === 'days' ? (
          <button
            type="button"
            onClick={handleNextMonth}
            className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 transition-colors"
            title="Next month"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setMode('days')}
            className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold px-2 py-1 hover:underline"
          >
            Done
          </button>
        )}
      </div>

      {/* Month Selection Mode */}
      {mode === 'months' && (
        <div className="grid grid-cols-3 gap-2 py-2">
          {SHORT_MONTHS.map((m, idx) => (
            <button
              key={m}
              type="button"
              onClick={() => {
                setViewDate(new Date(currentYear, idx, 1));
                setMode('days');
              }}
              className={`py-2 text-xs font-semibold rounded-xl transition-all ${
                currentMonth === idx
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300'
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      )}

      {/* Year Selection Mode */}
      {mode === 'years' && (
        <div className="grid grid-cols-4 gap-2 py-2 max-h-48 overflow-y-auto">
          {years.map(y => (
            <button
              key={y}
              type="button"
              onClick={() => {
                setViewDate(new Date(y, currentMonth, 1));
                setMode('days');
              }}
              className={`py-2 text-xs font-semibold rounded-xl transition-all ${
                currentYear === y
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300'
              }`}
            >
              {y}
            </button>
          ))}
        </div>
      )}

      {/* Days Grid Mode */}
      {mode === 'days' && (
        <>
          {/* Day of Week Header */}
          <div className="grid grid-cols-7 gap-1 text-center mb-1">
            {DAYS_OF_WEEK.map(d => (
              <div key={d} className="text-[11px] font-bold text-gray-400 dark:text-gray-500 py-1">
                {d}
              </div>
            ))}
          </div>

          {/* Day cells */}
          <div className="grid grid-cols-7 gap-1 text-center">
            {/* Previous month trailing days */}
            {Array.from({ length: firstDayIndex }).map((_, i) => {
              const dayNum = daysInPrevMonth - firstDayIndex + i + 1;
              return (
                <div
                  key={`prev-${i}`}
                  className="text-xs py-2 text-gray-300 dark:text-gray-600 cursor-not-allowed"
                >
                  {dayNum}
                </div>
              );
            })}

            {/* Days of current month */}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const selected = isSelected(day);
              const todayDay = isToday(day);

              return (
                <button
                  key={`day-${day}`}
                  type="button"
                  onClick={() => handleSelectDay(day)}
                  className={`text-xs py-2 rounded-xl font-medium transition-all flex items-center justify-center relative ${
                    selected
                      ? 'bg-indigo-600 text-white font-bold shadow-md shadow-indigo-500/20'
                      : todayDay
                      ? 'border border-indigo-500 text-indigo-600 dark:text-indigo-400 font-bold hover:bg-indigo-50 dark:hover:bg-indigo-950/30'
                      : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200'
                  }`}
                >
                  {day}
                  {todayDay && !selected && (
                    <span className="absolute bottom-0.5 w-1 h-1 rounded-full bg-indigo-500" />
                  )}
                </button>
              );
            })}
          </div>
        </>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-gray-100 dark:border-gray-700/60 text-xs">
        <button
          type="button"
          onClick={handleSelectToday}
          className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 font-semibold px-2 py-1 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition-colors"
        >
          Today
        </button>
        <button
          type="button"
          onClick={() => setIsOpen(false)}
          className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 px-2 py-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        >
          Close
        </button>
      </div>
    </div>
  );

  return (
    <div ref={containerRef} className="relative w-full" dir="ltr">
      {/* Input trigger button */}
      <button
        id={id}
        type="button"
        disabled={disabled}
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full flex items-center justify-between p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-left font-mono text-sm ${
          disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:border-gray-300 dark:hover:border-gray-600'
        } ${className}`}
        style={{ fontFamily: 'ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}
      >
        <span className={`font-medium ${value ? 'text-gray-900 dark:text-gray-100' : 'text-gray-400 dark:text-gray-500'}`}>
          {value || placeholder}
        </span>
        <CalendarIcon className="w-4 h-4 text-indigo-500 shrink-0 ml-2" />
      </button>

      {/* Mobile Modal Backdrop & Popover */}
      {isOpen && (
        <>
          {/* Mobile Overlay: fixed centered modal on small screens */}
          <div 
            className="fixed inset-0 z-[100] sm:hidden bg-black/40 backdrop-blur-xs flex items-center justify-center p-4"
            onClick={() => setIsOpen(false)}
          >
            <div 
              ref={popoverRef}
              className="w-full max-w-[320px] bg-white dark:bg-gray-800 rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-700 p-4 animate-in fade-in zoom-in-95 duration-150"
              onClick={e => e.stopPropagation()}
            >
              <CalendarBody />
            </div>
          </div>

          {/* Desktop Popover: anchored underneath button */}
          <div
            ref={popoverRef}
            className="hidden sm:block absolute z-50 mt-2 left-0 w-80 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-100 dark:border-gray-700 p-4 animate-in fade-in zoom-in-95 duration-150"
          >
            <CalendarBody />
          </div>
        </>
      )}
    </div>
  );
};
export default EnglishDatePicker;
