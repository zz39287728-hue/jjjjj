import React, { useState } from 'react';
import { useStore } from '../store';
import { Device } from '../types';
import confetti from 'canvas-confetti';
import { t } from '../i18n';
import { X } from 'lucide-react';
import { formatBHD, toLatinDigits, translateExtra, hapticFeedback } from '../utils';
import { motion, AnimatePresence } from 'motion/react';
import EnglishDatePicker from './EnglishDatePicker';

export default function SellModal({ device, onClose }: { device: Device, onClose: () => void }) {
  const { sellDevice, language, turboMode } = useStore();

  const [sellPrice, setSellPrice] = useState('');
  const [sellDate, setSellDate] = useState(new Date().toISOString().split('T')[0]);
  const [buyerName, setBuyerName] = useState('');
  const [buyerPhone, setBuyerPhone] = useState('');
  const [buyerArea, setBuyerArea] = useState('');
  const [soldExtras, setSoldExtras] = useState<string[]>(device.extras ? [...device.extras] : []);
  const [sellMethod, setSellMethod] = useState<'cash' | 'benefit' | 'mixed'>('benefit');
  const [cashAmount, setCashAmount] = useState('');
  const [benefitAmount, setBenefitAmount] = useState('');
  const [isSold, setIsSold] = useState(false);
  const [showOverlay, setShowOverlay] = useState(true);
  const [randomVideo, setRandomVideo] = useState('/videoplayback.mp4');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPrice = toLatinDigits(sellPrice);
    
    const missingFields: string[] = [];
    if (!cleanPrice) missingFields.push(language === 'ar' ? 'سعر البيع' : 'Sell Price');
    if (!buyerName) missingFields.push(language === 'ar' ? 'اسم المشتري' : 'Buyer Name');
    
    if (missingFields.length > 0) {
      alert((language === 'ar' ? 'يرجى إكمال الحقول التالية:\n\n' : 'Please complete the following fields:\n\n') + missingFields.map(f => `- ${f}`).join('\n'));
      return;
    }

    if (parseFloat(cleanPrice) < 0) return alert(t('price_negative', language));
    if (buyerPhone && buyerPhone.length !== 8) return alert(language === 'ar' ? 'رقم الهاتف يجب أن يكون 8 أرقام فقط' : 'Phone number must be exactly 8 digits');
    
    const parsedSellPrice = parseFloat(cleanPrice);
    let finalCash = sellMethod === 'cash' ? parsedSellPrice : sellMethod === 'mixed' ? parseFloat(toLatinDigits(cashAmount) || '0') : 0;
    let finalBenefit = sellMethod === 'benefit' ? parsedSellPrice : sellMethod === 'mixed' ? parseFloat(toLatinDigits(benefitAmount) || '0') : 0;
    
    if (sellMethod === 'mixed' && (finalCash + finalBenefit !== parsedSellPrice)) {
      return alert(language === 'ar' ? 'يجب أن يكون مجموع مبلغ الكاش وبنفت مساوياً لسعر البيع' : 'The sum of Cash and Benefit must equal the Sale Price');
    }
    
    sellDevice(
      device.id, 
      parsedSellPrice, 
      sellDate, 
      toLatinDigits(buyerName).trim(), 
      toLatinDigits(buyerPhone).trim(), 
      toLatinDigits(buyerArea).trim(), 
      soldExtras, 
      sellMethod, 
      finalCash, 
      finalBenefit
    );

    hapticFeedback('celebration');

    const videos = [
      '/videoplayback.mp4',
      '/video1.mp4',
      '/video2.mp4',
      '/video3.mp4',
      '/video5.mp4'
    ];
    setRandomVideo(videos[Math.floor(Math.random() * videos.length)]);

    setIsSold(true);
    
    // Celebrate!
    if (!turboMode) {
      const duration = 2500;
      const end = Date.now() + duration;

      const frame = () => {
        confetti({
          particleCount: 8,
          angle: 60,
          spread: 60,
          origin: { x: 0 },
          colors: ['#4f46e5', '#a855f7', '#fbbf24', '#10b981', '#ef4444']
        });
        confetti({
          particleCount: 8,
          angle: 120,
          spread: 60,
          origin: { x: 1 },
          colors: ['#4f46e5', '#a855f7', '#fbbf24', '#10b981', '#ef4444']
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };
      frame();
    }

    setTimeout(() => {
      onClose();
    }, 4500);
  };

  const deviceExpensesTotal = (device.expenses || []).reduce((sum, e) => sum + (e.amount || 0), 0);
  const currentProfit = sellPrice ? parseFloat(sellPrice) - device.buyPrice - deviceExpensesTotal : 0;

    if (isSold) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 cursor-pointer" onClick={() => onClose()}>
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          className="absolute inset-0 bg-black"
        />
        {!turboMode && (
          <video 
            src={randomVideo}
            autoPlay 
            playsInline
            muted
            loop
            className="absolute inset-0 w-full h-full object-cover z-0 opacity-80"
          />
        )}
        <AnimatePresence>
          {showOverlay && (
            <motion.div 
              initial={{ scale: 0.5, opacity: 0, y: 50 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
              className="relative bg-white/90 dark:bg-gray-800/90 backdrop-blur-xl rounded-3xl p-8 max-w-sm w-full shadow-2xl flex flex-col items-center text-center overflow-hidden z-10 border border-white/20 dark:border-gray-700/50"
            >
              {/* Animated Background Rays */}
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                className="absolute -inset-[100%] bg-[conic-gradient(from_0deg,transparent_0_340deg,rgba(79,70,229,0.1)_360deg)]"
              />
              
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1, rotate: [0, 10, -10, 0] }}
                transition={{ 
                  scale: { delay: 0.2, type: 'spring', stiffness: 200, damping: 10 },
                  rotate: { delay: 0.4, duration: 0.5 }
                }}
                className="w-24 h-24 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center mb-6 shadow-lg shadow-emerald-500/30 relative z-10"
              >
                <svg className="w-12 h-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </motion.div>
              
              <motion.h2 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="text-3xl font-black bg-gradient-to-r from-emerald-600 to-indigo-600 bg-clip-text text-transparent mb-2 relative z-10"
              >
                {language === 'ar' ? 'تم البيع بنجاح!' : 'Successfully Sold!'}
              </motion.h2>
              
              <motion.p 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="text-gray-500 dark:text-gray-400 font-medium relative z-10"
              >
                {language === 'ar' ? 'مبروك، تمت إضافة الأرباح إلى السجل.' : 'Congratulations, profits added to the record.'}
              </motion.p>
              
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.7, type: 'spring' }}
                className="mt-6 px-6 py-3 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 rounded-2xl font-bold relative z-10 text-xl flex items-center gap-2"
              >
                <span>+</span>
                <span>{formatBHD(currentProfit)}</span>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center sm:p-4"
    >
      <motion.div 
        initial={{ opacity: 0, scale: 0.98, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.98, y: 15 }}
        transition={{ duration: 0.2 }}
        className="bg-white dark:bg-gray-800 w-full h-full sm:h-auto sm:max-h-[92vh] sm:max-w-2xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center shrink-0 bg-white dark:bg-gray-800">
          <div className="flex items-center gap-2.5">
            <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">{t('sell_device', language)}</h2>
            <span className="text-xs bg-indigo-50 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 px-2.5 py-1 rounded-full font-medium">
              {device.title || device.model}
            </span>
          </div>
          <motion.button 
            whileTap={{ scale: 0.9 }}
            onClick={() => { hapticFeedback("light"); onClose(); }} 
            className="p-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-full text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:text-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </motion.button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* Device Summary Card */}
          <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 flex justify-between items-center">
            <div>
              <p className="text-xs text-gray-500 dark:text-gray-400">{t('device', language)}</p>
              <p className="font-bold text-gray-900 dark:text-gray-100 text-base">{device.title || device.model}</p>
              {device.title && <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{device.model}</p>}
              {device.extras && device.extras.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {device.extras.map((extra, idx) => (
                    <span key={idx} className="bg-purple-50 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 border border-purple-100 dark:border-purple-800 text-[11px] px-2 py-0.5 rounded-md font-medium">
                      {translateExtra(extra)}
                    </span>
                  ))}
                </div>
              )}
            </div>
            <div className="text-end">
              <p className="text-xs text-gray-500 dark:text-gray-400">{t('buy_cost', language)}</p>
              <p className="font-bold text-gray-900 dark:text-gray-100 text-base">{formatBHD(device.buyPrice)}</p>
            </div>
          </div>

          {/* Form */}
          <form id="sell-form" onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">{t('sell_price', language)}</label>
                <input 
                  type="number" step="1" min="0" value={sellPrice} 
                  onChange={e => { const v = toLatinDigits(e.target.value); if (v === "" || Number(v) <= 10000) setSellPrice(v); }}
                  onKeyDown={(e) => { if (['e', 'E', '+', '-'].includes(e.key)) e.preventDefault(); }}
                   lang="en" dir="ltr"
                  className="w-full p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-left"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">{t('sell_date', language)}</label>
                <EnglishDatePicker 
                  value={sellDate} 
                  onChange={setSellDate} 
                />
              </div>
            </div>

            <div className="pt-2 border-t border-gray-100 dark:border-gray-700 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{language === 'ar' ? 'طريقة الدفع' : 'Payment Method'}</label>
                <div className="flex bg-gray-100 dark:bg-gray-700/60 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setSellMethod('benefit')}
                    className={`flex-1 py-2 text-sm font-medium rounded-lg transition-colors ${sellMethod === 'benefit' ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}
                  >
                    بنفت
                  </button>
                  <button
                    type="button"
                    onClick={() => setSellMethod('cash')}
                    className={`flex-1 py-2 text-sm font-medium rounded-lg transition-colors ${sellMethod === 'cash' ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}
                  >
                    كاش
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSellMethod('mixed');
                      if (sellPrice) {
                        setCashAmount((parseFloat(sellPrice) / 2).toString());
                        setBenefitAmount((parseFloat(sellPrice) / 2).toString());
                      }
                    }}
                    className={`flex-1 py-2 text-sm font-medium rounded-lg transition-colors ${sellMethod === 'mixed' ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}
                  >
                    مشترك
                  </button>
                </div>
              </div>
              
              {sellMethod === 'mixed' && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{language === 'ar' ? 'مبلغ بنفت' : 'Benefit Amount'}</label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.1"
                       
                        value={benefitAmount}
                        onChange={(e) => {
                          const val = toLatinDigits(e.target.value);
                          if (Number(val) <= 10000) setBenefitAmount(val); else return;
                          const sp = toLatinDigits(sellPrice);
                          if (sp && val) {
                            const remainder = parseFloat(sp) - parseFloat(val);
                            setCashAmount(Math.max(0, remainder).toString());
                          }
                        }}
                        lang="en" dir="ltr"
                        className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:text-white text-left"
                      />
                      <span className="absolute left-3 top-3 text-gray-400 text-sm">BD</span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{language === 'ar' ? 'مبلغ الكاش' : 'Cash Amount'}</label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.1"
                       
                        value={cashAmount}
                        onChange={(e) => {
                          const val = toLatinDigits(e.target.value);
                          if (Number(val) <= 10000) setCashAmount(val); else return;
                          const sp = toLatinDigits(sellPrice);
                          if (sp && val) {
                            const remainder = parseFloat(sp) - parseFloat(val);
                            setBenefitAmount(Math.max(0, remainder).toString());
                          }
                        }}
                        lang="en" dir="ltr"
                        className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:text-white text-left"
                      />
                      <span className="absolute left-3 top-3 text-gray-400 text-sm">BD</span>
                    </div>
                  </div>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">{t('buyer_name', language)}</label>
                <input 
                  type="text" value={buyerName} onChange={e => setBuyerName(toLatinDigits(e.target.value))}
                  
                  className="w-full p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">{t('buyer_phone', language)}</label>
                  <input 
                    type="tel" maxLength={8} value={buyerPhone} onChange={e => {
                      const val = toLatinDigits(e.target.value).replace(/\D/g, '');
                      if (val.length <= 8) setBuyerPhone(val);
                    }}
                    
                    className="w-full p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">{t('buyer_area', language)}</label>
                  <input 
                    type="text" value={buyerArea} onChange={e => setBuyerArea(toLatinDigits(e.target.value))}
                    
                    className="w-full p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>
            </div>

            {device.extras && device.extras.length > 0 && (
              <div className="pt-2 border-t border-gray-100 dark:border-gray-700">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('extras_included_sale', language)}</label>
                <div className="flex flex-wrap gap-2">
                  {device.extras.map((extra, idx) => {
                    const isSelected = soldExtras.includes(extra);
  return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setSoldExtras(prev => 
                            isSelected ? prev.filter(e => e !== extra) : [...prev, extra]
                          )
                        }}
                        className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${isSelected ? 'bg-indigo-50 dark:bg-indigo-900/40 border-indigo-500 text-indigo-700 dark:text-indigo-300 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
                      >
                        {translateExtra(extra)}
                      </button>
                    )
                  })}
                </div>
              </div>
            )}

            {sellPrice && !isNaN(currentProfit) && (
              <div className={`p-4 rounded-2xl border flex flex-col ${currentProfit >= 0 ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200' : 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'}`}>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-sm">{currentProfit >= 0 ? t('expected_profit', language) : t('expected_loss', language)}</span>
                  <span className="font-bold text-lg">{formatBHD(Math.abs(currentProfit))}</span>
                </div>
                {device.extras && device.extras.filter(e => !soldExtras.includes(e)).length > 0 && (
                  <div className="mt-3 pt-3 border-t border-current/20 flex flex-wrap items-center gap-1.5">
                    <span className="text-xs font-semibold opacity-90">{language === 'ar' ? '+ ربح إضافي (إضافات متبقية):' : '+ Extra Profit (Kept Extras):'}</span>
                    {device.extras.filter(e => !soldExtras.includes(e)).map((ex, i) => (
                      <span key={i} className="text-[10px] bg-current/10 px-2 py-0.5 rounded-full font-bold">
                        {translateExtra(ex)}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}
          </form>
        </div>
        
        {/* Fixed Footer with Submit Button */}
        <div className="p-4 sm:p-5 border-t border-gray-100 dark:border-gray-700 shrink-0 bg-white dark:bg-gray-800 sm:rounded-b-3xl">
          <motion.button 
            whileTap={{ scale: 0.98 }}
            type="submit" form="sell-form"
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3.5 rounded-xl shadow-lg dark:shadow-none transition-all flex items-center justify-center text-base"
          >
            تأكيد البيع
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
}
