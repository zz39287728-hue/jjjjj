import React, { useState } from 'react';
import { Device, Expense, ExtraAction } from '../types';
import { Receipt } from 'lucide-react';
import { t } from '../i18n';
import { X, Calendar, Phone, MapPin, Image as ImageIcon, Pencil, Check, Briefcase, Gamepad, Disc, Headphones, Wind, MonitorUp, MoreHorizontal, User, Trash2 } from 'lucide-react';
import { formatBHD, formatDate, toLatinDigits, translateExtra, getWhatsAppLink, hapticFeedback } from '../utils';
import { useStore } from '../store';
import { motion } from 'motion/react';
import EnglishDatePicker from './EnglishDatePicker';

export default function DeviceDetailsModal({ device, onClose, onImageClick }: { device: Device, onClose: () => void, onImageClick: (img: string) => void }) {
  const { updateDevice, language } = useStore();
  const [isEditing, setIsEditing] = useState(false);
  
  // Edit State
  const [title, setTitle] = useState(device.title || '');
  const [model, setModel] = useState(device.model || '');
  const [buyPrice, setBuyPrice] = useState(device.buyPrice.toString());
  const [buyDate, setBuyDate] = useState(device.buyDate);
  const [area, setArea] = useState(device.area || '');
  const [expenses, setExpenses] = useState<Expense[]>(device.expenses || []);
  const [loanStatus, setLoanStatus] = useState(device.loanStatus || 'unpaid');
  const [loanAmount, setLoanAmount] = useState(device.loanAmount?.toString() || '');
  const [extraActions, setExtraActions] = useState<ExtraAction[]>(device.extraActions || []);
  const [sellerName, setSellerName] = useState(device.sellerName || '');
  const [sellerPhone, setSellerPhone] = useState(device.sellerPhone || '');
  
  const [hasBag, setHasBag] = useState(device.extras?.includes('Bag') || false);
  const [hasController, setHasController] = useState(device.extras?.includes('Extra Controller') || false);
  const [hasHeadset, setHasHeadset] = useState(device.extras?.includes('Headset') || false);
  const [hasCooler, setHasCooler] = useState(device.extras?.includes('Cooler') || false);
  const [hasStand, setHasStand] = useState(device.extras?.includes('Stand') || false);
  
  const cdExtra = device.extras?.find(e => e.startsWith('CD: '));
  const [hasCD, setHasCD] = useState(!!cdExtra);
  const [cdName, setCdName] = useState(cdExtra ? cdExtra.replace('CD: ', '') : '');

  const otherExtra = device.extras?.find(e => e.startsWith('Other: '));
  const [hasOther, setHasOther] = useState(!!otherExtra);
  const [otherName, setOtherName] = useState(otherExtra ? otherExtra.replace('Other: ', '') : '');

  const [hasWarranty, setHasWarranty] = useState(device.hasWarranty || false);
  const [warrantyMonths, setWarrantyMonths] = useState(device.warrantyMonths?.toString() || '');

  const currentExtrasList = React.useMemo(() => {
    const list = [];
    if (hasBag) list.push('Bag');
    if (hasController) list.push('Extra Controller');
    if (hasCD && cdName.trim()) list.push(`CD: ${cdName.trim()}`);
    if (hasHeadset) list.push('Headset');
    if (hasCooler) list.push('Cooler');
    if (hasStand) list.push('Stand');
    if (hasOther && otherName.trim()) list.push(`Other: ${otherName.trim()}`);
    return list;
  }, [hasBag, hasController, hasCD, cdName, hasHeadset, hasCooler, hasStand, hasOther, otherName]);

  const [sellPrice, setSellPrice] = useState(device.sellPrice?.toString() || '');
  const [sellDate, setSellDate] = useState(device.sellDate || '');
  const [buyerName, setBuyerName] = useState(device.buyerName || '');
  const [buyerPhone, setBuyerPhone] = useState(device.buyerPhone || '');
  const [buyerArea, setBuyerArea] = useState(device.buyerArea || '');
  const [soldExtras, setSoldExtras] = useState<string[]>(device.soldExtras || []);
  const [sellMethod, setSellMethod] = useState<'cash' | 'benefit' | 'mixed' | undefined>(device.sellMethod);
  const [cashAmount, setCashAmount] = useState(device.cashAmount?.toString() || '');
  const [benefitAmount, setBenefitAmount] = useState(device.benefitAmount?.toString() || '');

  const isSold = device.status === 'sold';

  const handleSave = () => {
    if (sellerPhone && sellerPhone.length !== 8) return alert(language === 'ar' ? 'رقم هاتف البائع يجب أن يكون 8 أرقام فقط' : 'Seller phone must be exactly 8 digits');
    if (isSold && buyerPhone && buyerPhone.length !== 8) return alert(language === 'ar' ? 'رقم هاتف المشتري يجب أن يكون 8 أرقام فقط' : 'Buyer phone must be exactly 8 digits');

    const updates: Partial<Device> = {
      title: toLatinDigits(title).trim(),
      model: toLatinDigits(model).trim(),
      buyPrice: parseFloat(toLatinDigits(buyPrice)) || 0,
      buyDate,
      hasWarranty,
      warrantyMonths: hasWarranty && warrantyMonths ? parseInt(toLatinDigits(warrantyMonths)) : undefined,
      area: toLatinDigits(area).trim(),
      sellerName: toLatinDigits(sellerName).trim(),
      sellerPhone: toLatinDigits(sellerPhone).trim(),
      expenses: expenses.map(e => ({
        ...e,
        amount: parseFloat(toLatinDigits(e.amount)) || 0,
        customName: e.customName ? toLatinDigits(e.customName).trim() : undefined,
      })),
      extraActions: extraActions.map(a => ({
        ...a,
        price: a.price != null ? (parseFloat(toLatinDigits(a.price)) || 0) : undefined,
        notes: a.notes ? toLatinDigits(a.notes).trim() : undefined,
      })),
      extras: currentExtrasList.map(e => toLatinDigits(e)),
      loanStatus,
      ...(loanAmount && { loanAmount: parseFloat(toLatinDigits(loanAmount)) }),
      ...(!loanAmount && { loanAmount: null as any }) // clear if empty
    };

    if (isSold) {
      updates.sellPrice = parseFloat(toLatinDigits(sellPrice)) || 0;
      updates.sellDate = sellDate;
      updates.buyerName = toLatinDigits(buyerName).trim();
      updates.buyerPhone = toLatinDigits(buyerPhone).trim();
      updates.buyerArea = toLatinDigits(buyerArea).trim();
      updates.soldExtras = soldExtras.filter(e => currentExtrasList.includes(e));
      if (cashAmount) updates.cashAmount = parseFloat(toLatinDigits(cashAmount)) || 0;
      if (benefitAmount) updates.benefitAmount = parseFloat(toLatinDigits(benefitAmount)) || 0;
    }

    updateDevice(device.id, updates);
    setIsEditing(false);
  };
  
const ExtraToggle = ({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) => (
  <button
    type="button"
    onClick={onClick}
    className={`flex items-center justify-center p-2.5 rounded-xl border text-xs font-medium transition-all ${active ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
  >
    <div className="mr-1.5 [&>svg]:w-3.5 [&>svg]:h-3.5">{icon}</div>
    {label}
  </button>
);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center sm:p-4" 
    >
      <motion.div 
        initial={{ opacity: 0, scale: 0.98, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.98, y: 15 }}
        transition={{ duration: 0.2 }}
        className="bg-gray-50 dark:bg-gray-700 w-full h-full sm:h-auto sm:max-h-[92vh] sm:max-w-2xl sm:rounded-3xl shadow-2xl flex flex-col pointer-events-auto overflow-hidden"
      >
        <div className="p-4 bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-800 sm:rounded-t-3xl flex justify-between items-center shrink-0 sticky top-0 z-10">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">{isEditing ? t('edit_details', language) : t('device_details', language)}</h2>
          <div className="flex items-center gap-2">
            {isEditing ? (
              <button onClick={handleSave} className="px-3 py-1.5 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 flex items-center">
                <Check className="w-4 h-4 me-1" /> {t('save', language)}
              </button>
            ) : (
              <button onClick={() => setIsEditing(true)} className="p-2 bg-indigo-50 text-indigo-600 rounded-full hover:bg-indigo-100">
                <Pencil className="w-4 h-4" />
              </button>
            )}
            <button onClick={onClose} className="p-2 bg-gray-50 dark:bg-gray-700 rounded-full text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:text-gray-100">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          
          {isEditing ? (
            <div className="space-y-6">
              <div className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm space-y-5">
                <h3 className="font-bold text-gray-900 dark:text-gray-100 border-b border-gray-100 dark:border-gray-800 pb-2 mb-6">{t('main_purchase_info', language)}</h3>
                <div>
                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('title', language)}</label>
                  <input type="text" value={title} onChange={e => setTitle(toLatinDigits(e.target.value))} className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('model', language)}</label>
                  <input type="text" value={model} onChange={e => setModel(toLatinDigits(e.target.value))} className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
                <div className="flex flex-col space-y-5">
                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('buy_price', language)}</label>
                    <input type="number" step="1" value={buyPrice} onChange={e => { const v = toLatinDigits(e.target.value); if (v === "" || Number(v) <= 10000) setBuyPrice(v); }} lang="en" dir="ltr" className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-left" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('buy_date', language)}</label>
                    <EnglishDatePicker value={buyDate} onChange={setBuyDate} className="!p-2 text-sm !rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{language === 'ar' ? 'قيمة الدين (إذا وجد)' : 'Loan Amount (if any)'}</label>
                    <input type="number" step="1" min="0" value={loanAmount} onChange={e => { const v = toLatinDigits(e.target.value); if (v === "" || Number(v) <= 10000) setLoanAmount(v); }} lang="en" dir="ltr" className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-left" placeholder="0" />
                  </div>
                  
                  <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={hasWarranty}
                        onChange={e => setHasWarranty(e.target.checked)}
                        className="w-4 h-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-600 dark:border-gray-600 dark:bg-gray-700"
                      />
                      <span className="text-xs font-medium text-gray-700 dark:text-gray-300">
                        {language === 'ar' ? 'يوجد ضمان' : 'Has Warranty'}
                      </span>
                    </label>
                    
                    {hasWarranty && (
                      <div className="mt-3">
                        <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                          {language === 'ar' ? 'مدة الضمان (بالأشهر)' : 'Warranty Duration (Months)'}
                        </label>
                        <input 
                          type="number" step="1" min="1" value={warrantyMonths} onChange={e => setWarrantyMonths(toLatinDigits(e.target.value))} lang="en" dir="ltr"
                          placeholder="12"
                          className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-left"
                        />
                      </div>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('area', language)}</label>
                    <input type="text" value={area} onChange={e => setArea(toLatinDigits(e.target.value))} className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                                    <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('seller_name', language)}</label>
                    <input type="text" value={sellerName} onChange={e => setSellerName(toLatinDigits(e.target.value))} className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('seller_phone', language)}</label>
                    <input type="tel" maxLength={8} value={sellerPhone} onChange={e => {
                      const val = toLatinDigits(e.target.value).replace(/\D/g, '');
                      if (val.length <= 8) setSellerPhone(val);
                    }} className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                </div>
                                <div>
                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">{t('expenses', language)}</label>
                  {expenses.map((exp, idx) => (
                    <div key={exp.id} className="flex gap-2 mb-2 items-center bg-gray-50 dark:bg-gray-700/50 p-2 rounded-lg border border-gray-100 dark:border-gray-700">
                      <select 
                        value={exp.type}
                        onChange={(e) => {
                          const newExp = [...expenses];
                          newExp[idx].type = e.target.value as any;
                          setExpenses(newExp);
                        }}
                        className="flex-1 p-1.5 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md outline-none"
                      >
                        <option value="petrol_dad">{t('exp_petrol_dad', language)}</option>
                        <option value="petrol">{t('exp_petrol', language)}</option>
                        <option value="dinner_abbas">{t('exp_dinner_abbas', language)}</option>
                        <option value="maintenance">{t('exp_maintenance', language)}</option>
                        <option value="delivery">{t('exp_delivery', language)}</option>
                        <option value="other">{t('exp_other', language)}</option>
                      </select>
                      {exp.type === 'other' && (
                        <input 
                          type="text"
                          placeholder={t('expense_custom_name', language)}
                          value={exp.customName || ''}
                          onChange={(e) => {
                            const newExp = [...expenses];
                            newExp[idx].customName = toLatinDigits(e.target.value);
                            setExpenses(newExp);
                          }}
                          className="flex-1 p-1.5 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md outline-none w-20"
                        />
                      )}
                      <input 
                        type="number"
                        placeholder={t('expense_amount', language)}
                        value={exp.amount || ''}
                        onChange={(e) => {
                          const newExp = [...expenses];
                          newExp[idx].amount = parseFloat(toLatinDigits(e.target.value)) || 0;
                          setExpenses(newExp);
                        }}
                        lang="en" dir="ltr"
                        className="w-16 p-1.5 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md outline-none text-left"
                      />
                      <button type="button" onClick={() => setExpenses(expenses.filter((_, i) => i !== idx))} className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 p-1.5 rounded-md transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => setExpenses([...expenses, { id: Date.now().toString(), type: 'other', amount: 0 }])}
                    className="mt-1 w-full py-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-xs font-medium rounded-lg border border-indigo-100 dark:border-indigo-800 hover:bg-indigo-100 transition-colors"
                  >
                    + {t('add_expense', language)}
                  </button>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">{t('original_extras', language)}</label>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    <button type="button" onClick={() => setHasBag(!hasBag)} className={`px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all ${hasBag ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}>{t('bag', language)}</button>
                    <button type="button" onClick={() => setHasController(!hasController)} className={`px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all ${hasController ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}>{t('extra_controller', language)}</button>
                    <button type="button" onClick={() => setHasCD(!hasCD)} className={`px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all ${hasCD ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}>{t('cd', language)}</button>
                    <button type="button" onClick={() => setHasHeadset(!hasHeadset)} className={`px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all ${hasHeadset ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}>{t('headset', language)}</button>
                    <button type="button" onClick={() => setHasCooler(!hasCooler)} className={`px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all ${hasCooler ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}>{t('cooler', language)}</button>
                    <button type="button" onClick={() => setHasStand(!hasStand)} className={`px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all ${hasStand ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}>{t('stand', language)}</button>
                    <button type="button" onClick={() => setHasOther(!hasOther)} className={`px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all ${hasOther ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}>{t('other', language)}</button>
                  </div>
                  {hasCD && (
                    <div className="mb-2">
                      <input type="text" value={cdName} onChange={e => setCdName(toLatinDigits(e.target.value))} placeholder={t("cd_name", language)} className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                    </div>
                  )}
                  {hasOther && (
                    <div>
                      <input type="text" value={otherName} onChange={e => setOtherName(toLatinDigits(e.target.value))} placeholder={t("other_name", language)} className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                    </div>
                  )}
                </div>
              </div>

              {isSold && (
                <div className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm space-y-5">
                  <h3 className="font-bold text-gray-900 dark:text-gray-100 border-b border-gray-100 dark:border-gray-800 pb-2 mb-6">{t('sale_info', language)}</h3>
                  <div className="flex flex-col space-y-5">
                    <div>
                      <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('sell_price', language)}</label>
                      <input type="number" step="1" value={sellPrice} onChange={e => { const v = toLatinDigits(e.target.value); if (v === "" || Number(v) <= 10000) setSellPrice(v); }} lang="en" dir="ltr" className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-left" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('sell_date', language)}</label>
                      <EnglishDatePicker value={sellDate} onChange={setSellDate} className="!p-2 text-sm !rounded-lg" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('buyer_name', language)}</label>
                    <input type="text" value={buyerName} onChange={e => setBuyerName(toLatinDigits(e.target.value))} className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('buyer_area', language)}</label>
                      <input type="text" value={buyerArea} onChange={e => setBuyerArea(toLatinDigits(e.target.value))} className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('buyer_phone', language)}</label>
                      <input type="tel" maxLength={8} value={buyerPhone} onChange={e => {
                      const val = toLatinDigits(e.target.value).replace(/\D/g, '');
                      if (val.length <= 8) setBuyerPhone(val);
                    }} className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">{t('sold_extras', language)}</label>
                    {currentExtrasList.length === 0 ? (
                      <p className="text-xs text-gray-400 dark:text-gray-500 italic">{t('no_original_extras', language)}</p>
                    ) : (
                      <div className="flex flex-wrap gap-1.5">
                        {currentExtrasList.map((extra, idx) => {
                          const isSelected = soldExtras.includes(extra);
                          return (
                            <button
                              key={idx} type="button"
                              onClick={() => setSoldExtras(prev => isSelected ? prev.filter(e => e !== extra) : [...prev, extra])}
                              className={`px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all ${isSelected ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
                            >
                              {translateExtra(extra, language)}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {isSold && currentExtrasList.filter(e => !soldExtras.includes(e)).length > 0 && (
                <div className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm space-y-5 mt-3">
                  <h3 className="font-bold text-gray-900 dark:text-gray-100 border-b border-gray-100 dark:border-gray-800 pb-2 mb-6">{t('manage_extras', language)}</h3>
                  <div className="space-y-6">
                    {currentExtrasList.filter(e => !soldExtras.includes(e)).map((extra, idx) => {
                      const actionObj = extraActions.find(a => a.extraName === extra) || { extraName: extra, action: 'pending' };
                      return (
                        <div key={idx} className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-gray-100 dark:border-gray-700">
                          <div className="font-bold text-gray-800 dark:text-gray-200 text-sm mb-2">{translateExtra(extra, language)}</div>
                          <div className="flex gap-2 mb-2">
                            <select
                              value={actionObj.action}
                              onChange={(e) => {
                                const newAction = e.target.value as any;
                                const filtered = extraActions.filter(a => a.extraName !== extra);
                                setExtraActions([...filtered, { ...actionObj, action: newAction }]);
                              }}
                              className="flex-1 p-2 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                            >
                              <option value="pending">{t('action_pending', language)}</option>
                              <option value="sold">{t('action_sold', language)}</option>
                              <option value="gifted">{t('action_gifted', language)}</option>
                              <option value="kept_personal">{t('action_kept', language)}</option>
                            </select>
                            
                            {actionObj.action === 'sold' && (
                              <input
                                type="number"
                                placeholder={t('extra_sale_price', language)}
                                value={actionObj.price || ''}
                                onChange={(e) => {
                                  const val = parseFloat(toLatinDigits(e.target.value)) || 0;
                                  const filtered = extraActions.filter(a => a.extraName !== extra);
                                  setExtraActions([...filtered, { ...actionObj, price: val }]);
                                }}
                                lang="en" dir="ltr"
                                className="w-24 p-2 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-left"
                              />
                            )}
                          </div>
                          {(actionObj.action === 'gifted' || actionObj.action === 'kept_personal') && (
                            <input
                              type="text"
                              placeholder={actionObj.action === 'gifted' ? t('extra_notes', language) : t('extra_notes_kept', language)}
                              value={actionObj.notes || ''}
                              onChange={(e) => {
                                const filtered = extraActions.filter(a => a.extraName !== extra);
                                setExtraActions([...filtered, { ...actionObj, notes: toLatinDigits(e.target.value) }]);
                              }}
                              className="w-full p-2 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <>
              <div className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm">
                <h3 className="font-bold text-gray-900 dark:text-gray-100 text-xl">{device.title || device.model}</h3>
                {device.title && <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{device.model}</p>}
                
                <div className="flex flex-wrap items-center text-sm text-gray-500 dark:text-gray-400 mt-3 gap-4">
                  <span className="flex items-center">
                    <Calendar className="w-4 h-4 me-1.5" />
                    {language === 'ar' ? 'الشراء: ' : 'Buy: '}{formatDate(device.buyDate)}
                  </span>
                  {device.hasWarranty && device.warrantyMonths && (
                    <span className="flex items-center text-indigo-600 dark:text-indigo-400 font-medium">
                      <Check className="w-4 h-4 me-1.5" />
                      {language === 'ar' ? `ضمان ${device.warrantyMonths} شهر` : `Warranty: ${device.warrantyMonths} Mo`}
                    </span>
                  )}
                  {isSold && device.sellDate && (
                    <span className="flex items-center">
                      <Calendar className="w-4 h-4 me-1.5" />
                      {language === 'ar' ? 'البيع: ' : 'Sell: '}{formatDate(device.sellDate)}
                    </span>
                  )}
                </div>
                
                <div className="mt-4 pt-4 border-t border-gray-50 dark:border-gray-800 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('buy_cost', language)}</p>
                    <p className="font-bold text-gray-900 dark:text-gray-100 text-lg">{formatBHD(device.buyPrice)}</p>
                  </div>
                  {isSold && device.sellPrice ? (
                    <div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('sell_price', language).replace(' (د.ب)', '')}</p>
                      <p className="font-bold text-gray-900 dark:text-gray-100 text-lg">{formatBHD(device.sellPrice)}</p>
                      <p className={`text-xs mt-1 font-medium ${device.sellPrice - device.buyPrice >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                        {device.sellPrice - device.buyPrice >= 0 ? t('profit', language) : t('loss', language)} 
                        {formatBHD(device.sellPrice - device.buyPrice)}
                      </p>
                    </div>
                  ) : null}
                </div>
              </div>

                            <div className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm space-y-6">
                <h4 className="font-semibold text-gray-900 dark:text-gray-100">{t('purchase_details', language)}</h4>
                
                {device.loanAmount && (
                  <div className="space-y-3 mb-6 pb-3 border-b border-gray-50 dark:border-gray-800 bg-rose-50/50 dark:bg-rose-900/10 p-3 rounded-xl border border-rose-100 dark:border-rose-900/30">
                    <div className="flex items-center text-sm font-medium text-rose-700 dark:text-rose-400">
                      <Receipt className="w-4 h-4 me-2" />
                      {language === 'ar' ? 'تم شراء هذا الجهاز بالدين' : 'Device bought on debt'}
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-600 dark:text-gray-400">{language === 'ar' ? 'المبلغ:' : 'Amount:'}</span>
                      <span className="font-bold text-rose-600 dark:text-rose-400">{formatBHD(device.loanAmount)}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-600 dark:text-gray-400">{language === 'ar' ? 'الدائن:' : 'Lender:'}</span>
                      <span className="font-medium text-gray-900 dark:text-gray-100">
                        {device.loanLender === 'lender_abbas' ? (language === 'ar' ? 'أعباس' : 'Abbas') : device.loanLender}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm pt-2 border-t border-rose-200/50 dark:border-rose-800/50">
                      <span className="text-gray-600 dark:text-gray-400">{language === 'ar' ? 'الحالة:' : 'Status:'}</span>
                      <div className="flex items-center gap-2">
                         <span className={`text-xs font-bold px-2 py-1 rounded-md ${device.loanStatus === 'paid' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400' : 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-400'}`}>
                           {device.loanStatus === 'paid' ? (language === 'ar' ? 'تم السداد' : 'Paid') : (language === 'ar' ? 'غير مسدد' : 'Unpaid')}
                         </span>
                      </div>
                    </div>
                    {device.loanStatus === 'unpaid' && (
                      <button
                        onClick={() => {
                          updateDevice(device.id, { loanStatus: 'paid' });
                          hapticFeedback('success');
                        }}
                        className="w-full mt-2 bg-emerald-500 hover:bg-emerald-600 text-white font-medium py-2 rounded-lg transition-colors text-sm"
                      >
                        {language === 'ar' ? 'تحديد كـ "تم السداد"' : 'Mark as Paid'}
                      </button>
                    )}
                    {device.loanStatus === 'paid' && (
                       <button
                         onClick={() => {
                           updateDevice(device.id, { loanStatus: 'unpaid' });
                           hapticFeedback('medium');
                         }}
                         className="w-full mt-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 font-medium py-2 rounded-lg transition-colors text-sm"
                       >
                         {language === 'ar' ? 'تراجع (إلغاء السداد)' : 'Undo (Mark Unpaid)'}
                       </button>
                    )}
                  </div>
                )}
                
                {device.expenses && device.expenses.length > 0 && (
                  <div className="space-y-2 mb-6 pb-3 border-b border-gray-50 dark:border-gray-800">
                    <div className="flex items-center text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      <Receipt className="w-4 h-4 me-2 text-indigo-500" />
                      {t('expenses', language)}
                    </div>
                    {device.expenses.map((exp, idx) => (
                      <div key={idx} className="flex justify-between items-center text-xs bg-gray-50 dark:bg-gray-700/50 p-2 rounded-lg border border-gray-100 dark:border-gray-700">
                        <span className="text-gray-600 dark:text-gray-300">
                          {exp.type === 'other' ? exp.customName || t('exp_other', language) : t(`exp_${exp.type}` as any, language)}
                        </span>
                        <span className="font-bold text-gray-900 dark:text-gray-100">{formatBHD(exp.amount)}</span>
                      </div>
                    ))}
                    <div className="flex justify-between items-center text-xs pt-1 px-1">
                      <span className="text-gray-500 dark:text-gray-400 font-medium">{language === 'ar' ? 'إجمالي المصاريف:' : 'Total Expenses:'}</span>
                      <span className="font-bold text-indigo-600 dark:text-indigo-400">{formatBHD(device.expenses.reduce((s, e) => s + e.amount, 0))}</span>
                    </div>
                  </div>
                )}

                
                                {(device.sellerName || device.sellerPhone || device.area || device.chatImage) ? (
                  <div className="space-y-5">
                    {device.sellerName && (
                      <div className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                        <User className="w-4 h-4 me-2 text-gray-400 dark:text-gray-500" />
                        <span className="text-gray-500 dark:text-gray-400 w-16">{t('seller_name', language)}:</span> {device.sellerName}
                      </div>
                    )}
                    {device.area && (
                      <div className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                        <MapPin className="w-4 h-4 me-2 text-gray-400 dark:text-gray-500" /> 
                        <span className="text-gray-500 dark:text-gray-400 w-16">{language === 'ar' ? 'المنطقة:' : 'Area:'}</span> {device.area}
                      </div>
                    )}
                    {device.sellerPhone && (
                      <div className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                        <Phone className="w-4 h-4 me-2 text-gray-400 dark:text-gray-500" />
                        <span className="text-gray-500 dark:text-gray-400 w-16">{language === 'ar' ? 'الهاتف:' : 'Phone:'}</span>
                        <a href={getWhatsAppLink(device.sellerPhone)} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">{device.sellerPhone}</a>
                      </div>
                    )}
                    {device.chatImage && (
                      <div className="pt-2">
                        <button 
                          onClick={() => onImageClick(device.chatImage!)} 
                          className="flex items-center text-sm text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-3 py-2 rounded-lg transition-colors border border-indigo-100 w-full justify-center font-medium"
                        >
                          <ImageIcon className="w-4 h-4 me-2" /> عرض صورة محادثة البائع
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-gray-400 dark:text-gray-500 italic">{t('no_purchase_details', language)}</p>
                )}

                {device.extras && device.extras.length > 0 && (
                  <div className="pt-3 border-t border-gray-50 dark:border-gray-800">
                    <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">{t('original_extras', language)}:</p>
                    <div className="flex flex-wrap gap-1.5">
                      {device.extras.map((extra, idx) => (
                        <span key={idx} className="bg-indigo-50 text-indigo-700 border border-indigo-100 text-xs px-2.5 py-1 rounded-md font-medium">
                          {translateExtra(extra, language)}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {isSold && (
                <div className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm space-y-6">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">{t('sale_info', language)}</h4>
                  
                  {device.sellMethod && (
                    <div className="flex flex-wrap gap-2 mb-6">
                      {device.sellMethod === 'benefit' && (
                        <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-purple-50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400">
                          {language === 'ar' ? 'الدفع عبر بنفت' : 'Paid via Benefit'} ({formatBHD(device.sellPrice || 0)})
                        </span>
                      )}
                      {device.sellMethod === 'cash' && (
                        <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                          {language === 'ar' ? 'دفع كاش' : 'Paid in Cash'} ({formatBHD(device.sellPrice || 0)})
                        </span>
                      )}
                      {device.sellMethod === 'mixed' && (
                        <>
                          <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-purple-50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400">
                            بنفت: {formatBHD(device.benefitAmount || 0)}
                          </span>
                          <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                            كاش: {formatBHD(device.cashAmount || 0)}
                          </span>
                        </>
                      )}
                    </div>
                  )}
                  
                  {(device.buyerName || device.buyerPhone || device.buyerArea) ? (
                    <div className="space-y-5">
                      {device.buyerName && (
                        <div className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                          <span className="text-gray-500 dark:text-gray-400 w-16">{language === 'ar' ? 'الاسم:' : 'Name:'}</span> 
                          <span className="font-medium">{device.buyerName}</span>
                        </div>
                      )}
                      {device.buyerArea && (
                        <div className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                          <MapPin className="w-4 h-4 me-2 text-gray-400 dark:text-gray-500" /> 
                          <span className="text-gray-500 dark:text-gray-400 w-16">{language === 'ar' ? 'المنطقة:' : 'Area:'}</span> {device.buyerArea}
                        </div>
                      )}
                      {device.buyerPhone && (
                        <div className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                          <Phone className="w-4 h-4 me-2 text-gray-400 dark:text-gray-500" />
                          <span className="text-gray-500 dark:text-gray-400 w-16">{language === 'ar' ? 'الهاتف:' : 'Phone:'}</span>
                          <a href={getWhatsAppLink(device.buyerPhone)} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">{device.buyerPhone}</a>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-400 dark:text-gray-500 italic">{t('no_sale_details', language)}</p>
                  )}

                                    {device.extras && device.extras.filter(e => !device.soldExtras?.includes(e)).length > 0 && (
                    <div className="pt-3 border-t border-gray-50 dark:border-gray-800">
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">{t('kept_extras', language)}</p>
                      <div className="flex flex-col gap-2">
                        {device.extras.filter(e => !device.soldExtras?.includes(e)).map((extra, idx) => {
                          const actionObj = device.extraActions?.find(a => a.extraName === extra);
                          let statusText = '';
                          let statusColor = 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300';
                          
                          if (actionObj?.action === 'sold') {
                            statusText = `${t('action_sold', language)} - ${formatBHD(actionObj.price || 0)}`;
                            statusColor = 'bg-indigo-50 text-indigo-700 border border-indigo-100 dark:bg-indigo-900/30 dark:border-indigo-800/50 dark:text-indigo-400';
                          } else if (actionObj?.action === 'gifted') {
                            statusText = actionObj.notes ? `${t('action_gifted', language)} (${actionObj.notes})` : t('action_gifted', language);
                            statusColor = 'bg-pink-50 text-pink-700 border border-pink-100 dark:bg-pink-900/30 dark:border-pink-800/50 dark:text-pink-400';
                          } else if (actionObj?.action === 'kept_personal') {
                            statusText = actionObj.notes ? `${t('action_kept', language)} (${actionObj.notes})` : t('action_kept', language);
                            statusColor = 'bg-emerald-50 text-emerald-700 border border-emerald-100 dark:bg-emerald-900/30 dark:border-emerald-800/50 dark:text-emerald-400';
                          }
                          
                          return (
                            <div key={idx} className="flex justify-between items-center text-xs">
                              <span className="font-medium text-gray-800 dark:text-gray-200">{translateExtra(extra, language)}</span>
                              {statusText ? (
                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${statusColor}`}>
                                  {statusText}
                                </span>
                              ) : (
                                <span className="bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400 text-[10px] px-2 py-0.5 rounded-full">
                                  {t('action_pending', language)}
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          )}

        </div>
      </motion.div>
    </motion.div>
  );
}
