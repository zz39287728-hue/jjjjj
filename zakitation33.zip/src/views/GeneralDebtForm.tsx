import React, { useState } from 'react';
import { useStore } from '../store';
import { t } from '../i18n';
import { toLatinDigits, hapticFeedback } from '../utils';
import { motion } from 'motion/react';
import EnglishDatePicker from '../components/EnglishDatePicker';

export default function GeneralDebtForm({ onSuccess }: { onSuccess: () => void }) {
  const { addGeneralDebt, language } = useStore();
  

  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [personName, setPersonName] = useState('أحمد الزاكي');
  const [notes, setNotes] = useState('');
  const [type, setType] = useState<'borrowed' | 'lent'>('borrowed');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanAmount = toLatinDigits(amount);
    
    const missingFields: string[] = [];
    if (!personName.trim()) missingFields.push(language === 'ar' ? 'الاسم' : 'Name');
    if (!cleanAmount) missingFields.push(language === 'ar' ? 'المبلغ' : 'Amount');

    if (missingFields.length > 0) {
      alert((language === 'ar' ? 'يرجى إكمال الحقول التالية:\n\n' : 'Please complete the following fields:\n\n') + missingFields.map(f => `- ${f}`).join('\n'));
      return;
    }

    await addGeneralDebt({
      amount: parseFloat(cleanAmount) || 0,
      date,
      personName: toLatinDigits(personName).trim(),
      type,
      status: 'unpaid',
      notes: notes ? toLatinDigits(notes).trim() : ''
    });
    
    hapticFeedback("success");
    onSuccess();
  };

  const lenders = ['أحمد الزاكي', 'عباس الزاكي', 'حسين الزاكي', 'علي الزاكي', 'الوالدة', 'الوالد', 'أم حمود', 'أم حسين'];

  return (
    <div className="p-4 space-y-6">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">{language === 'ar' ? 'نظام الديون والقروض' : 'Debts and Loans System'}</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{language === 'ar' ? 'المبلغ (د.ب)' : 'Amount (BHD)'}</label>
          <input 
            type="number" step="0.5" min="0" value={amount} 
            onChange={e => { const v = toLatinDigits(e.target.value); if (v === "" || Number(v) <= 10000) setAmount(v); }} 
            onKeyDown={(e) => { if (['e', 'E', '+', '-'].includes(e.key)) e.preventDefault(); }}
            lang="en" dir="ltr"
            className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-left"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{language === 'ar' ? 'التاريخ' : 'Date'}</label>
          <EnglishDatePicker 
            value={date} 
            onChange={setDate} 
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{language === 'ar' ? 'الطرف الآخر' : 'Other Party'}</label>
          <select 
            value={personName} onChange={e => setPersonName(e.target.value)}
            className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          >
            {lenders.map(l => {
              const display = language === 'en' ? (
                l === 'أحمد الزاكي' ? 'Ahmed Al-Zaki' :
                l === 'عباس الزاكي' ? 'Abbas Al-Zaki' :
                l === 'حسين الزاكي' ? 'Hussain Al-Zaki' :
                l === 'الوالدة' ? 'Mother' :
                l === 'الوالد' ? 'Father' :
                l === 'علي الزاكي' ? 'Ali Al-Zaki' :
                l === 'أم حمود' ? 'Om Hamood' :
                l === 'أم حسين' ? 'Om Hussain' : l
              ) : l;
              return <option key={l} value={l}>{display}</option>;
            })}
            <option value="other">{language === 'ar' ? 'شخص آخر' : 'Someone else'}</option>
          </select>
          {personName === 'other' && (
            <input 
              type="text" placeholder={language === "ar" ? "اسم الشخص" : "Person Name"} 
              onChange={e => setPersonName(e.target.value)}
              className="w-full p-3 mt-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{language === 'ar' ? 'نوع الحالة' : 'Status Type'}</label>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setType('borrowed')}
              className={`flex-1 py-2 px-3 text-sm font-medium rounded-xl border transition-all ${type === 'borrowed' ? 'bg-red-50 border-red-500 text-red-700 dark:bg-red-900/30 dark:border-red-500/50 dark:text-red-400' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300'}`}
            >
              {language === 'ar' ? 'مديونية' : 'Indebtedness'}
            </button>
            <button
              type="button"
              onClick={() => setType('lent')}
              className={`flex-1 py-2 px-3 text-sm font-medium rounded-xl border transition-all ${type === 'lent' ? 'bg-emerald-50 border-emerald-500 text-emerald-700 dark:bg-emerald-900/30 dark:border-emerald-500/50 dark:text-emerald-400' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300'}`}
            >
              {language === 'ar' ? 'إقراض' : 'Lending'}
            </button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{language === 'ar' ? 'ملاحظات (اختياري)' : 'Notes (Optional)'}</label>
          <textarea 
            value={notes} onChange={e => setNotes(e.target.value)}
            className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all min-h-[100px]"
          />
        </div>

        <button 
          type="submit"
          disabled={!amount}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3.5 rounded-xl mt-6 shadow-lg transition-all disabled:opacity-50 disabled:shadow-none"
        >
          حفظ الدين
        </button>
      </form>
    </div>
  );
}
