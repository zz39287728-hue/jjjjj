import React, { useState } from 'react';
import { useStore } from '../store';
import { t } from '../i18n';
import { toLatinDigits, hapticFeedback } from '../utils';
import { motion } from 'motion/react';
import EnglishDatePicker from '../components/EnglishDatePicker';

export default function GeneralExpenseForm({ onSuccess }: { onSuccess: () => void }) {
  const { addGeneralExpense, language } = useStore();
  

  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanAmount = toLatinDigits(amount);
    const cleanTitle = toLatinDigits(title).trim();
    
    const missingFields: string[] = [];
    if (!cleanTitle) missingFields.push(language === 'ar' ? 'نوع المصروف' : 'Expense Type');
    if (!cleanAmount) missingFields.push(language === 'ar' ? 'المبلغ' : 'Amount');

    if (missingFields.length > 0) {
      alert((language === 'ar' ? 'يرجى إكمال الحقول التالية:\n\n' : 'Please complete the following fields:\n\n') + missingFields.map(f => `- ${f}`).join('\n'));
      return;
    }

    await addGeneralExpense({
      amount: parseFloat(cleanAmount) || 0,
      date,
      title: cleanTitle,
      notes: notes ? toLatinDigits(notes).trim() : ''
    });
    
    hapticFeedback("success");
    onSuccess();
  };

  const predefinedExpenses = [
    'بترول', 'عشاء', 'صيانة', 'توصيل', 'أخرى'
  ];

  return (
    <div className="p-4 space-y-6">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">{language === 'ar' ? 'إضافة مصروف جديد' : 'Add New Expense'}</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{language === 'ar' ? 'نوع المصروف' : 'Expense Type'}</label>
          <div className="flex flex-wrap gap-2 mb-3">
            {predefinedExpenses.map(p => {
              const display = language === 'en' ? (
                p === 'بترول' ? 'Petrol' :
                p === 'عشاء' ? 'Dinner' :
                p === 'صيانة' ? 'Maintenance' :
                p === 'توصيل' ? 'Delivery' :
                p === 'أخرى' ? 'Other' : p
              ) : p;
              return (
              <button
                key={p}
                type="button"
                onClick={() => setTitle(p)}
                className={`px-3 py-1.5 text-xs font-medium rounded-xl border transition-all ${title === p ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300'}`}
              >
                {display}
              </button>
            )})}
          </div>
          <input 
            type="text" value={title} onChange={e => setTitle(toLatinDigits(e.target.value))}
            
            className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{language === 'ar' ? 'المبلغ (د.ب)' : 'Amount (BHD)'}</label>
          <input 
            type="number" step="0.5" min="0" value={amount} 
            onChange={e => { const v = toLatinDigits(e.target.value); if (v === "" || Number(v) <= 10000) setAmount(v); }} 
            onKeyDown={(e) => { if (['e', 'E', '+', '-'].includes(e.key)) e.preventDefault(); }}
            lang="en" dir="ltr"
            className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-left"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{language === 'ar' ? 'التاريخ' : 'Date'}</label>
          <EnglishDatePicker 
            value={date} 
            onChange={setDate} 
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{language === 'ar' ? 'ملاحظات (اختياري)' : 'Notes (Optional)'}</label>
          <textarea 
            value={notes} onChange={e => setNotes(e.target.value)}
            className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all min-h-[100px]"
          />
        </div>

        <button 
          type="submit"
          disabled={!amount || !title}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3.5 rounded-xl mt-6 shadow-lg transition-all disabled:opacity-50 disabled:shadow-none"
        >
          حفظ المصروف
        </button>
      </form>
    </div>
  );
}
