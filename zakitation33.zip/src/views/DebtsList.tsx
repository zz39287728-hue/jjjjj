import React, { useState } from 'react';
import { useStore } from '../store';
import { formatBHD, hapticFeedback } from '../utils';
import { CreditCard, CheckCircle2, Circle, Trash2, ArrowRightLeft, User, Calendar, Edit2, Check, X, Archive, ArrowLeft, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GeneralDebt } from '../types';
import { t } from '../i18n';

export default function DebtsList({ type }: { type: 'borrowed' | 'lent' }) {
  const { generalDebts, language, updateGeneralDebt, deleteGeneralDebt } = useStore();
  
  const [showArchived, setShowArchived] = useState(false);
  const activeDebts = generalDebts.filter(d => d.type === type && d.status === 'unpaid');
  const archivedDebts = generalDebts.filter(d => d.type === type && d.status === 'paid');
  
  const displayDebts = showArchived ? archivedDebts : activeDebts;
  
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<GeneralDebt>>({});
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const toggleStatus = (debt: GeneralDebt) => {
    const isPaying = debt.status === 'unpaid';
    updateGeneralDebt(debt.id, { status: isPaying ? 'paid' : 'unpaid' });
    
    if (isPaying) {
      setToastMessage(language === 'ar' ? 'تم نقل السجل إلى الأرشيف' : 'Record moved to archive');
      hapticFeedback('success');
      setTimeout(() => setToastMessage(null), 3000);
    } else {
      hapticFeedback('medium');
    }
  };

  const startEditing = (debt: GeneralDebt) => {
    setEditingId(debt.id);
    setEditForm({ ...debt });
  };

  const saveEdit = async () => {
    if (editingId && editForm.amount && editForm.personName) {
      await updateGeneralDebt(editingId, {
        amount: Number(editForm.amount),
        personName: editForm.personName,
        notes: editForm.notes
      });
      setEditingId(null);
    }
  };

  return (
    <div className="p-4 sm:p-6 pb-24 max-w-4xl mx-auto space-y-6 relative">
      <AnimatePresence>
        {toastMessage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.7, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="bg-white dark:bg-gray-900 rounded-[2rem] p-10 shadow-2xl flex flex-col items-center justify-center aspect-square w-full max-w-[280px] border border-gray-100 dark:border-gray-800"
            >
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 0.1, damping: 12 }}
                className="w-24 h-24 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center mb-6 shadow-lg shadow-emerald-200 dark:shadow-emerald-900/50"
              >
                <Check className="w-12 h-12 text-white" strokeWidth={3} />
              </motion.div>
              <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-2 text-center tracking-tight">
                {language === 'ar' ? 'رائع!' : 'Awesome!'}
              </h3>
              <p className="text-gray-500 dark:text-gray-400 text-center font-medium text-lg leading-tight">
                {toastMessage}
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
          {showArchived ? (
            <Archive className="w-6 h-6 text-gray-500" />
          ) : (
            <CreditCard className={`w-6 h-6 ${type === 'borrowed' ? 'text-red-500' : 'text-emerald-500'}`} />
          )}
          {showArchived 
            ? (language === 'ar' ? 'الأرشيف' : 'Archive')
            : type === 'borrowed' 
              ? (language === 'ar' ? 'سجل الديون (علي)' : 'Debts Record (Borrowed)') 
              : (language === 'ar' ? 'سجل الإقراض (لي)' : 'Loans Record (Lent)')}
        </h1>
        <button 
          onClick={() => setShowArchived(!showArchived)}
          className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-colors ${
            showArchived 
              ? 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-600'
              : 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/50'
          }`}
        >
          {showArchived ? (
            <>
              {language === 'ar' ? 'العودة' : 'Back'}
              <ArrowLeft className="w-4 h-4" />
            </>
          ) : (
            <>
              <Archive className="w-4 h-4" />
              {language === 'ar' ? 'الأرشيف' : 'Archive'}
            </>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <AnimatePresence mode="popLayout" initial={false}>
          {displayDebts.length === 0 ? (
            <motion.div 
              layout
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="text-center py-12 bg-white dark:bg-gray-800 rounded-3xl border border-gray-200 dark:border-gray-700 col-span-1 sm:col-span-2"
            >
              <CreditCard className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
              <p className="text-gray-500 dark:text-gray-400">
                {language === 'ar' 
                  ? showArchived ? 'لا توجد سجلات مؤرشفة' : 'لا يوجد ديون أو قروض مسجلة' 
                  : showArchived ? 'No archived records' : 'No debts or loans recorded'}
              </p>
            </motion.div>
          ) : (
            displayDebts.map(debt => {
              const isBorrowed = debt.type === 'borrowed';
              const isPaid = debt.status === 'paid';
              const isEditing = editingId === debt.id;

              return (
                <motion.div 
                  key={debt.id}
                  layout="position"
                  initial={{ opacity: 0, scale: 0.95, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                  transition={{ duration: 0.25, ease: "easeInOut" }}
                  className={`bg-white dark:bg-gray-800 rounded-2xl p-4 sm:p-5 shadow-sm border transition-all ${
                    isPaid 
                      ? 'border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/50' 
                      : isBorrowed 
                        ? 'border-red-200 dark:border-red-900/50' 
                        : 'border-emerald-200 dark:border-emerald-900/50'
                  }`}
                >
                  {isEditing ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{language === 'ar' ? 'المبلغ' : 'Amount'}</label>
                          <input 
                            type="number" 
                            value={editForm.amount || ''} 
                            onChange={(e) => { const v = e.target.value; if (v === "" || Number(v) <= 10000) setEditForm({...editForm, amount: Number(v)}); }}
                            className="w-full p-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{language === 'ar' ? 'الاسم' : 'Name'}</label>
                          <input 
                            type="text" 
                            value={editForm.personName || ''} 
                            onChange={(e) => setEditForm({...editForm, personName: e.target.value})}
                            className="w-full p-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{language === 'ar' ? 'ملاحظات' : 'Notes'}</label>
                        <input 
                          type="text" 
                          value={editForm.notes || ''} 
                          onChange={(e) => setEditForm({...editForm, notes: e.target.value})}
                          className="w-full p-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl"
                        />
                      </div>
                      <div className="flex gap-2 justify-end mt-2">
                        <button onClick={() => setEditingId(null)} className="p-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                          <X className="w-5 h-5" />
                        </button>
                        <button onClick={saveEdit} className="p-2 text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg">
                          <Check className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
                      <div className="flex items-start gap-4">
                        <button 
                          onClick={() => toggleStatus(debt)}
                          title={isPaid ? (language === 'ar' ? 'استعادة من الأرشيف' : 'Restore from archive') : (language === 'ar' ? 'تحديد كمنتهي (نقل للأرشيف)' : 'Mark as done (Move to archive)')}
                          className={`mt-1 flex-shrink-0 transition-colors ${isPaid ? 'text-emerald-500' : 'text-gray-300 dark:text-gray-600 hover:text-gray-400 dark:hover:text-gray-500'}`}
                        >
                          {isPaid ? <RotateCcw className="w-6 h-6" /> : <Circle className="w-6 h-6" />}
                        </button>
                        
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`text-xs font-bold px-2 py-0.5 rounded-full whitespace-nowrap ${
                              isBorrowed 
                                ? 'bg-red-50 text-red-600 dark:bg-red-900/30 dark:text-red-400' 
                                : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400'
                            }`}>
                              {isBorrowed ? (language === 'ar' ? 'دين (أخذت)' : 'Borrowed') : (language === 'ar' ? 'إقراض (أعطيت)' : 'Lent')}
                            </span>
                            <span className="text-xs text-gray-400 dark:text-gray-500 flex items-center gap-1 whitespace-nowrap">
                              <Calendar className="w-3 h-3" />
                              {debt.date}
                            </span>
                          </div>
                          <h3 className={`text-lg font-bold truncate ${isPaid ? 'text-gray-500 dark:text-gray-400' : 'text-gray-900 dark:text-white'}`}>
                            {debt.personName}
                          </h3>
                          {debt.notes && (
                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 break-words line-clamp-2">{debt.notes}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center justify-between xl:justify-end gap-4 xl:w-auto ps-10 xl:ps-0 border-t xl:border-t-0 border-gray-100 dark:border-gray-700 pt-3 xl:pt-0">
                        <span className={`text-xl font-bold truncate ${isPaid ? 'text-gray-400 dark:text-gray-500' : isBorrowed ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                          {formatBHD(debt.amount)}
                        </span>
                        
                        <div className="flex items-center gap-1 shrink-0">
                          <button 
                            onClick={() => startEditing(debt)}
                            className="p-2.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg transition-colors"
                          >
                            <Edit2 className="w-5 h-5" />
                          </button>
                          <button 
                            onClick={() => {
                              if (confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذا السجل؟' : 'Are you sure you want to delete this record?')) {
                                deleteGeneralDebt(debt.id);
                              }
                            }}
                            className="p-2.5 text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
