const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

c = c.replace(/dev\.sellerPhone\?\.replace\(\/\\D\/g, ''\)/g, "String(dev.sellerPhone).replace(/\\D/g, '')");
c = c.replace(/dev\.buyerPhone\?\.replace\(\/\\D\/g, ''\)/g, "String(dev.buyerPhone).replace(/\\D/g, '')");

fs.writeFileSync('src/views/Inventory.tsx', c);
