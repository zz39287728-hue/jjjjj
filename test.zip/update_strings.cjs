const fs = require('fs');

let c1 = fs.readFileSync('src/components/SellModal.tsx', 'utf8');
c1 = c1.replace(/>BHD<\/span>/g, ">BD</span>");
fs.writeFileSync('src/components/SellModal.tsx', c1);

let c2 = fs.readFileSync('src/i18n.ts', 'utf8');
c2 = c2.replace(/Buy Price \(BHD\)/g, "Buy Price (BD)");
c2 = c2.replace(/Sell Price \(BHD\)/g, "Sell Price (BD)");
c2 = c2.replace(/سعر الشراء \(BHD\)/g, "سعر الشراء (BD)");
c2 = c2.replace(/سعر البيع \(BHD\)/g, "سعر البيع (BD)");
fs.writeFileSync('src/i18n.ts', c2);

