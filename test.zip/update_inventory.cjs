const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

c = c.replace(/import \{ Device \} from '\.\.\/types';/, "import { Device } from '../types';\nimport { ErrorBoundary } from '../components/ErrorBoundary';");

const originalPortal = `<DeviceDetailsModal 
            device={selectedDevice} 
            onClose={() => setSelectedDevice(null)} 
            onImageClick={(img) => setViewingImage(img)}
          />`;

const wrappedPortal = `<ErrorBoundary>
            <DeviceDetailsModal 
              device={selectedDevice} 
              onClose={() => setSelectedDevice(null)} 
              onImageClick={(img) => setViewingImage(img)}
            />
          </ErrorBoundary>`;

c = c.replace(originalPortal, wrappedPortal);
fs.writeFileSync('src/views/Inventory.tsx', c);
