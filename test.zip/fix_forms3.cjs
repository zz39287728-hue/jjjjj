const fs = require('fs');
let c = fs.readFileSync('src/views/FormsView.tsx', 'utf8');

c = c.replace(/import \{ Gamepad2, Briefcase, Disc, Gamepad, Headphones, Wind, MonitorUp, MoreHorizontal, X \} from 'lucide-react';/, "import { Gamepad2, Briefcase, Disc, Gamepad, Headphones, Wind, MonitorUp, MoreHorizontal, X } from 'lucide-react';\nimport { t } from '../i18n';");

fs.writeFileSync('src/views/FormsView.tsx', c);
