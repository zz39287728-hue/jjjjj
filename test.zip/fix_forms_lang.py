import sys

with open('src/views/FormsView.tsx', 'r') as f:
    content = f.read()

def r(target, rep):
    global content
    content = content.replace(target, rep)

r(">شراء جهاز جديد<", ">{t('buy_new_device', language)}<")
r(">تسجيل شراء جهاز بلايستيشن جديد<", ">{t('record_purchase', language)}<")
r(">العنوان (للتعرف عليه)<", ">{t('title', language)}<")
r('placeholder="مثال: بلايستيشن 5 نظيف جداً"', 'placeholder={language === "ar" ? "مثال: بلايستيشن 5 نظيف جداً" : "e.g. Clean PS5"}')
r(">موديل الجهاز<", ">{t('model', language)}<")
r(">رقمي (Digital)<", ">{t('digital', language)}<")
r(">أقراص (Disk)<", ">{t('disk', language)}<")
r(">الإضافات (اختياري)<", ">{t('extras_included', language)}<")
r(">حقيبة<", ">{t('bag', language)}<")
r(">جهاز تحكم إضافي<", ">{t('extra_controller', language)}<")
r(">شريط إضافي<", ">{t('cd', language)}<")
r(">سماعة<", ">{t('headset', language)}<")
r(">مبرد<", ">{t('cooler', language)}<")
r(">قاعدة<", ">{t('stand', language)}<")
r(">أخرى<", ">{t('other', language)}<")
r('placeholder="اسم الشريط (مثال: FIFA 24)"', 'placeholder={t("cd_name", language)}')
r('placeholder="اسم الإضافة الأخرى (مثال: سلك، غلاف)"', 'placeholder={t("other_name", language)}')
r(">سعر الشراء (د.ب)<", ">{t('buy_price', language)}<")
r(">تاريخ الشراء<", ">{t('buy_date', language)}<")
r(">المنطقة (اختياري)<", ">{t('purchase_area', language)}<")
r('placeholder="مثال: المنامة"', 'placeholder={language === "ar" ? "مثال: المنامة" : "e.g. Manama"}')
r(">صورة المحادثة (اختياري)<", ">{t('chat_screenshot', language)}<")
r(">حفظ الجهاز<", ">{t('save_device', language)}<")

with open('src/views/FormsView.tsx', 'w') as f:
    f.write(content)

print("FormsView language updated.")
