import sys

with open('src/types.ts', 'r') as f:
    content = f.read()

app_error_type = """
export interface AppError {
  id: string;
  code: string;
  message: string;
  timestamp: string;
  details?: string;
  path?: string;
}
"""

if "export interface AppError" not in content:
    content += app_error_type
    with open('src/types.ts', 'w') as f:
        f.write(content)
    print("Added AppError type")
