const fs = require('fs');
let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

const calculateDebt = `  const inventoryValue = inStockDevices.reduce((sum, d) => sum + d.buyPrice, 0);
  const totalDebt = devices.reduce((sum, d) => sum + (d.loanStatus === 'unpaid' && d.loanAmount ? d.loanAmount : 0), 0);`;

c = c.replace(/  const inventoryValue = inStockDevices\.reduce\(\(sum, d\) => sum \+ d\.buyPrice, 0\);/, calculateDebt);

const displayDebt = `          <div className="bg-white dark:bg-gray-800 p-4 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 flex items-center justify-between">
            <div>
              <p className="text-gray-500 dark:text-gray-400 text-sm font-medium mb-1">{t('total_debt', language)}</p>
              <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100">{formatBHD(totalDebt)}</h3>
            </div>
            <div className="w-12 h-12 bg-red-50 dark:bg-red-900/30 rounded-2xl flex items-center justify-center text-red-600 dark:text-red-400">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>`;

c = c.replace(/        <\/div>\n\n        <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 shadow-sm border border-gray-100 dark:border-gray-800">/, displayDebt + '\n\n        <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 shadow-sm border border-gray-100 dark:border-gray-800">');

fs.writeFileSync('src/views/Dashboard.tsx', c);
