console.log("Checking rules idea");
