const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

// Fix FirebaseProvider
c = c.replace(/const workspaceId = useStore\.getState\(\)\.activeWorkspaceId \|\| user\.uid;/g, 
  "const workspaceId = activeWorkspaceId || user.uid;");

// Fix Zustand methods
c = c.replace(/useStore\.getState\(\)\.activeWorkspaceId \|\| user\.uid/g, 
  "get().activeWorkspaceId || user.uid");
  
c = c.replace(/activeWorkspaceId \|\| user\.uid\],/g, "activeWorkspaceId || user.uid],"); // Cleanup any mistakes

// The second error in store.tsx(116,13): Cannot find name 'activeWorkspaceId'.
c = c.replace(/  \}, \[user, activeWorkspaceId\]\);/g, "  }, [user, activeWorkspaceId]);");

fs.writeFileSync('src/store.tsx', c);
