const fs = require('fs');
let c = fs.readFileSync('src/i18n.ts', 'utf8');

c = c.replace(/extra_profit: 'Extra Profit'/, "extra_profit: 'Extra Profit',\n    loan_financing: 'Financing Method',\n    personal_money: 'Personal Money',\n    loan_money: 'Loan / Debt',\n    lender: 'Lender',\n    loan_amount: 'Loan Amount',\n    lender_abbas: 'Abbas',\n    lender_ali: 'Ali',\n    lender_mother: 'Mother',\n    lender_father: 'Father',\n    lender_hussain: 'Hussain',\n    lender_om_hamood: 'Om Hamood',\n    lender_om_hussain: 'Om Hussain',\n    loan_status: 'Loan Status',\n    unpaid: 'Unpaid',\n    paid: 'Paid',\n    total_debt: 'Total Debt'");

c = c.replace(/extra_profit: 'أرباح إضافية'/, "extra_profit: 'أرباح إضافية',\n    loan_financing: 'طريقة التمويل',\n    personal_money: 'مال شخصي',\n    loan_money: 'سلفة / دين',\n    lender: 'المقرض',\n    loan_amount: 'مبلغ السلفة',\n    lender_abbas: 'عباس',\n    lender_ali: 'علي',\n    lender_mother: 'الوالدة',\n    lender_father: 'الوالد',\n    lender_hussain: 'حسين',\n    lender_om_hamood: 'أم حمود',\n    lender_om_hussain: 'أم حسين',\n    loan_status: 'حالة الدين',\n    unpaid: 'غير مسدد',\n    paid: 'مسدد',\n    total_debt: 'إجمالي الديون'");

fs.writeFileSync('src/i18n.ts', c);
