import sys

with open('firestore.rules', 'r') as f:
    content = f.read()

rule_to_add = """
    match /appErrors/{errorId} {
      allow create: if isSignedIn();
      allow read: if isSignedIn();
      allow delete: if isSignedIn();
    }
  }
}"""

if "match /appErrors" not in content:
    content = content.replace("  }\n}", rule_to_add)
    with open('firestore.rules', 'w') as f:
        f.write(content)
    print("Added appErrors to firestore.rules")
else:
    print("appErrors already in firestore.rules")
