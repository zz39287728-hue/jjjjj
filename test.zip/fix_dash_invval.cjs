const fs = require('fs');
let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

const newTotalSales = `  const totalSales = soldDevices.reduce((sum, d) => {
    const extraProfit = d.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
    return sum + (d.sellPrice || 0) + extraProfit;
  }, 0);
  
  const inventoryValue = inStockDevices.reduce((sum, d) => sum + d.buyPrice, 0);`;

c = c.replace(/const totalSales = [\s\S]*?\}, 0\);/, newTotalSales);

fs.writeFileSync('src/views/Dashboard.tsx', c);
