import sys
import re

with open('src/views/Dashboard.tsx', 'r') as f:
    content = f.read()

# Add Trophy and ChevronDown to lucide-react imports
if "Trophy" not in content:
    content = content.replace("ReceiptText, X } from 'lucide-react';", "ReceiptText, X, Trophy, ChevronDown } from 'lucide-react';")

# Add state
if "const [showTopProfitable, setShowTopProfitable] = useState(false);" not in content:
    content = content.replace("const [timeFilter, setTimeFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');", "const [timeFilter, setTimeFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');\n  const [showTopProfitable, setShowTopProfitable] = useState(false);")

# Add useMemo for topProfitableDevices
top_devices_code = """
  const topProfitableDevices = useMemo(() => {
    return devices
      .filter(d => d.status === 'sold')
      .map(d => ({
        ...d,
        profit: (d.sellPrice || 0) - d.buyPrice
      }))
      .filter(d => d.profit > 0)
      .sort((a, b) => b.profit - a.profit);
  }, [devices]);
"""
if "const topProfitableDevices = useMemo" not in content:
    content = content.replace("const recentTransactions = useMemo(() => {", top_devices_code + "\n  const recentTransactions = useMemo(() => {")

# Insert UI section
ui_section = """
      {/* Top Profitable Devices Option */}
      <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden mb-6">
        <button 
          onClick={() => { setShowTopProfitable(!showTopProfitable); }} 
          className="w-full p-5 sm:p-6 flex justify-between items-center bg-gradient-to-r from-indigo-50/50 to-purple-50/50 hover:from-indigo-50 hover:to-purple-50 dark:from-indigo-900/10 dark:to-purple-900/10 dark:hover:from-indigo-900/20 dark:hover:to-purple-900/20 transition-all text-right"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-yellow-100 to-amber-100 dark:from-yellow-900/40 dark:to-amber-900/40 flex items-center justify-center text-yellow-600 dark:text-yellow-500 shadow-sm">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900 dark:text-gray-100 text-lg mb-0.5">{language === 'ar' ? 'أكثر الأجهزة ربحاً' : 'Top Profitable Devices'}</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400">{language === 'ar' ? 'ما هو أكثر بلايستيشن حصلنا على فائدة منه؟' : 'Which PlayStation gave us the highest profit?'}</p>
            </div>
          </div>
          <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${showTopProfitable ? 'rotate-180' : ''}`} />
        </button>

        <AnimatePresence>
          {showTopProfitable && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              className="overflow-hidden border-t border-gray-100 dark:border-gray-700 bg-gray-50/30 dark:bg-gray-800/30"
            >
              <div className="p-4 sm:p-5 flex flex-col gap-3">
                {topProfitableDevices.length === 0 ? (
                  <p className="text-center text-gray-500 text-sm py-6">{language === 'ar' ? 'لا توجد أجهزة مباعة بربح بعد.' : 'No profitable sold devices yet.'}</p>
                ) : (
                  topProfitableDevices.map((dev, idx) => (
                    <div key={dev.id} className="flex justify-between items-center p-3.5 bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 transition-all hover:border-indigo-200 dark:hover:border-indigo-800">
                       <div className="flex items-center gap-3.5">
                         <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${idx === 0 ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/50 dark:text-yellow-400' : idx === 1 ? 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300' : idx === 2 ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-500' : 'bg-gray-50 text-gray-500 dark:bg-gray-800 dark:text-gray-400 border border-gray-200 dark:border-gray-700'}`}>
                           #{idx + 1}
                         </div>
                         <div className="text-right">
                           <h4 className="font-bold text-sm text-gray-900 dark:text-gray-100 leading-tight mb-1">{dev.title}</h4>
                           <p className="text-[10px] text-gray-500">{dev.model} • {dev.sellDate}</p>
                         </div>
                       </div>
                       <div className="text-left flex flex-col items-end justify-center">
                         <span className="font-bold text-emerald-600 dark:text-emerald-400 text-sm">+{formatBHD(dev.profit)}</span>
                         <span className="text-[10px] text-emerald-600/70 dark:text-emerald-400/70 font-medium">{language === 'ar' ? 'فائدة' : 'Profit'}</span>
                       </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
"""
if "أكثر الأجهزة ربحاً" not in content:
    content = content.replace("{/* Recent Transactions */}", ui_section + "\n      {/* Recent Transactions */}")

with open('src/views/Dashboard.tsx', 'w') as f:
    f.write(content)

print("Added top profitable devices section.")
