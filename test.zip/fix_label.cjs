const fs = require('fs');
let c = fs.readFileSync('src/views/FormsView.tsx', 'utf8');
c = c.replace(/<label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">رقم هاتف البائع \(اختياري\)<\/label>/g, '<label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t(\'seller_phone\', language)}</label>');
c = c.replace(/placeholder="مثال: 33334444"/g, "placeholder=\"33334444\"");
fs.writeFileSync('src/views/FormsView.tsx', c);
