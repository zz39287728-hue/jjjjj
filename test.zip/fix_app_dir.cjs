const fs = require('fs');
let c = fs.readFileSync('src/App.tsx', 'utf8');
c = c.replace(/const \{ language \} = useStore\(\);/, "const { language } = useStore();\n  React.useEffect(() => {\n    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';\n  }, [language]);");
fs.writeFileSync('src/App.tsx', c);
