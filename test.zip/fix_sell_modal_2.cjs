const fs = require('fs');
let c = fs.readFileSync('src/components/SellModal.tsx', 'utf8');

c = c.replace(/<div className="border-t border-gray-100 dark:border-gray-800 my-4 pt-4">\n              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اسم المشتري<\/label>/, '<label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">اسم المشتري</label>');

fs.writeFileSync('src/components/SellModal.tsx', c);
