const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/const \[area, setArea\] = useState\(device\.area \|\| ''\);/, "const [area, setArea] = useState(device.area || '');\n  const [sellerName, setSellerName] = useState(device.sellerName || '');");

c = c.replace(/area,\n\s*sellerPhone,/, "area,\n      sellerName,\n      sellerPhone,");

const editSellerName = `                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 mb-1">{t('seller_name', language)}</label>
                    <input type="text" value={sellerName} onChange={e => setSellerName(e.target.value)} className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 mb-1">{t('seller_phone', language)}</label>`;

c = c.replace(/<div>\n\s*<label className="block text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 mb-1">رقم هاتف البائع<\/label>/, editSellerName);

const viewSellerName = `                {(device.sellerName || device.sellerPhone || device.area || device.chatImage) ? (
                  <div className="space-y-3">
                    {device.sellerName && (
                      <div className="flex items-center text-sm text-gray-700 dark:text-gray-300">
                        <User className="w-4 h-4 me-2 text-gray-400 dark:text-gray-500" />
                        <span className="text-gray-500 dark:text-gray-400 dark:text-gray-500 w-16">{t('seller_name', language)}:</span> {device.sellerName}
                      </div>
                    )}`;

c = c.replace(/\{\(device\.sellerPhone \|\| device\.area \|\| device\.chatImage\) \? \(\n\s*<div className="space-y-3">/, viewSellerName);

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
