const fs = require('fs');

function addMotionToSettings() {
  let c = fs.readFileSync('src/components/SettingsModal.tsx', 'utf8');
  if (!c.includes('motion/react')) {
    c = c.replace(/import \{ t \} from '\.\.\/i18n';/, "import { t } from '../i18n';\nimport { motion } from 'motion/react';");
    
    // Replace backdrop
    c = c.replace(/<div className="fixed inset-0 z-50 bg-black\/40 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">/g,
      '<motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">');
    
    // Replace modal body
    c = c.replace(/<div className="bg-white dark:bg-gray-800 w-full max-w-md rounded-3xl shadow-2xl overflow-hidden max-h-\[85vh\] flex flex-col">/g,
      '<motion.div initial={{ opacity: 0, y: 50, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 50, scale: 0.95 }} className="bg-white dark:bg-gray-800 w-full max-w-md rounded-3xl shadow-2xl overflow-hidden max-h-[85vh] flex flex-col">');

    c = c.replace(/<\/div>\n    <\/div>/, '</motion.div>\n    </motion.div>');
    fs.writeFileSync('src/components/SettingsModal.tsx', c);
    console.log("Updated SettingsModal");
  }
}

function addMotionToDeviceDetails() {
  let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');
  if (!c.includes('motion/react')) {
    c = c.replace(/import \{ t \} from '\.\.\/i18n';/, "import { t } from '../i18n';\nimport { motion } from 'motion/react';");
    
    // Backdrop
    c = c.replace(/<div className="fixed inset-0 bg-black\/40 backdrop-blur-sm z-50 flex justify-center items-end sm:items-center p-0 sm:p-4">/g,
      '<motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex justify-center items-end sm:items-center p-0 sm:p-4">');
    
    // Body
    c = c.replace(/<div className="bg-gray-50 dark:bg-gray-900 w-full max-w-2xl rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-\[90vh\] flex flex-col">/g,
      '<motion.div initial={{ opacity: 0, y: 50, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 50, scale: 0.95 }} className="bg-gray-50 dark:bg-gray-900 w-full max-w-2xl rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">');

    // Close
    c = c.replace(/<\/div>\n    <\/div>/, '</motion.div>\n    </motion.div>');
    fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
    console.log("Updated DeviceDetailsModal");
  }
}

addMotionToSettings();
addMotionToDeviceDetails();
