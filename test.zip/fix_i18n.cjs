const fs = require('fs');
let c = fs.readFileSync('src/i18n.ts', 'utf8');

const newEn = `    exp_delivery: 'Delivery/Pickup Trip',
    exp_other: 'Other',
    manage_extras: 'Manage Kept Extras',
    action_sold: 'Sold (Extra Profit)',
    action_gifted: 'Gifted',
    action_kept: 'Kept (Personal Use)',
    action_pending: 'Pending',
    extra_sale_price: 'Price',
    extra_notes: 'Notes (e.g. gifted to brother)',
    extra_profit: 'Extra Profit'
  },`;

const newAr = `    exp_delivery: 'مشوار استلام/تسليم',
    exp_other: 'أخرى',
    manage_extras: 'إدارة الإضافات المتبقية',
    action_sold: 'مُباع (ربح إضافي)',
    action_gifted: 'تم إهداؤه',
    action_kept: 'احتفاظ شخصي',
    action_pending: 'قيد الانتظار',
    extra_sale_price: 'سعر البيع',
    extra_notes: 'ملاحظات (مثال: هدية لأخي)',
    extra_profit: 'أرباح إضافية'
  }
};`;

c = c.replace(/    exp_delivery: 'Delivery\/Pickup Trip',\n    exp_other: 'Other'\n  \},/, newEn);
c = c.replace(/    exp_delivery: 'مشوار استلام\/تسليم',\n    exp_other: 'أخرى'\n  \}\n\};/, newAr);

fs.writeFileSync('src/i18n.ts', c);
