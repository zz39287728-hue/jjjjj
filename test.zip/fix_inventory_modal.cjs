const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

const modalRenderFixed = `      <AnimatePresence>
        {selectedDevice && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 pointer-events-auto"
            onClick={() => setSelectedDevice(null)}
          >
            <div className="bg-transparent w-full h-full absolute inset-0" />
            <div onClick={e => e.stopPropagation()} className="w-full max-w-[400px] h-full flex flex-col justify-end sm:justify-center z-10">
              <ErrorBoundary>
                <DeviceDetailsModal 
                  device={selectedDevice} 
                  onClose={() => setSelectedDevice(null)} 
                  onImageClick={(img) => setViewingImage(img)}
                />
              </ErrorBoundary>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deviceToDelete && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 pointer-events-auto"
            onClick={() => setDeviceToDelete(null)}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              className="bg-white dark:bg-gray-800 rounded-2xl p-6 w-full max-w-sm shadow-2xl relative z-10"
              onClick={e => e.stopPropagation()}
            >
              <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">حذف الجهاز</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6 text-sm">هل أنت متأكد من أنك تريد أن تحذف هذه العملية؟</p>
              <div className="flex space-x-3 space-x-reverse">
                <button 
                  onClick={() => setDeviceToDelete(null)}
                  className="flex-1 py-2.5 rounded-xl font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  إلغاء
                </button>
                <button 
                  onClick={() => {
                    deleteDevice(deviceToDelete.id);
                    setDeviceToDelete(null);
                  }}
                  className="flex-1 py-2.5 rounded-xl font-medium text-white bg-red-600 hover:bg-red-700 transition-colors shadow-sm shadow-red-200 dark:shadow-none"
                >
                  حذف
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>`;

c = c.replace(/      <AnimatePresence>\n        \{selectedDevice && \(\n          <ErrorBoundary>\n            <DeviceDetailsModal [\s\S]*?      <\/AnimatePresence>/, modalRenderFixed);

fs.writeFileSync('src/views/Inventory.tsx', c);
