const React = require('react');
const { renderToString } = require('react-dom/server');
require('ts-node').register({
  compilerOptions: { module: 'commonjs', jsx: 'react' }
});

const DeviceDetailsModal = require('./src/components/DeviceDetailsModal.tsx').default;

const mockDevice = {
  id: '1',
  title: 'Test',
  model: 'Model',
  status: 'sold',
  buyPrice: 100,
  buyDate: '2023-01-01',
  sellPrice: 150,
  sellDate: '2023-02-01',
  buyerName: 'John',
  soldExtras: ['Bag'],
  expenses: [],
  extras: ['Bag']
};

const StoreContext = require('./src/store').StoreContext;

const MockProvider = ({children}) => {
  return React.createElement(StoreContext.Provider, { value: { updateDevice: () => {}, language: 'ar' } }, children);
};

try {
  renderToString(
    React.createElement(MockProvider, null, 
      React.createElement(DeviceDetailsModal, { device: mockDevice, onClose: () => {}, onImageClick: () => {} })
    )
  );
  console.log("RENDER SUCCESS!");
} catch (e) {
  console.error("RENDER FAILED:", e);
}
