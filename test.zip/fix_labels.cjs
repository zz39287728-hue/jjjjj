const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/<h4 className="font-semibold text-gray-900 dark:text-gray-100">معلومات الشراء<\/h4>/g, 
              '{isSold ? <h4 className="font-semibold text-gray-900 dark:text-gray-100">معلومات البائع</h4> : <h4 className="font-semibold text-gray-900 dark:text-gray-100">معلومات الشراء (البائع)</h4>}');

c = c.replace(/<h4 className="font-semibold text-gray-900 dark:text-gray-100">معلومات البيع<\/h4>/g, 
              '<h4 className="font-semibold text-gray-900 dark:text-gray-100">معلومات المشتري</h4>');

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
