const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

c = c.replace(/import \{ motion, AnimatePresence \} from 'motion\/react';/, "import { motion, AnimatePresence } from 'motion/react';\nimport { createPortal } from 'react-dom';");

const replaceModals = `      <AnimatePresence>
        {selectedDevice && document.getElementById('modal-root') && createPortal(
          <DeviceDetailsModal 
            device={selectedDevice} 
            onClose={() => setSelectedDevice(null)} 
            onImageClick={(img) => setViewingImage(img)}
          />,
          document.getElementById('modal-root')!
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deviceToDelete && document.getElementById('modal-root') && createPortal(
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[60] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 pointer-events-auto"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              className="bg-white dark:bg-gray-800 rounded-2xl p-6 w-full max-w-sm shadow-2xl"
            >
              <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">حذف الجهاز</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6 text-sm">هل أنت متأكد من أنك تريد أن تحذف هذه العملية؟</p>
              <div className="flex space-x-3 space-x-reverse">
                <button 
                  onClick={() => setDeviceToDelete(null)}
                  className="flex-1 py-2.5 rounded-xl font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  إلغاء
                </button>
                <button 
                  onClick={() => {
                    deleteDevice(deviceToDelete.id);
                    setDeviceToDelete(null);
                  }}
                  className="flex-1 py-2.5 rounded-xl font-medium text-white bg-red-600 hover:bg-red-700 transition-colors shadow-sm shadow-red-200 dark:shadow-none"
                >
                  حذف
                </button>
              </div>
            </motion.div>
          </motion.div>,
          document.getElementById('modal-root')!
        )}
      </AnimatePresence>
    </div>
  );
}`;

c = c.replace(/      <AnimatePresence>\n        \{selectedDevice && \([\s\S]*?\n  \);\n\}/, replaceModals);

fs.writeFileSync('src/views/Inventory.tsx', c);
