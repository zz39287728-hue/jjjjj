const fs = require('fs');
let c = fs.readFileSync('src/types.ts', 'utf8');

const newTypes = `export interface Expense {
  id: string;
  type: 'petrol_dad' | 'petrol' | 'dinner_abbas' | 'maintenance' | 'delivery' | 'other';
  amount: number;
  customName?: string;
}

export interface Device {`;

c = c.replace(/export interface Device \{/, newTypes);
c = c.replace(/soldExtras\?: string\[\];\n\}/, "soldExtras?: string[];\n  expenses?: Expense[];\n}");

fs.writeFileSync('src/types.ts', c);
