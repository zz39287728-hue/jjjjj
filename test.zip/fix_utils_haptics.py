import sys

with open('src/utils.ts', 'r') as f:
    content = f.read()

haptics_code = """
export const hapticFeedback = (type: 'light' | 'medium' | 'heavy' | 'success' | 'error' = 'light') => {
  if (typeof window !== 'undefined' && window.navigator && window.navigator.vibrate) {
    try {
      switch(type) {
        case 'light': window.navigator.vibrate(10); break;
        case 'medium': window.navigator.vibrate(20); break;
        case 'heavy': window.navigator.vibrate(40); break;
        case 'success': window.navigator.vibrate([15, 50, 20]); break;
        case 'error': window.navigator.vibrate([50, 50, 50]); break;
      }
    } catch (e) {
      // ignore
    }
  }
};
"""

if "export const hapticFeedback" not in content:
    with open('src/utils.ts', 'a') as f:
        f.write(haptics_code)
    print("Added haptics to utils.ts")
else:
    print("Haptics already present.")
