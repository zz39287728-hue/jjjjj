const fs = require('fs');
let c = fs.readFileSync('src/views/FormsView.tsx', 'utf8');

c = c.replace(/import \{ Device \} from '\.\.\/types';/, "import { Device, Expense } from '../types';\nimport { Receipt, Trash2 } from 'lucide-react';");

c = c.replace(/const \[sellerPhone, setSellerPhone\] = useState\(''\);/, "const [sellerPhone, setSellerPhone] = useState('');\n  const [expenses, setExpenses] = useState<Expense[]>([]);");

const newSave = `      ...(sellerName && { sellerName }),
      ...(sellerPhone && { sellerPhone }),
      ...(chatImage && { chatImage }),
      ...(expenses.length > 0 && { expenses }),`;

c = c.replace(/\.\.\.\(sellerName && \{ sellerName \}\),\n\s*\.\.\.\(sellerPhone && \{ sellerPhone \}\),\n\s*\.\.\.\(chatImage && \{ chatImage \}\),/, newSave);

c = c.replace(/setSellerName\(''\);\n\s*setSellerPhone\(''\);/, "setSellerName('');\n    setSellerPhone('');\n    setExpenses([]);");

const addExpenseSection = `        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 mb-6">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 rounded-full bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center me-3 text-indigo-600 dark:text-indigo-400">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-800 dark:text-gray-200">{t('expenses', language)}</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">أي مصاريف إضافية (بترول، صيانة، إلخ)</p>
            </div>
          </div>
          
          <div className="space-y-3">
            {expenses.map((exp, idx) => (
              <div key={exp.id} className="flex gap-2 items-center bg-gray-50 dark:bg-gray-700/50 p-3 rounded-xl border border-gray-100 dark:border-gray-700">
                <select 
                  value={exp.type}
                  onChange={(e) => {
                    const newExp = [...expenses];
                    newExp[idx].type = e.target.value as any;
                    setExpenses(newExp);
                  }}
                  className="flex-1 p-3 text-sm bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  <option value="petrol_dad">{t('exp_petrol_dad', language)}</option>
                  <option value="petrol">{t('exp_petrol', language)}</option>
                  <option value="dinner_abbas">{t('exp_dinner_abbas', language)}</option>
                  <option value="maintenance">{t('exp_maintenance', language)}</option>
                  <option value="delivery">{t('exp_delivery', language)}</option>
                  <option value="other">{t('exp_other', language)}</option>
                </select>
                
                {exp.type === 'other' && (
                  <input 
                    type="text"
                    placeholder={t('expense_custom_name', language)}
                    value={exp.customName || ''}
                    onChange={(e) => {
                      const newExp = [...expenses];
                      newExp[idx].customName = e.target.value;
                      setExpenses(newExp);
                    }}
                    className="flex-1 p-3 text-sm bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                )}
                
                <input 
                  type="number"
                  placeholder={t('expense_amount', language)}
                  value={exp.amount || ''}
                  onChange={(e) => {
                    const newExp = [...expenses];
                    newExp[idx].amount = parseFloat(e.target.value) || 0;
                    setExpenses(newExp);
                  }}
                  className="w-24 p-3 text-sm bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                
                <button 
                  type="button" 
                  onClick={() => setExpenses(expenses.filter((_, i) => i !== idx))} 
                  className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 p-3 rounded-lg transition-colors border border-transparent hover:border-red-100 dark:hover:border-red-900/50"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))}
            
            <button
              type="button"
              onClick={() => setExpenses([...expenses, { id: Date.now().toString(), type: 'other', amount: 0 }])}
              className="w-full py-4 border-2 border-dashed border-gray-200 dark:border-gray-700 text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:border-indigo-300 dark:hover:border-indigo-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-xl transition-all font-medium flex items-center justify-center"
            >
              + {t('add_expense', language)}
            </button>
          </div>
        </div>

        <button`;

c = c.replace(/<button\n\s*type="submit"/, addExpenseSection);

fs.writeFileSync('src/views/FormsView.tsx', c);
