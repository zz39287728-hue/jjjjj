const fs = require('fs');
let c = fs.readFileSync('src/App.tsx', 'utf8');

c = c.replace(/\{React\.cloneElement\(icon as React\.ReactElement, \{ className: 'w-5 h-5' \}\)\}/, 
  "{React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { className: 'w-5 h-5' }) : icon}");

fs.writeFileSync('src/App.tsx', c);
