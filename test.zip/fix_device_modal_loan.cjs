const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

const loanFieldsState = `  const [expenses, setExpenses] = useState<Expense[]>(device.expenses || []);
  const [loanStatus, setLoanStatus] = useState(device.loanStatus || 'unpaid');`;

c = c.replace(/  const \[expenses, setExpenses\] = useState<Expense\[\]>\(device\.expenses \|\| \[\]\);/, loanFieldsState);

const saveUpdates = `    const updates: Partial<Device> = {
      title,
      model,
      buyPrice: parseFloat(buyPrice) || 0,
      buyDate,
      area,
      sellerName,
      sellerPhone,
      expenses,
      extraActions,
      notes,
      extras: currentExtrasList,
      loanStatus,
    };`;

c = c.replace(/    const updates: Partial<Device> = \{\n      title,\n      model,\n      buyPrice: parseFloat\(buyPrice\) \|\| 0,\n      buyDate,\n      area,\n      sellerName,\n      sellerPhone,\n      expenses,\n      extraActions,\n      notes,\n      extras: currentExtrasList,\n    \};/, saveUpdates);

const loanInfoRender = `              </div>

              {device.loanAmount ? (
                <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border border-indigo-100 dark:border-indigo-900/30">
                  <h4 className="text-sm font-bold text-gray-900 dark:text-gray-100 mb-3">{t('loan_money', language)}</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('loan_amount', language)}</p>
                      <p className="font-bold text-gray-900 dark:text-gray-100 text-lg">{formatBHD(device.loanAmount)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('lender', language)}</p>
                      <p className="font-bold text-gray-900 dark:text-gray-100 text-lg">{t(device.loanLender as keyof typeof translations.en, language)}</p>
                    </div>
                    {isEditing ? (
                      <div className="col-span-2 mt-2">
                        <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('loan_status', language)}</label>
                        <select 
                          value={loanStatus} 
                          onChange={e => setLoanStatus(e.target.value as 'unpaid' | 'paid')} 
                          className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                        >
                          <option value="unpaid">{t('unpaid', language)}</option>
                          <option value="paid">{t('paid', language)}</option>
                        </select>
                      </div>
                    ) : (
                      <div className="col-span-2 mt-2">
                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('loan_status', language)}</p>
                        <span className={\`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium \${device.loanStatus === 'paid' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400'}\`}>
                          {t(device.loanStatus as keyof typeof translations.en || 'unpaid', language)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              ) : null}

              <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-800 overflow-hidden">`;

c = c.replace(/              <\/div>\n\n              <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-800 overflow-hidden">/, loanInfoRender);

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
