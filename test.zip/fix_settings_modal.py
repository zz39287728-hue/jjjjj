import sys

with open('src/components/SettingsModal.tsx', 'r') as f:
    content = f.read()

# Add AppError import if needed. But we actually just need to use `useStore` to get `errors` and `clearErrors`.
if "errors," not in content and "clearErrors" not in content:
    content = content.replace("const { language, setLanguage, theme, setTheme, devices, generalExpenses, importDevices, activeWorkspaceId, generateInviteCode, joinWorkspace, clearWorkspace } = useStore();", "const { language, setLanguage, theme, setTheme, devices, generalExpenses, importDevices, activeWorkspaceId, generateInviteCode, joinWorkspace, clearWorkspace, errors, clearErrors } = useStore();")
    
# Add bug icon to lucide-react
if "Bug" not in content:
    content = content.replace("LogOut, FileText } from 'lucide-react';", "LogOut, FileText, Bug } from 'lucide-react';")

error_logs_section = """
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
              <Bug className="w-4 h-4" />
              {language === 'ar' ? 'سجل الأخطاء' : 'Error Logs'}
            </h3>
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-2 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col max-h-[300px] overflow-y-auto">
              {errors.length === 0 ? (
                <div className="p-4 text-center text-sm text-gray-500">
                  {language === 'ar' ? 'لا توجد أخطاء مسجلة.' : 'No errors logged.'}
                </div>
              ) : (
                <>
                  <div className="p-2 flex justify-between items-center border-b border-gray-100 dark:border-gray-700 mb-2">
                    <span className="text-xs text-gray-500">{errors.length} {language === 'ar' ? 'أخطاء' : 'Errors'}</span>
                    <button 
                      onClick={() => clearErrors()}
                      className="text-xs text-red-500 font-bold hover:text-red-700"
                    >
                      {language === 'ar' ? 'مسح السجل' : 'Clear Logs'}
                    </button>
                  </div>
                  <div className="space-y-2">
                    {errors.map(err => (
                      <div key={err.id} className="p-2 bg-red-50 dark:bg-red-900/10 rounded-lg text-left" dir="ltr">
                        <div className="flex justify-between items-start">
                          <span className="font-mono text-xs font-bold text-red-600 dark:text-red-400">{err.code}</span>
                          <span className="text-[10px] text-gray-400">{new Date(err.timestamp).toLocaleString()}</span>
                        </div>
                        <p className="text-xs text-gray-700 dark:text-gray-300 mt-1 break-words">{err.message}</p>
                        {err.path && <p className="text-[10px] text-gray-500 mt-1 border-t border-red-100 dark:border-red-900/30 pt-1">Path: {err.path}</p>}
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
"""

# Insert before "Account" section
target = """          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
              <LogOut className="w-4 h-4" />"""

if target in content:
    content = content.replace(target, error_logs_section + "\n" + target)
    with open('src/components/SettingsModal.tsx', 'w') as f:
        f.write(content)
    print("Added Error Logs to SettingsModal")
else:
    print("Could not find target in SettingsModal")
