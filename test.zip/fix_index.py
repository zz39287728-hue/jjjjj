import sys

with open('index.html', 'r') as f:
    content = f.read()

content = content.replace(
    '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />',
    '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />'
)

# Fix double theme-color
if content.count('<meta name="theme-color"') > 1:
    content = content.replace('<meta name="theme-color" content="#f9fafb" />\n', '')

with open('index.html', 'w') as f:
    f.write(content)
print("Updated index.html viewport for full screen")
