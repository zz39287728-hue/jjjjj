import sys

with open('src/views/Dashboard.tsx', 'r') as f:
    content = f.read()

top_devices_code = """
  const topProfitableDevices = useMemo(() => {
    return devices
      .filter(d => d.status === 'sold')
      .map(d => ({
        ...d,
        profit: (d.sellPrice || 0) - d.buyPrice
      }))
      .filter(d => d.profit > 0)
      .sort((a, b) => b.profit - a.profit);
  }, [devices]);
"""
if "const topProfitableDevices = useMemo" not in content:
    content = content.replace("const filteredTransactions = useMemo(() => {", top_devices_code + "\n  const filteredTransactions = useMemo(() => {")

with open('src/views/Dashboard.tsx', 'w') as f:
    f.write(content)

print("Added topProfitableDevices definition.")
