const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

c = c.replace(/  const \[activeWorkspaceId, setActiveWorkspaceId\] = useState<string>\(''\);\s*/, "");

fs.writeFileSync('src/store.tsx', c);
