const fs = require('fs');

let c = fs.readFileSync('src/App.tsx', 'utf8');

if (c.includes('<button onClick={() => setShowSettings(true)}')) {
    c = c.replace(/<button onClick=\{\(\) => setShowSettings\(true\)\}/, '<motion.button whileTap={{ scale: 0.9 }} onClick={() => setShowSettings(true)}');
    c = c.replace(/<Settings className="w-5 h-5" \/>\n                <\/button>/, '<Settings className="w-5 h-5" />\n                </motion.button>');
    
    // The main FAB (PlusCircle)
    c = c.replace(/<button \n                        onClick=\{\(\) => setShowAddMenu\(true\)\}/, '<motion.button whileTap={{ scale: 0.9 }} \n                        onClick={() => setShowAddMenu(true)}');
    c = c.replace(/<PlusCircle className="w-6 h-6" \/>\n                      <\/button>/, '<PlusCircle className="w-6 h-6" />\n                      </motion.button>');

    // Sub FABs in add menu
    c = c.replace(/<button \n                        onClick=\{\(\) => \{ setActiveTab\('add_debt'\); setShowAddMenu\(false\); \}\}/, '<motion.button whileTap={{ scale: 0.95 }} \n                        onClick={() => { setActiveTab(\'add_debt\'); setShowAddMenu(false); }}');
    c = c.replace(/<span className="text-xs font-medium text-gray-700 dark:text-gray-300">ديون<\/span>\n                      <\/button>/, '<span className="text-xs font-medium text-gray-700 dark:text-gray-300">ديون</span>\n                      </motion.button>');
    
    c = c.replace(/<button \n                        onClick=\{\(\) => \{ setActiveTab\('add'\); setShowAddMenu\(false\); \}\}/, '<motion.button whileTap={{ scale: 0.95 }} \n                        onClick={() => { setActiveTab(\'add\'); setShowAddMenu(false); }}');
    c = c.replace(/<span className="text-xs font-medium text-gray-700 dark:text-gray-300">شراء جهاز<\/span>\n                      <\/button>/, '<span className="text-xs font-medium text-gray-700 dark:text-gray-300">شراء جهاز</span>\n                      </motion.button>');
    
    c = c.replace(/<button \n                        onClick=\{\(\) => \{ setActiveTab\('add_expense'\); setShowAddMenu\(false\); \}\}/, '<motion.button whileTap={{ scale: 0.95 }} \n                        onClick={() => { setActiveTab(\'add_expense\'); setShowAddMenu(false); }}');
    c = c.replace(/<span className="text-xs font-medium text-gray-700 dark:text-gray-300">المصاريف<\/span>\n                      <\/button>/, '<span className="text-xs font-medium text-gray-700 dark:text-gray-300">المصاريف</span>\n                      </motion.button>');

    fs.writeFileSync('src/App.tsx', c);
    console.log('App.tsx updated');
}
