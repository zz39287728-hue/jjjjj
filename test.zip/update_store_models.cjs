const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

c = c.replace(/import \{ Device \} from '\.\/types';/, "import { Device, GeneralExpense, GeneralDebt } from './types';");

const interfaceReplace = `  devices: Device[];
  generalExpenses: GeneralExpense[];
  generalDebts: GeneralDebt[];
  addGeneralExpense: (expense: Omit<GeneralExpense, 'id'>) => Promise<void>;
  updateGeneralExpense: (id: string, updates: Partial<GeneralExpense>) => Promise<void>;
  deleteGeneralExpense: (id: string) => Promise<void>;
  addGeneralDebt: (debt: Omit<GeneralDebt, 'id'>) => Promise<void>;
  updateGeneralDebt: (id: string, updates: Partial<GeneralDebt>) => Promise<void>;
  deleteGeneralDebt: (id: string) => Promise<void>;`;

c = c.replace(/  devices: Device\[\];/, interfaceReplace);

const stateReplace = `  const [devices, setDevices] = useState<Device[]>([]);
  const [generalExpenses, setGeneralExpenses] = useState<GeneralExpense[]>([]);
  const [generalDebts, setGeneralDebts] = useState<GeneralDebt[]>([]);`;

c = c.replace(/  const \[devices, setDevices\] = useState<Device\[\]>\(\[\]\);/, stateReplace);

const useStoreReplace = `  const [authLoading, setAuthLoading] = useState(true);
  const [devices, setDevices] = useState<Device[]>([]);
  const [generalExpenses, setGeneralExpenses] = useState<GeneralExpense[]>([]);
  const [generalDebts, setGeneralDebts] = useState<GeneralDebt[]>([]);

  useEffect(() => {
    if (!user) {
      setDevices([]);
      setGeneralExpenses([]);
      setGeneralDebts([]);
      return;
    }

    const unsubDevices = onSnapshot(query(collection(db, 'devices'), where('userId', '==', user.uid)), (snapshot) => {
      setDevices(snapshot.docs.map(d => ({ id: d.id, ...d.data() }) as Device));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'devices'));

    const unsubExpenses = onSnapshot(query(collection(db, 'generalExpenses'), where('userId', '==', user.uid)), (snapshot) => {
      setGeneralExpenses(snapshot.docs.map(d => ({ id: d.id, ...d.data() }) as GeneralExpense));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'generalExpenses'));

    const unsubDebts = onSnapshot(query(collection(db, 'generalDebts'), where('userId', '==', user.uid)), (snapshot) => {
      setGeneralDebts(snapshot.docs.map(d => ({ id: d.id, ...d.data() }) as GeneralDebt));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'generalDebts'));

    return () => {
      unsubDevices();
      unsubExpenses();
      unsubDebts();
    };
  }, [user]);`;

// Need to safely replace the useEffect logic
// Wait, the previous useEffect had a migration script inside it. I shouldn't overwrite the whole thing without checking.
