const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/const \{ updateDevice \} = useStore\(\);/, 'const { updateDevice, language } = useStore();');
c = c.replace(/import \{ Device \} from '\.\.\/types';/, "import { Device } from '../types';\nimport { t } from '../i18n';");

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
