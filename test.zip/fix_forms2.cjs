const fs = require('fs');
let c = fs.readFileSync('src/views/FormsView.tsx', 'utf8');

c = c.replace(/const \{ addDevice \} = useStore\(\);/, 'const { addDevice, language } = useStore();');
c = c.replace(/import \{ Check, Upload, Image as ImageIcon, Briefcase, Gamepad, Disc, Headphones, Wind, MonitorUp \} from 'lucide-react';/, "import { Check, Upload, Image as ImageIcon, Briefcase, Gamepad, Disc, Headphones, Wind, MonitorUp } from 'lucide-react';\nimport { t } from '../i18n';");

fs.writeFileSync('src/views/FormsView.tsx', c);
