const fs = require('fs');

let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

c = c.replace(/<button onClick=\{\(\) => setTimeFilter\('all'\)\}/g, '<motion.button whileTap={{ scale: 0.9 }} onClick={() => setTimeFilter(\'all\')}');
c = c.replace(/\{language === 'ar' \? 'الكل' : 'All'\}\n            <\/button>/g, "{language === 'ar' ? 'الكل' : 'All'}\n            </motion.button>");

c = c.replace(/<button onClick=\{\(\) => setTimeFilter\('today'\)\}/g, '<motion.button whileTap={{ scale: 0.9 }} onClick={() => setTimeFilter(\'today\')}');
c = c.replace(/\{language === 'ar' \? 'اليوم' : 'Today'\}\n            <\/button>/g, "{language === 'ar' ? 'اليوم' : 'Today'}\n            </motion.button>");

c = c.replace(/<button onClick=\{\(\) => setTimeFilter\('week'\)\}/g, '<motion.button whileTap={{ scale: 0.9 }} onClick={() => setTimeFilter(\'week\')}');
c = c.replace(/\{language === 'ar' \? 'الأسبوع' : 'Week'\}\n            <\/button>/g, "{language === 'ar' ? 'الأسبوع' : 'Week'}\n            </motion.button>");

c = c.replace(/<button onClick=\{\(\) => setTimeFilter\('month'\)\}/g, '<motion.button whileTap={{ scale: 0.9 }} onClick={() => setTimeFilter(\'month\')}');
c = c.replace(/\{language === 'ar' \? 'الشهر' : 'Month'\}\n            <\/button>/g, "{language === 'ar' ? 'الشهر' : 'Month'}\n            </motion.button>");

fs.writeFileSync('src/views/Dashboard.tsx', c);
console.log("Updated buttons in Dashboard");
