const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');
c = c.replace(/} , User from 'lucide-react';/, ', User } from \'lucide-react\';');
fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
