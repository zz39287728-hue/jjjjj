import sys
import re

with open('src/App.tsx', 'r') as f:
    content = f.read()

# Add hapticFeedback import
if "import { hapticFeedback }" not in content:
    content = content.replace("import { t } from './i18n';", "import { t } from './i18n';\nimport { hapticFeedback } from './utils';")

# Update tabs
def r(target, rep):
    global content
    content = content.replace(target, rep)

r("onClick={() => setActiveTab('inventory')}", "onClick={() => { hapticFeedback('light'); setActiveTab('inventory'); }}")
r("onClick={() => setActiveTab('home')}", "onClick={() => { hapticFeedback('light'); setActiveTab('home'); }}")
r("onClick={() => setActiveTab('add')}", "onClick={() => { hapticFeedback('medium'); setActiveTab('add'); setShowAddMenu(false); }}")
r("onClick={() => setActiveTab('add_debt')}", "onClick={() => { hapticFeedback('medium'); setActiveTab('add_debt'); setShowAddMenu(false); }}")
r("onClick={() => setActiveTab('add_expense')}", "onClick={() => { hapticFeedback('medium'); setActiveTab('add_expense'); setShowAddMenu(false); }}")

r("setShowAddMenu(!showAddMenu)", "hapticFeedback('light'); setShowAddMenu(!showAddMenu)")
r("setShowSettings(true)", "{ hapticFeedback('medium'); setShowSettings(true); }")

# Update App.tsx motion animations to use more native spring
r("""<motion.div
                      key={activeTab}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.2 }}
                      className="h-full"
                    >""", """<motion.div
                      key={activeTab}
                      initial={{ opacity: 0, y: 20, scale: 0.98 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -20, scale: 0.98 }}
                      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                      className="h-full"
                    >""")

with open('src/App.tsx', 'w') as f:
    f.write(content)

print("Added haptics and springs to App.tsx")
