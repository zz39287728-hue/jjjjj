const fs = require('fs');
let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

c = c.replace(/<div className="bg-white dark:bg-gray-800 p-5 sm:p-6 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700">/g, '<motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white dark:bg-gray-800 p-5 sm:p-6 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700">');
c = c.replace(/<p className="text-xs text-gray-400 dark:text-gray-500 mt-1">\{inStockDevices\.length\} \{t\('in_stock_devices', language\)\}<\/p>\n        <\/div>/, '<p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{inStockDevices.length} {t(\'in_stock_devices\', language)}</p>\n        </motion.div>');
c = c.replace(/<p className="text-xs text-gray-400 dark:text-gray-500 mt-1">\{soldDevices\.length\} \{t\('sold_devices', language\)\}<\/p>\n        <\/div>/, '<p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{soldDevices.length} {t(\'sold_devices\', language)}</p>\n        </motion.div>');

c = c.replace(/<div className="bg-white dark:bg-gray-800 p-5 sm:p-6 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700 col-span-2 flex items-center justify-between">/, '<motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-white dark:bg-gray-800 p-5 sm:p-6 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700 col-span-2 flex items-center justify-between">');

fs.writeFileSync('src/views/Dashboard.tsx', c);
console.log("Fixed Dashboard");
