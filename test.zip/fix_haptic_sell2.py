import sys

with open('src/components/SellModal.tsx', 'r') as f:
    content = f.read()

content = content.replace("import { formatBHD, toLatinDigits, translateExtra } from '../utils';", "import { formatBHD, toLatinDigits, translateExtra, hapticFeedback } from '../utils';")

with open('src/components/SellModal.tsx', 'w') as f:
    f.write(content)
