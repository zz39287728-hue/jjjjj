const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

const badChunkTop = `        const [activeWorkspaceId, setActiveWorkspaceId] = useState<string>('');
    const generateInviteCode = async () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const joinWorkspace = async (workspaceId: string, inviteCode: string) => {
    alert("Not fully implemented yet");
    return false;
  };

  const clearWorkspace = () => {
    setActiveWorkspaceId('');
  };`;

c = c.replace(badChunkTop, "");

const badChunkBottom = `  const [activeWorkspaceId, setActiveWorkspaceId] = useState<string>('');
  
  const generateInviteCode = async () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const joinWorkspace = async (workspaceId: string, inviteCode: string) => {
    alert("Not fully implemented yet");
    return false;
  };

  const clearWorkspace = () => {
    setActiveWorkspaceId('');
  };`;

c = c.replace(badChunkBottom, "");

fs.writeFileSync('src/store.tsx', c);
