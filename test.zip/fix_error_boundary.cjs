const fs = require('fs');
let c = fs.readFileSync('src/components/ErrorBoundary.tsx', 'utf8');

c = c.replace(/export class ErrorBoundary extends React\.Component<Props, State> \{/, 
  "export class ErrorBoundary extends React.Component<Props, State> {\n  public state: State;\n");

fs.writeFileSync('src/components/ErrorBoundary.tsx', c);
console.log("Fixed ErrorBoundary");
