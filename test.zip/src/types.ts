export interface Expense {
  id: string;
  type: 'petrol_dad' | 'petrol' | 'dinner_abbas' | 'maintenance' | 'delivery' | 'other';
  amount: number;
  customName?: string;
}

export interface ExtraAction {
  extraName: string;
  action: 'sold' | 'gifted' | 'kept_personal' | 'pending';
  price?: number;
  notes?: string;
}

export interface Device {
  id: string;
  model: string;
  buyPrice: number;
  buyDate: string;
  hasWarranty?: boolean;
  warrantyMonths?: number;
  sellPrice?: number;
  sellDate?: string;
  status: 'in_stock' | 'sold';
  notes?: string;
  extras?: string[];
  sellerName?: string;
  sellerPhone?: string;
  chatImage?: string;
  title?: string;
  area?: string;
  buyerName?: string;
  buyerPhone?: string;
  buyerArea?: string;
  soldExtras?: string[];
  sellMethod?: 'cash' | 'benefit' | 'mixed';
  cashAmount?: number;
  benefitAmount?: number;
  expenses?: Expense[];
  extraActions?: ExtraAction[];
  loanAmount?: number;
  loanLender?: string;
  loanStatus?: 'unpaid' | 'paid';
}

export interface GeneralExpense {
  id: string;
  amount: number;
  date: string;
  title: string;
  notes?: string;
}

export interface GeneralDebt {
  id: string;
  amount: number;
  date: string;
  personName: string;
  type: 'borrowed' | 'lent';
  status: 'unpaid' | 'paid';
  notes?: string;
}

export interface AppError {
  id: string;
  code: string;
  message: string;
  timestamp: string;
  details?: string;
  path?: string;
  seen?: boolean;
}
