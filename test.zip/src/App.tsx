import React, { useState } from 'react';
import { StoreProvider, useStore } from './store';
import { OfflineIndicator } from './components/OfflineIndicator';
import { Home, Package, PlusCircle, Gamepad2, Settings } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import Dashboard from './views/Dashboard';
import Inventory from './views/Inventory';
import FormsView from './views/FormsView';
import GeneralDebtForm from './views/GeneralDebtForm';
import GeneralExpenseForm from './views/GeneralExpenseForm';
import DebtsList from './views/DebtsList';
import { Receipt, CreditCard, X, Plus, ArrowRight, ArrowLeft } from 'lucide-react';
import SellModal from './components/SellModal';
import { PWAInstallButton } from "./PWAInstallButton";
import SplashScreen from './components/SplashScreen';
import SettingsModal from './components/SettingsModal';
import { t } from './i18n';
import { hapticFeedback } from './utils';
import { useBackButton } from './useBackButton';
import { useSwipeable } from 'react-swipeable';

function MainLayout() {
  const { language, user, authLoading, signIn, errors, turboMode } = useStore();
  
  const unseenErrorsCount = errors.filter(e => !e.seen).length;

  React.useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  React.useEffect(() => {
    if (turboMode) {
      document.body.classList.add('turbo-mode');
    } else {
      document.body.classList.remove('turbo-mode');
    }
  }, [turboMode]);
  
  const [showSplash, setShowSplash] = useState(true);
  const [activeTab, setActiveTab] = useState<'home' | 'inventory' | 'add' | 'add_debt' | 'add_expense' | 'borrowed_list' | 'lent_list'>('home');
  const [showAddMenu, setShowAddMenu] = useState(false);
  const [sellingDevice, setSellingDevice] = useState<any>(null);
  const [showSettings, setShowSettings] = useState(false);

  const mainSwipeHandlers = useSwipeable({
    onSwipedLeft: (e) => {
      if (activeTab === 'home') {
        if (language === 'ar') {
          // RTL: Home is Right, swipe left means we are going further right, nothing there
        } else {
          setActiveTab('inventory'); // LTR: Home is Left, swipe left goes to Inventory (Right)
        }
      } else if (activeTab === 'inventory') {
        if (language === 'ar') {
          setActiveTab('home'); // RTL: Inventory is Left, swipe left goes to Home (Right)
        }
      }
    },
    onSwipedRight: (e) => {
      if (activeTab === 'home') {
        if (language === 'ar') {
          setActiveTab('inventory'); // RTL: Home is Right, swipe right goes to Inventory (Left)
        }
      } else if (activeTab === 'inventory') {
        if (language === 'ar') {
          // RTL: Inventory is Left, swipe right means going further left, nothing there
        } else {
          setActiveTab('home'); // LTR: Inventory is Right, swipe right goes to Home (Left)
        }
      }
    },
    trackMouse: true,
    delta: 60
  });

  useBackButton(() => {
    if (sellingDevice) {
      setSellingDevice(null);
      return true;
    }
    if (showSettings) {
      setShowSettings(false);
      return true;
    }
    if (showAddMenu) {
      setShowAddMenu(false);
      return true;
    }
    if (activeTab !== 'home') {
      setActiveTab('home');
      return true;
    }
    return false;
  });

  const renderContent = () => {
    switch (activeTab) {
      case 'home': return <Dashboard onNavigate={setActiveTab} />;
      case 'inventory': return <Inventory onSellClick={setSellingDevice} />;
      case 'add': return <FormsView onSuccess={() => setActiveTab('inventory')} />;
      case 'add_debt': return <GeneralDebtForm onSuccess={() => setActiveTab('home')} />;
      case 'add_expense': return <GeneralExpenseForm onSuccess={() => setActiveTab('inventory')} />;
      case 'borrowed_list': return <DebtsList type="borrowed" />;
      case 'lent_list': return <DebtsList type="lent" />;
      default: return <Dashboard onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="flex justify-center bg-gray-200 dark:bg-gray-950 min-h-[100dvh] font-sans text-gray-900 dark:text-gray-100 selection:bg-indigo-200">
      <div className="w-full max-w-3xl bg-gray-50 dark:bg-gray-900 min-h-[100dvh] h-[100dvh] flex flex-col relative overflow-hidden transition-colors shadow-2xl">
        
        <AnimatePresence mode="wait">
          {showSplash || authLoading ? (
            <SplashScreen key="splash" onComplete={() => setShowSplash(false)} />
          ) : !user ? (
            <motion.div
              key="auth"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center h-full p-8 space-y-6 text-center bg-white dark:bg-gray-900"
            >
              <Gamepad2 className="w-20 h-20 text-indigo-600 dark:text-indigo-400" />
              <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">ZakiTation</h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {language === 'ar' ? 'سجل دخولك لمزامنة الأجهزة والمبيعات الخاصة بك' : 'Sign in to sync your devices and sales'}
              </p>
              
              <button
                onClick={() => signIn()}
                className="w-full flex items-center justify-center gap-3 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-700 font-medium py-3 px-4 rounded-xl shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
                {language === 'ar' ? 'تسجيل الدخول باستخدام جوجل' : 'Sign in with Google'}
              </button>
            </motion.div>
          ) : (
            <motion.div 
              key="main-app"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="flex flex-col h-full w-full"
            >
              <header className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-800 px-4 pb-4 pt-[max(env(safe-area-inset-top),40px)] sm:pt-[max(env(safe-area-inset-top),16px)] shrink-0 shadow-sm z-10 relative flex justify-between items-center transition-colors min-h-[88px] sm:min-h-[72px]">
                <div className="flex items-center z-10 min-w-[80px]">
                  {(activeTab === 'add' || activeTab === 'add_debt' || activeTab === 'add_expense') ? (
                    <button onClick={() => { hapticFeedback('light'); setActiveTab('inventory'); }} className="flex items-center p-3 -ml-3 text-sm font-medium text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 min-h-[44px] min-w-[44px]">
                       {t('cancel', language)}
                    </button>
                  ) : (activeTab === 'borrowed_list' || activeTab === 'lent_list') ? (
                    <button onClick={() => { hapticFeedback('light'); setActiveTab('home'); }} className="flex items-center justify-center p-3 -ml-3 text-sm font-medium text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 min-h-[44px] min-w-[44px]">
                       {language === 'ar' ? <ArrowRight className="w-6 h-6" /> : <ArrowLeft className="w-6 h-6" />}
                    </button>
                  ) : null}
                </div>

                {!(activeTab === 'add' || activeTab === 'add_debt' || activeTab === 'add_expense' || activeTab === 'borrowed_list' || activeTab === 'lent_list') && (
                  <div className="absolute left-0 right-0 bottom-0 top-[max(env(safe-area-inset-top),40px)] sm:top-[max(env(safe-area-inset-top),16px)] flex items-center justify-center pointer-events-none">
                    <h1 className="text-xl sm:text-2xl font-black bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 dark:from-indigo-400 dark:via-purple-400 dark:to-indigo-400 bg-clip-text text-transparent drop-shadow-sm truncate px-4">
                      تجارة حمازك وعبازك
                    </h1>
                  </div>
                )}

                <div className="flex items-center gap-1 z-10 justify-end min-w-[80px]">
                  <PWAInstallButton />
                  <div className="relative">
                    <motion.button whileTap={{ scale: 0.9 }} onClick={() => { hapticFeedback('medium'); setShowSettings(true); }} className="flex items-center justify-center w-12 h-12 -mr-3 text-gray-400 dark:text-gray-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-full transition-colors">
                      <Settings className="w-6 h-6" />
                    </motion.button>
                    {unseenErrorsCount > 0 && (
                      <span className="absolute top-2 right-0 -mr-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white shadow-sm ring-2 ring-white dark:ring-gray-900">
                        {unseenErrorsCount > 9 ? '9+' : unseenErrorsCount}
                      </span>
                    )}
                  </div>
                </div>
              </header>

              <main {...mainSwipeHandlers} className="flex-1 overflow-y-auto pb-32 relative bg-gray-50/50 dark:bg-gray-900/50 transition-colors" id="main-scroll">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, y: 10, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.98 }}
                    transition={{ duration: 0.25, ease: "easeOut" }}
                    className="min-h-full"
                  >
                    {renderContent()}
                  </motion.div>
                </AnimatePresence>
              </main>

              <AnimatePresence>
                {!(activeTab === 'add' || activeTab === 'add_debt' || activeTab === 'add_expense') && (
                  <motion.nav 
                    initial={{ y: 100 }}
                    animate={{ y: 0 }}
                    exit={{ y: 100 }}
                    transition={{ type: "spring", bounce: 0, duration: 0.4 }}
                    className="absolute bottom-0 w-full bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-800 h-16 flex justify-around items-center px-6 pb-safe shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] z-20 transition-colors"
                  >
                    <NavItem icon={<Home />} label={t('dashboard', language)} active={activeTab === 'home'} onClick={() => { hapticFeedback('light'); setActiveTab('home'); }} />
                    
                    <div className="relative -top-5">
                      <motion.button whileTap={{ scale: 0.9 }} 
                        onClick={() => setShowAddMenu(true)}
                        className="w-16 h-16 rounded-full flex items-center justify-center text-white shadow-lg bg-gray-900 dark:bg-gray-700 hover:bg-gray-800 dark:hover:bg-gray-600 shadow-gray-300 dark:shadow-none transition-transform"
                      >
                        <PlusCircle className="w-7 h-7" />
                      </motion.button>
                    </div>
                    
                    <NavItem icon={<Package />} label={t('inventory', language)} active={activeTab === 'inventory'} onClick={() => { hapticFeedback('light'); setActiveTab('inventory'); }} />
                  </motion.nav>
                )}
              </AnimatePresence>


                {showAddMenu && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 z-40 bg-black/40 backdrop-blur-sm flex items-end justify-center pointer-events-auto pb-[100px]"
                    onClick={() => setShowAddMenu(false)}
                  >
                    <motion.div
                      initial={{ y: 50, scale: 0.9, opacity: 0 }}
                      animate={{ y: 0, scale: 1, opacity: 1 }}
                      exit={{ y: 50, scale: 0.9, opacity: 0 }}
                      className="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-2xl flex items-start justify-center gap-6 border border-gray-100 dark:border-gray-700 max-w-[90%] mx-auto"
                      onClick={e => e.stopPropagation()}
                    >
                      <motion.button whileTap={{ scale: 0.95 }} 
                        onClick={() => { setActiveTab('add_debt'); setShowAddMenu(false); }}
                        className="flex flex-col items-center gap-3 w-[72px]"
                      >
                        <div className="w-16 h-16 shrink-0 bg-red-50 dark:bg-red-900/30 rounded-2xl flex items-center justify-center text-red-600 dark:text-red-400 shadow-sm">
                          <CreditCard className="w-7 h-7" />
                        </div>
                        <span className="text-xs font-medium text-gray-700 dark:text-gray-300 text-center leading-tight break-words w-full">{t('debts_and_loans', language)}</span>
                      </motion.button>
                      <motion.button whileTap={{ scale: 0.95 }} 
                        onClick={() => { setActiveTab('add'); setShowAddMenu(false); }}
                        className="flex flex-col items-center gap-3 w-[72px]"
                      >
                        <div className="w-16 h-16 shrink-0 bg-indigo-50 dark:bg-indigo-900/30 rounded-2xl flex items-center justify-center text-indigo-600 dark:text-indigo-400 shadow-sm">
                          <Gamepad2 className="w-7 h-7" />
                        </div>
                        <span className="text-xs font-medium text-gray-700 dark:text-gray-300 text-center leading-tight break-words w-full">{t('buy_new_device', language)}</span>
                      </motion.button>
                      <motion.button whileTap={{ scale: 0.95 }} 
                        onClick={() => { setActiveTab('add_expense'); setShowAddMenu(false); }}
                        className="flex flex-col items-center gap-3 w-[72px]"
                      >
                        <div className="w-16 h-16 shrink-0 bg-amber-50 dark:bg-amber-900/30 rounded-2xl flex items-center justify-center text-amber-600 dark:text-amber-400 shadow-sm">
                          <Receipt className="w-7 h-7" />
                        </div>
                        <span className="text-xs font-medium text-gray-700 dark:text-gray-300 text-center leading-tight break-words w-full">{t('expenses', language)}</span>
                      </motion.button>
                    </motion.div>
                  </motion.div>
                )}
              <OfflineIndicator />
              <AnimatePresence>
                {sellingDevice && (
                  <SellModal device={sellingDevice} onClose={() => setSellingDevice(null)} />
                )}
                {showSettings && (
                  <SettingsModal onClose={() => setShowSettings(false)} />
                )}
              </AnimatePresence>
              <div id="modal-root" className="absolute inset-0 pointer-events-none z-50 [&>*]:pointer-events-auto flex flex-col justify-end sm:justify-center"></div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick} 
      className={`flex flex-col items-center justify-center w-20 h-full space-y-1 transition-colors ${active ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`}
    >
      <div className={`${active ? 'scale-110' : 'scale-100'} transition-transform`}>
        {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { className: 'w-6 h-6' }) : icon}
      </div>
      <span className="text-[10px] font-medium">{label}</span>
    </button>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <MainLayout />
    </StoreProvider>
  );
}
