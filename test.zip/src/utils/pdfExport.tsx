import { Device, GeneralExpense } from '../types';
import { formatBHD } from '../utils';
import jsPDF from 'jspdf';
import * as htmlToImage from 'html-to-image';

export const generateTransactionsPDF = async (
  devices: Device[],
  generalExpenses: GeneralExpense[],
  language: 'ar' | 'en'
) => {
  const txs: { id: string; type: 'buy' | 'sell' | 'expense'; title: string; amount: number; date: string; profit?: number }[] = [];
  
  devices.forEach(d => {
    txs.push({
      id: d.id + '_buy',
      type: 'buy',
      title: d.title || d.model,
      amount: d.buyPrice,
      date: d.buyDate
    });
    
    if (d.status === 'sold' && d.sellDate && d.sellPrice) {
      const extraProfit = d.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
      const baseProfit = d.sellPrice - d.buyPrice - (d.expenses?.reduce((eSum, e) => eSum + e.amount, 0) || 0);
      txs.push({
        id: d.id + '_sell',
        type: 'sell',
        title: d.title || d.model,
        amount: d.sellPrice,
        date: d.sellDate,
        profit: baseProfit + extraProfit
      });
    }
  });

  if (generalExpenses) {
    generalExpenses.forEach(exp => {
      txs.push({
        id: exp.id + '_exp',
        type: 'expense',
        title: exp.title,
        amount: exp.amount,
        date: exp.date
      });
    });
  }

  txs.sort((a, b) => (b.date > a.date ? 1 : -1));

  const totalSales = txs.filter(t => t.type === 'sell').reduce((sum, t) => sum + t.amount, 0);
  const totalPurchases = txs.filter(t => t.type === 'buy').reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = txs.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  const totalProfits = txs.filter(t => t.type === 'sell').reduce((sum, t) => sum + (t.profit || 0), 0);

  const htmlString = `
    <div style="padding: 40px; font-family: Arial, Helvetica, sans-serif; background-color: white; color: black; box-sizing: border-box;">
      <h1 style="font-size: 24px; font-weight: normal; margin-bottom: 5px; color: #000;">
        Accounting Transactions Report
      </h1>
      <p style="color: #666; font-size: 12px; margin-top: 0; margin-bottom: 30px; letter-spacing: 1px;">
        Generated: ${new Date().toLocaleDateString('en-GB')}
      </p>
      
      <div style="font-size: 14px; line-height: 1.8; margin-bottom: 30px; color: #000;">
        <div>Total Sales: ${formatBHD(totalSales)}</div>
        <div>Total Purchases: ${formatBHD(totalPurchases)}</div>
        <div>Total Expenses: ${formatBHD(totalExpenses)}</div>
        <div>Net Profits: ${formatBHD(totalProfits)}</div>
      </div>

      <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
        <thead>
          <tr style="background-color: #4285f4; color: white;">
            <th style="padding: 8px 10px; text-align: left; border: 1px solid #ddd; font-weight: bold;">Date</th>
            <th style="padding: 8px 10px; text-align: left; border: 1px solid #ddd; font-weight: bold;">Type</th>
            <th style="padding: 8px 10px; text-align: left; border: 1px solid #ddd; font-weight: bold;">Description</th>
            <th style="padding: 8px 10px; text-align: left; border: 1px solid #ddd; font-weight: bold;">Amount</th>
            <th style="padding: 8px 10px; text-align: left; border: 1px solid #ddd; font-weight: bold;">Profit</th>
          </tr>
        </thead>
        <tbody>
          ${txs.map(tx => `
            <tr>
              <td style="padding: 8px 10px; border: 1px solid #ddd; color: #333;">${new Date(tx.date).toLocaleDateString('en-GB')}</td>
              <td style="padding: 8px 10px; border: 1px solid #ddd; color: #333;">
                ${tx.type === 'sell' ? 'Sale' : tx.type === 'buy' ? 'Purchase' : 'Expense'}
              </td>
              <td style="padding: 8px 10px; border: 1px solid #ddd; color: #333;" dir="auto">${tx.title}</td>
              <td style="padding: 8px 10px; border: 1px solid #ddd; color: #333;">${formatBHD(tx.amount)}</td>
              <td style="padding: 8px 10px; border: 1px solid #ddd; color: #333;">
                ${tx.type === 'sell' && tx.profit !== undefined ? formatBHD(tx.profit) : '-'}
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;

  const iframe = document.createElement('iframe');
  iframe.style.position = 'absolute';
  iframe.style.width = '800px';
  iframe.style.height = '0';
  iframe.style.left = '-9999px';
  document.body.appendChild(iframe);

  const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
  if (!iframeDoc) {
    document.body.removeChild(iframe);
    throw new Error('Cannot access iframe document');
  }

  iframeDoc.open();
  iframeDoc.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>Report</title>
      </head>
      <body style="background: white; margin: 0;">
        <div id="pdf-container">
          ${htmlString}
        </div>
      </body>
    </html>
  `);
  iframeDoc.close();

  // Wait a moment for iframe content to be parsed
  await new Promise(resolve => setTimeout(resolve, 200));

  try {
    const containerNode = iframeDoc.getElementById('pdf-container');
    if (!containerNode) throw new Error('Container not found');

    const dataUrl = await htmlToImage.toPng(containerNode, { quality: 1, pixelRatio: 2 });
    
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    const imgProps = pdf.getImageProperties(dataUrl);
    const imgHeight = (imgProps.height * pdfWidth) / imgProps.width;
    
    let heightLeft = imgHeight;
    let position = 0;
    
    pdf.addImage(dataUrl, 'PNG', 0, position, pdfWidth, imgHeight);
    heightLeft -= pdfHeight;
    
    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(dataUrl, 'PNG', 0, position, pdfWidth, imgHeight);
      heightLeft -= pdfHeight;
    }
    
    pdf.save(`Accounting_Report_${new Date().toISOString().split('T')[0]}.pdf`);
  } catch (error) {
    console.error('Failed to generate PDF', error);
  } finally {
    document.body.removeChild(iframe);
  }
};
