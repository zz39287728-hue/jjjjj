import { playSound } from './audio';
/**
 * Convert any Eastern Arabic (٠-٩) or Persian (۰-۹) digits into English / Latin digits (0-9)
 */
export const toLatinDigits = (val: string | number | undefined | null): string => {
  if (val == null) return '';
  const str = String(val);
  return str
    .replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 1632 + 48))
    .replace(/[۰-۹]/g, d => String.fromCharCode(d.charCodeAt(0) - 1776 + 48));
};

export const formatBHD = (amount: number | undefined | null) => {
  if (amount == null) return '-';
  const formatted = new Intl.NumberFormat('en-BH-u-nu-latn', { 
    style: 'currency', 
    currency: 'BHD',
    maximumFractionDigits: 3 
  }).format(amount);
  return toLatinDigits(formatted.replace('BHD', 'BD').trim());
};

export const formatDate = (dateString: string | undefined | null) => {
  if (!dateString) return '-';
  const formatted = new Intl.DateTimeFormat('en-BH-u-nu-latn', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  }).format(new Date(dateString));
  return toLatinDigits(formatted);
};

export const translateExtra = (extra: string, language: 'en' | 'ar' = 'ar') => {
  if (language === 'en') {
    if (extra.startsWith('CD:')) return extra;
    if (extra.startsWith('Other:')) return extra;
    switch (extra.toLowerCase()) {
      case 'bag': return 'Bag';
      case 'extra controller':
      case 'controller': return 'Extra Controller';
      case 'headset': return 'Headset';
      case 'cooler': return 'Cooler';
      case 'stand': return 'Stand';
      default: return extra;
    }
  }

  if (extra.startsWith('CD:')) return extra.replace('CD:', 'شريط:');
  if (extra.startsWith('Other:')) return extra.replace('Other:', 'أخرى:');
  switch (extra.toLowerCase()) {
    case 'bag': return 'حقيبة';
    case 'extra controller':
    case 'controller': return 'جهاز تحكم إضافي';
    case 'headset': return 'سماعة';
    case 'cooler': return 'مبرد';
    case 'stand': return 'قاعدة';
    default: return extra;
  }
};

export const hapticFeedback = (type: 'light' | 'medium' | 'heavy' | 'success' | 'error' | 'celebration' = 'light') => {
  // Play sound
  if (type === 'light') playSound('tap');
  else if (type === 'medium') playSound('click');
  else if (type === 'heavy') playSound('delete');
  else if (type === 'success') playSound('success');
  else if (type === 'error') playSound('error');
  else if (type === 'celebration') playSound('celebration');

  // Play vibration
  if (typeof window !== 'undefined' && window.navigator && window.navigator.vibrate) {
    try {
      switch(type) {
        case 'light': window.navigator.vibrate(10); break;
        case 'medium': window.navigator.vibrate(20); break;
        case 'heavy': window.navigator.vibrate(40); break;
        case 'success': window.navigator.vibrate([15, 50, 20]); break;
        case 'celebration': window.navigator.vibrate([15, 50, 20, 50, 20]); break;
        case 'error': window.navigator.vibrate([50, 50, 50]); break;
      }
    } catch (e) {
      // ignore
    }
  }
};

export const getWhatsAppLink = (phone: string | undefined | null) => {
  if (!phone) return '#';
  let cleaned = String(phone).replace(/\D/g, '');
  if (cleaned.length === 8) {
    cleaned = `973${cleaned}`;
  } else if (cleaned.startsWith('00')) {
    cleaned = cleaned.substring(2);
  }
  return `https://wa.me/${cleaned}`;
};

export const calculateCurrentBalance = (devices: any[], generalExpenses: any[], generalDebts: any[]) => {
  // Cash in from sales
  const totalSalesIncome = devices.filter(d => d.status === 'sold').reduce((sum, d) => {
    const extraProfit = d.extraActions?.reduce((eSum: number, e: any) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
    return sum + (d.sellPrice || 0) + extraProfit;
  }, 0);

  // Cash out for purchases and expenses
  const totalPurchasesCost = devices.reduce((sum, d) => {
    // If device has unpaid loan, we didn't pay that cash out of pocket yet
    const unpaidDeviceDebt = (d.loanStatus === 'unpaid' && d.loanAmount) ? d.loanAmount : 0;
    // We cannot pay negative cash for a device. At most we pay 0 if the loan covers the full buy price (or more, though logically loan shouldn't exceed buyPrice).
    const cashPaidForDevice = Math.max(0, d.buyPrice - unpaidDeviceDebt);
    const expensesCost = d.expenses?.reduce((eSum: number, e: any) => eSum + e.amount, 0) || 0;
    
    // Note: Extra actions with 'bought' action are not currently supported by price field in types, but if they were it would be a cost.
    // Currently extras are bought together or have no price tracked individually. 
    return sum + cashPaidForDevice + expensesCost;
  }, 0);

  // General expenses cash out
  const totalGeneralExpenses = generalExpenses.reduce((sum, e) => sum + e.amount, 0);

  // Money lent to others (cash out)
  const totalLentCash = generalDebts.filter(d => d.type === 'lent' && d.status === 'unpaid').reduce((sum, d) => sum + d.amount, 0);

  // Money borrowed from others (cash in)
  const totalBorrowedCash = generalDebts.filter(d => d.type === 'borrowed' && d.status === 'unpaid').reduce((sum, d) => sum + d.amount, 0);

  return totalSalesIncome - totalPurchasesCost - totalGeneralExpenses - totalLentCash + totalBorrowedCash;
};
