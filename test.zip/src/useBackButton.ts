import { useEffect } from 'react';
import { App } from '@capacitor/app';

export function useBackButton(handler: () => boolean) {
  useEffect(() => {
    let listener: any;
    
    const register = async () => {
      try {
        listener = await App.addListener('backButton', ({ canGoBack }) => {
          const handled = handler();
          if (!handled && !canGoBack) {
            App.exitApp();
          }
        });
      } catch (e) {
        // Not running in Capacitor, ignore
      }
    };
    
    register();
    
    return () => {
      if (listener) {
        listener.remove();
      }
    };
  }, [handler]);
}
