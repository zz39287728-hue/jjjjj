import React, { useState } from 'react';
import { useStore } from '../store';
import { Device, Expense } from '../types';
import { toLatinDigits, hapticFeedback, calculateCurrentBalance, formatBHD } from '../utils';
import { Gamepad2, Briefcase, Disc, Gamepad, Headphones, Wind, MonitorUp, MoreHorizontal, X } from 'lucide-react';
import { t } from '../i18n';

export default function FormsView({ onSuccess }: { onSuccess: () => void }) {
  const { addDevice, language, devices, generalExpenses, generalDebts } = useStore();
  const currentBalance = calculateCurrentBalance(devices, generalExpenses, generalDebts);

  const [edition, setEdition] = useState<'PS5 SLIM' | 'PS5 STANDARD' | ''>('');
  const [version, setVersion] = useState<'Digital' | 'Disk' | ''>('');
  const [buyPrice, setBuyPrice] = useState('');
  const [buyDate, setBuyDate] = useState(new Date().toISOString().split('T')[0]);

  const [hasBag, setHasBag] = useState(false);
  const [hasController, setHasController] = useState(false);
  const [hasCD, setHasCD] = useState(false);
  const [cdName, setCdName] = useState('');
  
  const [hasHeadset, setHasHeadset] = useState(false);
  const [hasCooler, setHasCooler] = useState(false);
  const [hasStand, setHasStand] = useState(false);
  const [hasOther, setHasOther] = useState(false);
  const [otherName, setOtherName] = useState('');
  const [hasWarranty, setHasWarranty] = useState(false);
  const [warrantyMonths, setWarrantyMonths] = useState('');

  const [title, setTitle] = useState('');
  const [area, setArea] = useState('');
  const [sellerName, setSellerName] = useState('');
  const [sellerPhone, setSellerPhone] = useState('');
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [financing, setFinancing] = useState<'personal' | 'loan'>('personal');
  const [loanAmount, setLoanAmount] = useState('');
  const [loanLender, setLoanLender] = useState('lender_abbas');
  const [chatImage, setChatImage] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new window.Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 800;
          const MAX_HEIGHT = 800;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            setChatImage(canvas.toDataURL('image/jpeg', 0.7));
          }
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddDevice = (e: React.FormEvent) => {
    e.preventDefault();
    
    const missingFields: string[] = [];
    if (!title) missingFields.push(language === 'ar' ? 'العنوان' : 'Title');
    if (!edition) missingFields.push(language === 'ar' ? 'الموديل (الإصدار)' : 'Model (Edition)');
    if (!version) missingFields.push(language === 'ar' ? 'النسخة (رقمي أو أقراص)' : 'Version (Digital/Disk)');
    if (!buyPrice) missingFields.push(language === 'ar' ? 'سعر الشراء' : 'Buy Price');
    if (hasCD && !cdName) missingFields.push(language === 'ar' ? 'اسم الشريط' : 'CD Name');
    if (hasOther && !otherName) missingFields.push(language === 'ar' ? 'اسم الإضافة الأخرى' : 'Other Name');
    if (hasWarranty && !warrantyMonths) missingFields.push(language === 'ar' ? 'مدة الضمان' : 'Warranty Months');
    if (financing === 'loan' && !loanAmount) missingFields.push(language === 'ar' ? 'مبلغ الدين' : 'Loan Amount');

    if (missingFields.length > 0) {
      alert((language === 'ar' ? 'يرجى إكمال الحقول التالية:\n\n' : 'Please complete the following fields:\n\n') + missingFields.map(f => `- ${f}`).join('\n'));
      return;
    }

    if (parseFloat(buyPrice) < 0) return alert('Buy price cannot be negative');
    
    const model = `${edition} - ${version}`;
    
    const extras: string[] = [];
    if (hasBag) extras.push('Bag');
    if (hasController) extras.push('Extra Controller');
    if (hasHeadset) extras.push('Headset');
    if (hasCooler) extras.push('Cooler');
    if (hasStand) extras.push('Stand');
    if (hasCD && cdName) extras.push(`CD: ${cdName}`);
    if (hasOther && otherName) extras.push(otherName);
    
    addDevice({
      model,
      title: toLatinDigits(title).trim(),
      buyPrice: parseFloat(toLatinDigits(buyPrice)),
      buyDate,
      extras: extras.map(e => toLatinDigits(e)),
      ...(area && { area: toLatinDigits(area).trim() }),
      ...(sellerName && { sellerName: toLatinDigits(sellerName).trim() }),
      ...(sellerPhone && { sellerPhone: toLatinDigits(sellerPhone).trim() }),
      ...(chatImage && { chatImage }),
      ...(expenses.length > 0 && { expenses }),
      hasWarranty,
      ...(hasWarranty && warrantyMonths && { warrantyMonths: parseInt(warrantyMonths) }),
      ...(financing === 'loan' && loanAmount && { 
        loanAmount: parseFloat(toLatinDigits(loanAmount)), 
        loanLender: toLatinDigits(loanLender), 
        loanStatus: 'unpaid' 
      })
    });
    
    setTitle('');
    setArea('');
    setSellerName('');
    setEdition('');
    setVersion('');
    setBuyPrice('');
    setHasBag(false);
    setHasController(false);
    setHasCD(false);
    setCdName('');
    setHasHeadset(false);
    setHasCooler(false);
    setHasStand(false);
    setHasOther(false);
    setOtherName('');
    setHasWarranty(false);
    setWarrantyMonths('');
    setFinancing('personal');
    setLoanAmount('');
    setLoanLender('lender_abbas');
    setSellerPhone('');
    setChatImage(null);
    hapticFeedback("success");
    onSuccess();
  };

  return (
    <div className="p-4">
      <div className="flex items-center space-x-3 space-x-reverse mb-4">
        <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
          <Gamepad2 className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">{t('buy_new_device', language)}</h2>
          <p className="text-xs text-gray-500 dark:text-gray-400">{t('record_purchase', language)}</p>
        </div>
      </div>
      
      <form onSubmit={handleAddDevice} className="space-y-6 bg-white dark:bg-gray-800 p-6 sm:p-8 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-sm">
        
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('title', language)}</label>
          <input 
            type="text" value={title} onChange={e => setTitle(toLatinDigits(e.target.value))}
            className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('model', language)}</label>
          <div className="grid grid-cols-2 gap-2 mb-3">
            <button
              type="button"
              onClick={() => setEdition('PS5 SLIM')}
              className={`p-3 text-sm font-medium rounded-xl border transition-all ${edition === 'PS5 SLIM' ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
            >
              PS5 SLIM
            </button>
            <button
              type="button"
              onClick={() => setEdition('PS5 STANDARD')}
              className={`p-3 text-sm font-medium rounded-xl border transition-all ${edition === 'PS5 STANDARD' ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
            >
              PS5 STANDARD
            </button>
          </div>

          {edition && (
            <div className="grid grid-cols-2 gap-2 animate-in fade-in slide-in-from-top-2 duration-200">
              <button
                type="button"
                onClick={() => setVersion('Digital')}
                className={`p-3 text-sm font-medium rounded-xl border transition-all ${version === 'Digital' ? 'bg-purple-50 border-purple-500 text-purple-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
              >
                رقمي (Digital)
              </button>
              <button
                type="button"
                onClick={() => setVersion('Disk')}
                className={`p-3 text-sm font-medium rounded-xl border transition-all ${version === 'Disk' ? 'bg-purple-50 border-purple-500 text-purple-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
              >
                أقراص (Disk)
              </button>
            </div>
          )}
        </div>

        <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('extras_included', language)}</label>
          <div className="flex flex-wrap gap-2 mb-3">
            <button
              type="button"
              onClick={() => setHasBag(!hasBag)}
              className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${hasBag ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
            >
              حقيبة
            </button>
            <button
              type="button"
              onClick={() => setHasController(!hasController)}
              className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${hasController ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
            >
              جهاز تحكم إضافي
            </button>
            <button
              type="button"
              onClick={() => setHasCD(!hasCD)}
              className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${hasCD ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
            >
              شريط إضافي
            </button>
            <button
              type="button"
              onClick={() => setHasHeadset(!hasHeadset)}
              className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${hasHeadset ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
            >
              سماعة
            </button>
            <button
              type="button"
              onClick={() => setHasCooler(!hasCooler)}
              className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${hasCooler ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
            >
              مبرد
            </button>
            <button
              type="button"
              onClick={() => setHasStand(!hasStand)}
              className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${hasStand ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
            >
              قاعدة
            </button>
            <button
              type="button"
              onClick={() => setHasOther(!hasOther)}
              className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${hasOther ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
            >
              أخرى
            </button>
          </div>
          
          <div className="space-y-2">
            {hasCD && (
              <div className="animate-in fade-in slide-in-from-top-2 duration-200">
                <input 
                  type="text" 
                  placeholder={t("cd_name", language)}
                  value={cdName} 
                  onChange={e => setCdName(toLatinDigits(e.target.value))}
                  className="w-full p-2.5 text-sm bg-gray-50 dark:bg-gray-700 border border-indigo-200 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                />
              </div>
            )}
            
            {hasOther && (
              <div className="animate-in fade-in slide-in-from-top-2 duration-200">
                <input 
                  type="text" 
                  placeholder={t("other_name", language)}
                  value={otherName} 
                  onChange={e => setOtherName(toLatinDigits(e.target.value))}
                  className="w-full p-2.5 text-sm bg-gray-50 dark:bg-gray-700 border border-indigo-200 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                />
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-col space-y-5 pt-2 border-t border-gray-100 dark:border-gray-800">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('buy_price', language)}</label>
            <input 
              type="number" step="1" min="0" value={buyPrice} 
              onChange={e => { const v = toLatinDigits(e.target.value); if (v === "" || Number(v) <= 10000) setBuyPrice(v); }} 
              onKeyDown={(e) => { if (['e', 'E', '+', '-'].includes(e.key)) e.preventDefault(); }}
              lang="en" dir="ltr"
              className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-left"
            />
            {buyPrice && parseFloat(buyPrice) > currentBalance && (
              <p className="text-xs text-amber-600 dark:text-amber-500 mt-2 font-medium">
                {language === 'ar' 
                  ? `تنبيه: رصيدك الحالي (${formatBHD(currentBalance)}) لا يكفي! إذا كان هذا شراء بالدين، تأكد من تفعيل خيار "شراء الجهاز بالدين" بالأسفل.` 
                  : `Warning: Your current balance (${formatBHD(currentBalance)}) is insufficient! If this is a purchase on debt, make sure to enable the "Buy on debt" option below.`}
              </p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('buy_date', language)}</label>
            <input 
              type="date" value={buyDate} onChange={e => setBuyDate(e.target.value)} lang="en" dir="ltr"
              style={{ fontFamily: 'sans-serif' }}
              className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-left"
            />
          </div>
          
          <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
            <label className="flex items-center gap-3 cursor-pointer p-3 border border-gray-200 dark:border-gray-700 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
              <input 
                type="checkbox" 
                checked={hasWarranty}
                onChange={e => setHasWarranty(e.target.checked)}
                className="w-5 h-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-600 dark:border-gray-600 dark:bg-gray-700"
              />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                {language === 'ar' ? 'يوجد ضمان' : 'Has Warranty'}
              </span>
            </label>
            
            {hasWarranty && (
              <div className="mt-3 animate-in fade-in slide-in-from-top-2 duration-200">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {language === 'ar' ? 'مدة الضمان (بالأشهر)' : 'Warranty Duration (Months)'}
                </label>
                <input 
                  type="number" step="1" min="1" value={warrantyMonths} 
                  onChange={e => setWarrantyMonths(toLatinDigits(e.target.value))} 
                  onKeyDown={(e) => { if (['e', 'E', '+', '-'].includes(e.key)) e.preventDefault(); }}
                  lang="en" dir="ltr"
                  placeholder="12"
                  className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-left"
                />
              </div>
            )}
          </div>
        </div>

        <div className="pt-2 border-t border-gray-100 dark:border-gray-800 space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('purchase_area', language)}</label>
            <input 
              type="text" value={area} onChange={e => setArea(toLatinDigits(e.target.value))}
              
              className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm"
            />
          </div>
                    <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('seller_name', language)}</label>
            <input 
              type="text" value={sellerName} onChange={e => setSellerName(toLatinDigits(e.target.value))}
              placeholder={t('seller_name', language)}
              className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('seller_phone', language)}</label>
            <input 
              type="tel" maxLength={8} value={sellerPhone} onChange={e => {
                const val = toLatinDigits(e.target.value).replace(/\D/g, '');
                if (val.length <= 8) setSellerPhone(val);
              }}
              placeholder="33334444"
              className="w-full p-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl focus:bg-white dark:bg-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('chat_screenshot', language)}</label>
            <input 
              type="file" accept="image/*" onChange={handleImageUpload}
              className="w-full p-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-xl text-sm text-gray-500 dark:text-gray-400 file:me-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
            />
            {chatImage && (
              <div className="mt-3 relative inline-block">
                <img src={chatImage} alt="Chat preview" className="h-24 w-auto rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm" />
                <button 
                  type="button" 
                  onClick={() => setChatImage(null)} 
                  className="absolute -top-2 -end-2 bg-red-500 text-white rounded-full p-1 shadow-md hover:bg-red-600 transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Financing Section */}
        <div className="pt-4 border-t border-gray-100 dark:border-gray-700">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
            {language === 'ar' ? 'طريقة الشراء' : 'Purchase Method'}
          </label>
          <div className="grid grid-cols-2 gap-3 mb-4">
            <button
              type="button"
              onClick={() => setFinancing('personal')}
              className={`p-3 rounded-xl border font-medium transition-colors ${
                financing === 'personal'
                  ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400'
                  : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              {language === 'ar' ? 'من حر مالي' : 'From own money'}
            </button>
            <button
              type="button"
              onClick={() => setFinancing('loan')}
              className={`p-3 rounded-xl border font-medium transition-colors ${
                financing === 'loan'
                  ? 'border-rose-500 bg-rose-50 dark:bg-rose-900/30 text-rose-700 dark:text-rose-400'
                  : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              {language === 'ar' ? 'شراء الجهاز بالدين' : 'Buy on debt'}
            </button>
          </div>

          {financing === 'loan' && (
            <div className="space-y-4 p-4 bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-800 rounded-xl">
              <div>
                <label className="block text-sm font-medium text-rose-700 dark:text-rose-300 mb-1">
                  {language === 'ar' ? 'مبلغ الدين' : 'Debt Amount'}
                </label>
                <input
                  type="number" step="1" min="0"
                  value={loanAmount} onChange={e => { const v = toLatinDigits(e.target.value); if (v === "" || Number(v) <= 10000) setLoanAmount(v); }} 
                  onKeyDown={(e) => { if (['e', 'E', '+', '-'].includes(e.key)) e.preventDefault(); }}
                  lang="en" dir="ltr"
                  className="w-full p-3 bg-white dark:bg-gray-800 border border-rose-200 dark:border-rose-700 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-left"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-rose-700 dark:text-rose-300 mb-1">
                  {language === 'ar' ? 'الدين من عند من؟' : 'Borrowed from who?'}
                </label>
                <select
                  value={loanLender}
                  onChange={e => setLoanLender(e.target.value)}
                  className="w-full p-3 bg-white dark:bg-gray-800 border border-rose-200 dark:border-rose-700 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none"
                  dir={language === 'ar' ? 'rtl' : 'ltr'}
                >
                  <option value="lender_abbas">{language === 'ar' ? 'أعباس' : 'Abbas'}</option>
                  <option value="lender_other">{language === 'ar' ? 'شخص آخر' : 'Other'}</option>
                </select>
                {loanLender === 'lender_other' && (
                  <input
                    type="text" placeholder={language === 'ar' ? 'اكتب اسم الشخص' : 'Enter person name'}
                    onChange={e => setLoanLender(e.target.value)}
                    className="w-full mt-2 p-3 bg-white dark:bg-gray-800 border border-rose-200 dark:border-rose-700 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none"
                  />
                )}
              </div>
            </div>
          )}
        </div>

        <button 
          type="submit"
          disabled={!edition || !version || !buyPrice || (financing === 'loan' && (!loanAmount || !loanLender)) || (sellerPhone.length > 0 && sellerPhone.length !== 8)}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3.5 rounded-xl mt-6 shadow-lg transition-all disabled:opacity-50 disabled:shadow-none"
        >
          حفظ الجهاز
        </button>
      </form>
    </div>
  );
}
