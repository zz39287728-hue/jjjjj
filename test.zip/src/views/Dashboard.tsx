import React, { useState, useMemo } from 'react';
import { useStore } from '../store';
import { formatBHD, toLatinDigits, translateExtra, calculateCurrentBalance } from '../utils';
import { TrendingUp, Package, ShoppingCart, Headset, HardDrive, Gamepad2, Blocks, ArrowUp, ArrowDown, ReceiptText, X, Trophy, ChevronDown } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer } from 'recharts';
import { t } from '../i18n';
import { motion, AnimatePresence } from 'motion/react';
import { Device } from '../types';
import DeviceDetailsModal from '../components/DeviceDetailsModal';

export default function Dashboard({ onNavigate }: { onNavigate?: (tab: any) => void }) {
  type ChartPeriod = 'week' | 'month' | 'last3months' | 'year' | 'all';
  const [chartPeriod, setChartPeriod] = useState<ChartPeriod>('month');
  const [timeFilter, setTimeFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');
  const [showTopProfitable, setShowTopProfitable] = useState(false);
  const [selectedExtra, setSelectedExtra] = useState<{name: string, count: number, devices: Device[]} | null>(null);
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const { devices, generalExpenses, generalDebts, language } = useStore();

  const soldDevices = devices.filter(d => d.status === 'sold');
  const inStockDevices = devices.filter(d => d.status === 'in_stock');

  const totalBaseProfit = soldDevices.reduce((sum, d) => {
    const extraProfit = d.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
    const baseProfit = (d.sellPrice || 0) - d.buyPrice - (d.expenses?.reduce((eSum, e) => eSum + e.amount, 0) || 0);
    return sum + baseProfit + extraProfit;
  }, 0);
  
  const totalLoans = generalDebts.filter(d => d.type === 'lent' && d.status === 'unpaid').reduce((sum, d) => sum + d.amount, 0);
  
  const totalSales = soldDevices.reduce((sum, d) => {
    const extraProfit = d.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
    return sum + (d.sellPrice || 0) + extraProfit;
  }, 0);
  
  const totalDeviceDebt = devices.reduce((sum, d) => sum + (d.loanStatus === 'unpaid' && d.loanAmount ? d.loanAmount : 0), 0);
  const totalGeneralDebt = generalDebts.filter(d => d.type === 'borrowed' && d.status === 'unpaid').reduce((sum, d) => sum + d.amount, 0);
  const totalDebt = totalDeviceDebt + totalGeneralDebt;

  const totalProfit = totalBaseProfit; // Restore totalProfit to just be baseProfit for true profit metric
  const currentBalance = calculateCurrentBalance(devices, generalExpenses, generalDebts);

  // Calculate distinct extras in stock
  const inStockExtras = useMemo(() => {
    const extrasMap: Record<string, { count: number, devices: Device[] }> = {};
    // Extras from devices still in stock
    inStockDevices.forEach(d => {
      if (d.extras && d.extras.length > 0) {
        d.extras.forEach(extra => {
          const lower = extra.toLowerCase();
          if (!extrasMap[lower]) extrasMap[lower] = { count: 0, devices: [] };
          extrasMap[lower].count += 1;
          extrasMap[lower].devices.push(d);
        });
      }
    });
    // Kept extras from sold devices (Extra profits)
    soldDevices.forEach(d => {
      if (d.extras && d.extras.length > 0) {
        const keptExtras = d.extras.filter(e => !d.soldExtras?.includes(e));
        keptExtras.forEach(extra => {
          const lower = extra.toLowerCase();
          if (!extrasMap[lower]) extrasMap[lower] = { count: 0, devices: [] };
          extrasMap[lower].count += 1;
          extrasMap[lower].devices.push(d);
        });
      }
    });
    return Object.entries(extrasMap)
      .map(([name, data]) => ({ name: name.charAt(0).toUpperCase() + name.slice(1), count: data.count, devices: data.devices }))
      .sort((a, b) => b.count - a.count);
  }, [inStockDevices, soldDevices]);

  const transactions = useMemo(() => {
    const txs: { id: string; deviceId?: string; type: 'buy' | 'sell' | 'expense'; title: string; amount: number; date: string; profit?: number }[] = [];
    
    devices.forEach(d => {
      // Purchase transaction
      txs.push({
        id: d.id + '_buy',
        deviceId: d.id,
        type: 'buy',
        title: d.title || d.model,
        amount: d.buyPrice,
        date: d.buyDate
      });
      
      // Sale transaction
      if (d.status === 'sold' && d.sellDate && d.sellPrice) {
        const extraProfit = d.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
        const baseProfit = d.sellPrice - d.buyPrice - (d.expenses?.reduce((eSum, e) => eSum + e.amount, 0) || 0);
        
        txs.push({
          id: d.id + '_sell',
          deviceId: d.id,
          type: 'sell',
          title: d.title || d.model,
          amount: d.sellPrice,
          date: d.sellDate,
          profit: baseProfit + extraProfit
        });
      }
    });

    if (generalExpenses) {
      generalExpenses.forEach(exp => {
        txs.push({
          id: exp.id + '_exp',
          type: 'expense',
          title: exp.title,
          amount: exp.amount,
          date: exp.date
        });
      });
    }
    
    // Sort by date descending
    return txs.sort((a, b) => (b.date > a.date ? 1 : -1));
  }, [devices, generalExpenses]);

  const getExtraIcon = (name: string) => {
    const lower = name.toLowerCase();
    if (lower.includes('headset') || lower.includes('سماعة')) return <Headset className="w-4 h-4" />;
    if (lower.includes('cooler') || lower.includes('مبرد')) return <Blocks className="w-4 h-4" />;
    if (lower.includes('controller') || lower.includes('كنترولر') || lower.includes('يد')) return <Gamepad2 className="w-4 h-4" />;
    return <HardDrive className="w-4 h-4" />;
  }

  
  const topProfitableDevices = useMemo(() => {
    return devices
      .filter(d => d.status === 'sold')
      .map(d => ({
        ...d,
        profit: (d.sellPrice || 0) - d.buyPrice
      }))
      .filter(d => d.profit > 0)
      .sort((a, b) => b.profit - a.profit);
  }, [devices]);

  const filteredTransactions = useMemo(() => {
    const now = new Date();
    // Offset for local timezone to get accurate YYYY-MM-DD
    const offset = now.getTimezoneOffset() * 60000;
    const localNow = new Date(now.getTime() - offset);
    const todayStr = localNow.toISOString().split('T')[0];
    
    // start of week (sunday)
    const startOfWeek = new Date(localNow);
    startOfWeek.setDate(localNow.getDate() - localNow.getDay());
    const startOfWeekStr = startOfWeek.toISOString().split('T')[0];

    const currentMonthStr = localNow.toISOString().slice(0, 7); // YYYY-MM

    return transactions.filter(tx => {
      if (timeFilter === 'all') return true;
      if (timeFilter === 'today') return tx.date === todayStr;
      if (timeFilter === 'month') return tx.date.startsWith(currentMonthStr);
      if (timeFilter === 'week') {
        return tx.date >= startOfWeekStr && tx.date <= todayStr;
      }
      return true;
    });
  }, [transactions, timeFilter]);

  const chartData = useMemo(() => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();

    const monthNamesAr = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    const monthNamesEn = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];

    interface ChartItem {
      name: string;
      buy: number;
      sell: number;
      [key: string]: any;
    }

    if (chartPeriod === 'week') {
      const currentDay = now.getDay(); // 0 is Sunday
      const startOfWeek = new Date(now.getFullYear(), now.getMonth(), now.getDate() - currentDay);
      const daysOfWeekAr = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
      const daysOfWeekEn = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

      const list: ChartItem[] = [];
      for (let i = 0; i < 7; i++) {
        const d = new Date(startOfWeek.getFullYear(), startOfWeek.getMonth(), startOfWeek.getDate() + i);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const dayNum = String(d.getDate()).padStart(2, '0');
        const dateStr = `${y}-${m}-${dayNum}`;
        list.push({
          dateStr,
          name: language === 'ar' ? daysOfWeekAr[i] : daysOfWeekEn[i],
          buy: 0,
          sell: 0,
        });
      }

      transactions.forEach(tx => {
        if (!tx.date) return;
        const match = list.find(item => item.dateStr === tx.date);
        if (match) {
          if (tx.type === 'buy') match.buy += tx.amount;
          if (tx.type === 'sell') match.sell += tx.amount;
        }
      });

      return list;
    }

    if (chartPeriod === 'last3months') {
      const list: ChartItem[] = [];
      for (let i = 2; i >= 0; i--) {
        const d = new Date(currentYear, currentMonth - i, 1);
        const y = d.getFullYear();
        const m = d.getMonth();
        const mName = language === 'ar' ? monthNamesAr[m] : monthNamesEn[m];
        list.push({
          year: y,
          month: m,
          name: mName,
          buy: 0,
          sell: 0,
        });
      }

      transactions.forEach(tx => {
        if (!tx.date) return;
        const parts = tx.date.split('-');
        if (parts.length >= 3) {
          const y = parseInt(parts[0], 10);
          const m = parseInt(parts[1], 10) - 1;
          const match = list.find(item => item.year === y && item.month === m);
          if (match) {
            if (tx.type === 'buy') match.buy += tx.amount;
            if (tx.type === 'sell') match.sell += tx.amount;
          }
        }
      });

      return list;
    }

    if (chartPeriod === 'year') {
      const list: ChartItem[] = [];
      for (let m = 0; m < 12; m++) {
        const mName = language === 'ar' ? monthNamesAr[m] : monthNamesEn[m];
        list.push({
          year: currentYear,
          month: m,
          name: mName,
          buy: 0,
          sell: 0,
        });
      }

      transactions.forEach(tx => {
        if (!tx.date) return;
        const parts = tx.date.split('-');
        if (parts.length >= 3) {
          const y = parseInt(parts[0], 10);
          const m = parseInt(parts[1], 10) - 1;
          if (y === currentYear && list[m]) {
            if (tx.type === 'buy') list[m].buy += tx.amount;
            if (tx.type === 'sell') list[m].sell += tx.amount;
          }
        }
      });

      return list;
    }

    if (chartPeriod === 'all') {
      const list: ChartItem[] = [];
      const years = Array.from(new Set(transactions.map(tx => {
        if (!tx.date) return currentYear;
        return parseInt(tx.date.split('-')[0], 10);
      }))).sort();

      // If no transactions, show current year at least
      if (years.length === 0) years.push(currentYear);

      years.forEach(y => {
        list.push({
          year: y,
          name: `${y}`,
          buy: 0,
          sell: 0,
        });
      });

      transactions.forEach(tx => {
        if (!tx.date) return;
        const parts = tx.date.split('-');
        if (parts.length >= 3) {
          const y = parseInt(parts[0], 10);
          const match = list.find(item => item.year === y);
          if (match) {
            if (tx.type === 'buy') match.buy += tx.amount;
            if (tx.type === 'sell') match.sell += tx.amount;
          }
        }
      });

      return list;
    }

    // Default: 'month' (Current Month)
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const list: ChartItem[] = [];
    for (let i = 1; i <= daysInMonth; i++) {
      list.push({
        day: i,
        name: `${i}`,
        buy: 0,
        sell: 0,
      });
    }

    transactions.forEach(tx => {
      if (!tx.date) return;
      const parts = tx.date.split('-');
      if (parts.length >= 3) {
        const y = parseInt(parts[0], 10);
        const m = parseInt(parts[1], 10) - 1;
        const d = parseInt(parts[2], 10);
        if (y === currentYear && m === currentMonth && list[d - 1]) {
          if (tx.type === 'buy') list[d - 1].buy += tx.amount;
          if (tx.type === 'sell') list[d - 1].sell += tx.amount;
        }
      }
    });

    return list;
  }, [transactions, chartPeriod, language]);

  const periodTotals = useMemo(() => {
    return chartData.reduce(
      (acc, curr) => ({
        buy: acc.buy + (curr.buy || 0),
        sell: acc.sell + (curr.sell || 0),
      }),
      { buy: 0, sell: 0 }
    );
  }, [chartData]);

  const getTooltipLabel = (label: string) => {
    if (chartPeriod === 'week') return label;
    if (chartPeriod === 'month') return `${language === 'ar' ? 'يوم' : 'Day'} ${toLatinDigits(label)}`;
    if (chartPeriod === 'last3months') return label;
    if (chartPeriod === 'year') return `${label} ${new Date().getFullYear()}`;
    if (chartPeriod === 'all') return label;
    return toLatinDigits(label);
  };

  const formatDateLabel = (dateStr: string) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const formatted = date.toLocaleDateString(language === 'ar' ? 'ar-BH-u-nu-latn' : 'en-US', { month: 'short', day: 'numeric' });
    return toLatinDigits(formatted);
  };

  return (
    <div className="p-5 sm:p-6 space-y-6 sm:space-y-8 max-w-5xl mx-auto">
      <div className={`rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden ${currentBalance < 0 ? 'bg-rose-600' : 'bg-indigo-600'}`}>
        <div className="relative z-10 flex flex-col justify-between h-full">
          <div className="text-center">
            <p className="text-white/80 text-sm font-medium mb-1">{language === 'ar' ? 'الرصيد الحالي' : 'Current Balance'}</p>
            <h2 className="text-3xl sm:text-4xl font-bold flex justify-center items-center gap-2" dir="ltr">
              {formatBHD(currentBalance)}
            </h2>
          </div>
          <div className="mt-4 pt-4 border-t border-white/20 flex flex-col sm:flex-row sm:items-center gap-3">
             <div className="flex items-center gap-2">
                <div className={`p-1.5 rounded-lg ${currentBalance < 0 ? 'bg-rose-500/50 text-white' : 'bg-indigo-500/50 text-indigo-100'}`}>
                   <TrendingUp className="w-4 h-4" />
                </div>
                <div className="flex flex-col">
                  <span className={`text-[10px] font-medium uppercase tracking-wider ${currentBalance < 0 ? 'text-rose-200' : 'text-indigo-200'}`}>
                    {language === 'ar' ? 'صافي الأرباح الحقيقية' : 'True Net Profit'}
                  </span>
                  <span className="text-sm font-bold">{formatBHD(totalProfit)}</span>
                </div>
             </div>
             
             {/* Show warnings if user is in debt or has lent money out of pocket */}
             {(totalLoans > 0 || totalDebt > 0) && (
               <div className="flex flex-wrap gap-2 sm:ms-auto">
                 {totalLoans > 0 && (
                   <span className={`text-xs px-2 py-1 rounded-full border bg-black/10 font-medium ${currentBalance < 0 ? 'border-rose-400/30 text-rose-100' : 'border-indigo-400/30 text-indigo-100'}`}>
                     {language === 'ar' ? `لك عند الناس: ${formatBHD(totalLoans)}` : `Lent: ${formatBHD(totalLoans)}`}
                   </span>
                 )}
                 {totalDebt > 0 && (
                   <span className={`text-xs px-2 py-1 rounded-full border bg-black/10 font-medium ${currentBalance < 0 ? 'border-rose-400/30 text-rose-100' : 'border-indigo-400/30 text-indigo-100'}`}>
                     {language === 'ar' ? `ديون عليك: ${formatBHD(totalDebt)}` : `Debt: ${formatBHD(totalDebt)}`}
                   </span>
                 )}
               </div>
             )}
          </div>
        </div>
        <TrendingUp className={`absolute ${language === 'ar' ? '-left-4' : '-right-4'} -bottom-4 w-32 h-32 ${currentBalance < 0 ? 'text-rose-500' : 'text-indigo-500'} opacity-30`} />
      </div>

      <div className="grid grid-cols-2 gap-4 sm:gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white dark:bg-gray-800 p-5 sm:p-6 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700 col-span-2">
          <div className="flex items-center gap-2 mb-3">
            <div className="p-2 bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-lg">
              <ShoppingCart className="w-5 h-5" />
            </div>
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{t('total_sales', language)}</p>
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{formatBHD(totalSales)}</p>
          <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{soldDevices.length} {t('sold_devices', language)}</p>
        </motion.div>

        <motion.button 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ delay: 0.3 }} 
          onClick={() => onNavigate?.('borrowed_list')}
          className="bg-white dark:bg-gray-800 p-5 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700 col-span-1 flex flex-col items-start justify-center text-start cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors active:scale-95"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-xl">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <p className="text-xs sm:text-sm font-medium text-gray-500 dark:text-gray-400">{t('total_debt', language)}</p>
          </div>
          <p className="text-lg sm:text-xl font-bold text-gray-900 dark:text-gray-100">{formatBHD(totalDebt)}</p>
        </motion.button>
        
        <motion.button 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ delay: 0.4 }} 
          onClick={() => onNavigate?.('lent_list')}
          className="bg-white dark:bg-gray-800 p-5 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700 col-span-1 flex flex-col items-start justify-center text-start cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors active:scale-95"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl">
              <ArrowUp className="w-5 h-5" />
            </div>
            <p className="text-xs sm:text-sm font-medium text-gray-500 dark:text-gray-400">{language === 'ar' ? 'إجمالي الإقراض' : 'Total Lending'}</p>
          </div>
          <p className="text-lg sm:text-xl font-bold text-gray-900 dark:text-gray-100">{formatBHD(totalLoans)}</p>
        </motion.button>
      </div>

      
      {/* Top Profitable Devices Option */}
      <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden mb-6">
        <button 
          onClick={() => { setShowTopProfitable(!showTopProfitable); }} 
          className="w-full p-5 sm:p-6 flex justify-between items-center bg-gradient-to-r from-indigo-50/50 to-purple-50/50 hover:from-indigo-50 hover:to-purple-50 dark:from-indigo-900/10 dark:to-purple-900/10 dark:hover:from-indigo-900/20 dark:hover:to-purple-900/20 transition-all text-right"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-yellow-100 to-amber-100 dark:from-yellow-900/40 dark:to-amber-900/40 flex items-center justify-center text-yellow-600 dark:text-yellow-500 shadow-sm">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900 dark:text-gray-100 text-lg mb-0.5">{language === 'ar' ? 'أكثر الأجهزة ربحاً' : 'Top Profitable Devices'}</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400">{language === 'ar' ? 'ما هو أكثر بلايستيشن حصلنا على فائدة منه؟' : 'Which PlayStation gave us the highest profit?'}</p>
            </div>
          </div>
          <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${showTopProfitable ? 'rotate-180' : ''}`} />
        </button>

        <AnimatePresence>
          {showTopProfitable && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              className="overflow-hidden border-t border-gray-100 dark:border-gray-700 bg-gray-50/30 dark:bg-gray-800/30"
            >
              <div className="p-4 sm:p-5 flex flex-col gap-3">
                {topProfitableDevices.length === 0 ? (
                  <p className="text-center text-gray-500 text-sm py-6">{language === 'ar' ? 'لا توجد أجهزة مباعة بربح بعد.' : 'No profitable sold devices yet.'}</p>
                ) : (
                  topProfitableDevices.map((dev, idx) => (
                    <div key={dev.id} className="flex justify-between items-center p-3.5 bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 transition-all hover:border-indigo-200 dark:hover:border-indigo-800">
                       <div className="flex items-center gap-3.5">
                         <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${idx === 0 ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/50 dark:text-yellow-400' : idx === 1 ? 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300' : idx === 2 ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-500' : 'bg-gray-50 text-gray-500 dark:bg-gray-800 dark:text-gray-400 border border-gray-200 dark:border-gray-700'}`}>
                           #{idx + 1}
                         </div>
                         <div className="text-right">
                           <h4 className="font-bold text-sm text-gray-900 dark:text-gray-100 leading-tight mb-1">{dev.title}</h4>
                           <p className="text-[10px] text-gray-500">{dev.model} • {dev.sellDate}</p>
                         </div>
                       </div>
                       <div className="text-left flex flex-col items-end justify-center">
                         <span className="font-bold text-emerald-600 dark:text-emerald-400 text-sm">+{formatBHD(dev.profit)}</span>
                         <span className="text-[10px] text-emerald-600/70 dark:text-emerald-400/70 font-medium">{language === 'ar' ? 'فائدة' : 'Profit'}</span>
                       </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Recent Transactions */}
      <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center flex-wrap gap-3">
          <h3 className="font-bold text-gray-800 dark:text-gray-200">{t('recent_transactions', language)}</h3>
          <div className="flex bg-gray-100 dark:bg-gray-800/50 p-1 rounded-xl">
            <motion.button whileTap={{ scale: 0.9 }} onClick={() => setTimeFilter('all')} className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${timeFilter === 'all' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}>
              {language === 'ar' ? 'الكل' : 'All'}
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }} onClick={() => setTimeFilter('today')} className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${timeFilter === 'today' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}>
              {language === 'ar' ? 'اليوم' : 'Today'}
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }} onClick={() => setTimeFilter('week')} className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${timeFilter === 'week' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}>
              {language === 'ar' ? 'الأسبوع' : 'Week'}
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }} onClick={() => setTimeFilter('month')} className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${timeFilter === 'month' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}`}>
              {language === 'ar' ? 'الشهر' : 'Month'}
            </motion.button>
          </div>
        </div>
        <div className="p-2 sm:p-4">
          {filteredTransactions.slice(0, 10).map((tx, index) => (
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 * index }} key={tx.id} className="flex items-center justify-between gap-4 p-4 sm:p-5 border-b border-gray-50 dark:border-gray-800 last:border-0">
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className={`p-2 rounded-xl flex-shrink-0 ${
                  tx.type === 'sell' ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' : 
                  tx.type === 'buy' ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400' : 
                  'bg-yellow-100 text-yellow-600 dark:bg-yellow-900/30 dark:text-yellow-400'
                }`}>
                  {tx.type === 'sell' && <ArrowUp className="w-5 h-5" />}
                  {tx.type === 'buy' && <ArrowDown className="w-5 h-5" />}
                  {tx.type === 'expense' && <ReceiptText className="w-5 h-5" />}
                </div>
                <div className="flex-1 min-w-0 text-start">
                  <p className="font-semibold text-sm text-gray-900 dark:text-gray-100 line-clamp-2 leading-tight">{tx.title}</p>
                  <div className="flex items-center justify-start gap-2 mt-1">
                    <span className={`text-[10px] sm:text-xs font-medium px-1.5 py-0.5 rounded-md whitespace-nowrap ${
                      tx.type === 'sell' ? 'bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-300' : 
                      tx.type === 'buy' ? 'bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-300' : 
                      'bg-yellow-50 text-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-300'
                    }`}>
                      {tx.type === 'sell' ? t('sold', language) : tx.type === 'buy' ? t('bought', language) : (language === 'ar' ? 'مصروف' : 'Expense')}
                    </span>
                  </div>
                </div>
              </div>
              <div className="text-end flex-shrink-0">
                <span className="block text-[10px] sm:text-xs text-gray-400 dark:text-gray-500 whitespace-nowrap mb-1">{formatDateLabel(tx.date)}</span>
                <p className={`font-bold text-sm sm:text-base ${
                  tx.type === 'sell' ? 'text-green-600 dark:text-green-400' : 
                  tx.type === 'buy' ? 'text-red-600 dark:text-red-400' : 
                  'text-yellow-600 dark:text-yellow-400'
                }`}>
                  {tx.type === 'sell' ? '+' : '-'}{formatBHD(tx.amount)}
                </p>
                {tx.type === 'sell' && tx.profit !== undefined && (
                  <p className={`text-xs mt-0.5 ${tx.profit >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                    {tx.profit >= 0 ? t('profit', language) : (language === 'ar' ? 'خسارة:' : 'Loss:')} {formatBHD(tx.profit)}
                  </p>
                )}
              </div>
            </motion.div>
          ))}
          {filteredTransactions.length === 0 && (
            <div className="p-10 sm:p-12 text-center text-gray-400 dark:text-gray-500 text-sm">
              {t('no_recent', language)}
            </div>
          )}
        </div>
      </div>

      {/* In-Stock Extras */}
      {inStockExtras.length > 0 && (
        <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div className="p-5 sm:p-6 border-b border-gray-100 dark:border-gray-700">
            <h3 className="font-bold text-gray-800 dark:text-gray-200">{t('extras_in_stock', language)}</h3>
          </div>
          <div className="p-5 sm:p-6 flex flex-wrap gap-2">
            {inStockExtras.map(extra => (
              <div 
                key={extra.name} 
                onClick={() => setSelectedExtra(extra)}
                className="flex items-center bg-indigo-50 dark:bg-indigo-900/30 border border-indigo-100 dark:border-indigo-800/50 rounded-lg px-3 py-2 text-sm text-indigo-800 dark:text-indigo-300 cursor-pointer hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-colors"
              >
                <span className="me-2 text-indigo-500">{getExtraIcon(extra.name)}</span>
                <span className="font-medium me-1.5">{language === 'ar' ? translateExtra(extra.name) : extra.name}</span>
                <span className="bg-indigo-200 dark:bg-indigo-800 text-indigo-900 dark:text-indigo-200 text-xs px-1.5 py-0.5 rounded-full font-bold">{extra.count}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Overview Chart - At the end of the page */}
      <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-gray-100 dark:border-gray-700 flex flex-col md:flex-row justify-between md:items-start gap-4">
          <div>
            <h3 className="font-bold text-gray-800 dark:text-gray-200 text-base sm:text-lg mb-3">
              {chartPeriod === 'week' && (language === 'ar' ? 'نظرة عامة على هذا الأسبوع' : 'This Week Overview')}
              {chartPeriod === 'month' && (language === 'ar' ? 'نظرة عامة على الشهر الحالي' : 'Current Month Overview')}
              {chartPeriod === 'last3months' && (language === 'ar' ? 'نظرة عامة على آخر ثلاث أشهر' : 'Last 3 Months Overview')}
              {chartPeriod === 'year' && (language === 'ar' ? 'نظرة عامة على هذه السنة' : 'This Year Overview')}
              {chartPeriod === 'all' && (language === 'ar' ? 'نظرة عامة على كل الوقت' : 'All Time Overview')}
            </h3>
            <div className="flex items-center gap-4 text-xs mt-1">
              <span className="inline-flex items-center gap-2 font-semibold text-blue-600 dark:text-blue-400">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                {language === 'ar' ? 'المشتريات: ' : 'Purchases: '}{formatBHD(periodTotals.buy)}
              </span>
              <span className="inline-flex items-center gap-2 font-semibold text-purple-600 dark:text-purple-400">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                {language === 'ar' ? 'المبيعات: ' : 'Sales: '}{formatBHD(periodTotals.sell)}
              </span>
            </div>
          </div>
          <div className="flex bg-gray-100 dark:bg-gray-800/60 p-1 rounded-xl gap-1 overflow-x-auto max-w-full hide-scrollbar flex-nowrap" dir="rtl">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setChartPeriod('week')}
              className={`px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors shrink-0 ${
                chartPeriod === 'week'
                  ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              {language === 'ar' ? 'أسبوع' : 'This Week'}
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setChartPeriod('month')}
              className={`px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors shrink-0 ${
                chartPeriod === 'month'
                  ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              {language === 'ar' ? 'شهر' : 'Current Month'}
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setChartPeriod('last3months')}
              className={`px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors shrink-0 ${
                chartPeriod === 'last3months'
                  ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              {language === 'ar' ? 'ثلاثة أشهر' : 'Last 3 Months'}
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setChartPeriod('year')}
              className={`px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors shrink-0 ${
                chartPeriod === 'year'
                  ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              {language === 'ar' ? 'سنة' : 'This Year'}
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setChartPeriod('all')}
              className={`px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors shrink-0 ${
                chartPeriod === 'all'
                  ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              {language === 'ar' ? 'كل الوقت' : 'All Time'}
            </motion.button>
          </div>
        </div>
        <div className="p-5 sm:p-6 h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: language === 'ar' ? 20 : 0, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#374151" opacity={0.2} />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: chartPeriod === 'year' ? 10 : 12, fill: '#6B7280' }} dy={10} />
              <YAxis orientation={language === 'ar' ? 'right' : 'left'} axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} tickFormatter={(value) => `${value >= 1000 ? (value / 1000) + 'k' : value}`} />
              <RechartsTooltip 
                cursor={{ fill: 'rgba(107, 114, 128, 0.1)' }}
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)', backgroundColor: 'rgba(31, 41, 55, 0.9)', color: '#fff' }}
                itemStyle={{ fontSize: '14px', fontWeight: 'bold' }}
                formatter={(value: number, name: string) => [formatBHD(value), name === 'buy' ? (language === 'ar' ? 'المشتريات' : 'Purchases') : (language === 'ar' ? 'المبيعات' : 'Sales')]}
                labelFormatter={getTooltipLabel}
              />
              <Legend 
                iconType="circle" 
                wrapperStyle={{ paddingTop: '20px' }}
                formatter={(value) => <span style={{ color: '#9CA3AF', fontSize: '14px', marginInlineStart: '12px', marginInlineEnd: '4px' }}>{value === 'buy' ? (language === 'ar' ? 'المشتريات' : 'Purchases') : (language === 'ar' ? 'المبيعات' : 'Sales')}</span>} 
              />
              <Bar dataKey="buy" fill="#3B82F6" radius={[4, 4, 0, 0]} maxBarSize={chartPeriod === 'last3months' ? 48 : chartPeriod === 'week' ? 36 : chartPeriod === 'year' ? 24 : 32} />
              <Bar dataKey="sell" fill="#8B5CF6" radius={[4, 4, 0, 0]} maxBarSize={chartPeriod === 'last3months' ? 48 : chartPeriod === 'week' ? 36 : chartPeriod === 'year' ? 24 : 32} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      <AnimatePresence>
        {selectedExtra && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-gray-800 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl border border-gray-100 dark:border-gray-700"
            >
              <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center bg-gray-50/50 dark:bg-gray-800/50">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <span className="text-indigo-500">{getExtraIcon(selectedExtra.name)}</span>
                  {language === 'ar' ? translateExtra(selectedExtra.name) : selectedExtra.name}
                  <span className="bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 text-xs px-2 py-0.5 rounded-full font-bold">{selectedExtra.count}</span>
                </h2>
                <button 
                  onClick={() => setSelectedExtra(null)}
                  className="p-2 bg-white dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-full transition-colors text-gray-500 dark:text-gray-400 shadow-sm border border-gray-100 dark:border-gray-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="p-4 max-h-[60vh] overflow-y-auto space-y-3">
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2 px-2">
                  {language === 'ar' ? 'الجهاز المرتبط بهذه الإضافة:' : 'Device with this extra:'}
                </p>
                {selectedExtra.devices.map(device => (
                  <div 
                    key={device.id} 
                    onClick={() => {
                      setSelectedExtra(null);
                      setSelectedDevice(device);
                    }}
                    className="flex justify-between items-center p-4 bg-white dark:bg-gray-800 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 cursor-pointer rounded-2xl transition-all border border-gray-100 dark:border-gray-700 hover:border-indigo-200 dark:hover:border-indigo-800 group shadow-sm hover:shadow"
                  >
                    <div>
                      <h4 className="font-bold text-gray-900 dark:text-gray-100 group-hover:text-indigo-700 dark:group-hover:text-indigo-300 transition-colors">{device.title || device.model}</h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{device.model}</p>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-700 group-hover:bg-indigo-100 dark:group-hover:bg-indigo-800 p-2 rounded-full transition-colors">
                      <ArrowUp className="w-4 h-4 text-gray-400 dark:text-gray-500 group-hover:text-indigo-600 dark:group-hover:text-indigo-300" />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {selectedDevice && (
          <DeviceDetailsModal 
            device={selectedDevice} 
            onClose={() => setSelectedDevice(null)} 
            onImageClick={() => {}} // Ignoring for dashboard
          />
        )}
      </AnimatePresence>
    </div>
  );
}
