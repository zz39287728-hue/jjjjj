import React, { useState } from 'react';
import { useStore } from '../store';
import { formatBHD, formatDate, translateExtra, hapticFeedback, getWhatsAppLink } from '../utils';
import { Package, Trash2, Calendar, Phone, Image as ImageIcon, X, MapPin , User, ArrowLeftRight } from 'lucide-react';
import { Device } from '../types';
import { ErrorBoundary } from '../components/ErrorBoundary';
import DeviceDetailsModal from '../components/DeviceDetailsModal';
import { motion, AnimatePresence } from 'motion/react';
import { createPortal } from 'react-dom';
import { t } from '../i18n';
import { useSwipeable } from 'react-swipeable';

export default function Inventory({ onSellClick }: { onSellClick: (device: Device) => void }) {
  const { devices, deleteDevice, language } = useStore();
  const [tab, setTab] = useState<'in_stock' | 'sold'>('in_stock');
  const [viewingImage, setViewingImage] = useState<string | null>(null);
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [deviceToDelete, setDeviceToDelete] = useState<Device | null>(null);

  const filteredDevices = devices.filter(d => d.status === tab);

  const handlers = useSwipeable({
    onSwipedLeft: (eventData) => {
      eventData.event.stopPropagation();
      // Swiping left (<-) means "go to the tab on the right"
      if (language === 'ar') {
        setTab('in_stock'); // In RTL, in_stock is on the right
      } else {
        setTab('sold'); // In LTR, sold is on the right
      }
    },
    onSwipedRight: (eventData) => {
      eventData.event.stopPropagation();
      // Swiping right (->) means "go to the tab on the left"
      if (language === 'ar') {
        setTab('sold'); // In RTL, sold is on the left
      } else {
        setTab('in_stock'); // In LTR, in_stock is on the left
      }
    },
    trackMouse: true,
    delta: 50
  });

  return (
    <div {...handlers} className="flex flex-col min-h-full">
      <div className="p-4 bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-800 shrink-0 sticky top-0 z-20 shadow-sm">
        <div className="flex p-1 bg-gray-100 rounded-xl relative min-h-[48px]">
          <motion.div
            className="absolute top-1 bottom-1 w-[calc(50%-4px)] bg-white dark:bg-gray-800 rounded-lg shadow-sm origin-left" style={{ [language === 'ar' ? 'right' : 'left']: '4px' }}
            layoutId="tab-indicator"
            initial={false}
            animate={{ x: language === 'ar' ? (tab === 'in_stock' ? 0 : '-100%') : (tab === 'in_stock' ? 0 : '100%') }}
            transition={{ type: "spring", bounce: 0.2, duration: 0.5 }}
          />
          <button
            onClick={() => setTab('in_stock')}
            className={`relative z-10 flex-1 py-3 text-sm font-medium transition-colors min-h-[44px] ${tab === 'in_stock' ? 'text-gray-900 dark:text-gray-100' : 'text-gray-500 dark:text-gray-400'}`}
          >
            {t('in_stock', language)} ({devices.filter(d => d.status === 'in_stock').length})
          </button>
          <button
            onClick={() => setTab('sold')}
            className={`relative z-10 flex-1 py-3 text-sm font-medium transition-colors min-h-[44px] ${tab === 'sold' ? 'text-gray-900 dark:text-gray-100' : 'text-gray-500 dark:text-gray-400'}`}
          >
            {t('sold_tab', language)} ({devices.filter(d => d.status === 'sold').length})
          </button>
        </div>
      </div>

      <div className="p-4">
        {filteredDevices.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center h-40 text-gray-400 dark:text-gray-500"
          >
            <Package className="w-12 h-12 mb-2 opacity-50" />
            <p>{t('no_devices', language)}</p>
          </motion.div>
        ) : (
          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 gap-4"
            initial="hidden"
            animate="visible"
            variants={{
              hidden: {},
              visible: { transition: { staggerChildren: 0.05 } }
            }}
          >
            <AnimatePresence initial={false}>
              {filteredDevices.map(dev => {
                if (dev.status === 'sold') {
                  const extraProfit = dev.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
                  const expenses = dev.expenses?.reduce((eSum, e) => eSum + e.amount, 0) || 0;
                  const totalProfit = (dev.sellPrice || 0) - dev.buyPrice - expenses + extraProfit;
                  
                  return (
                    <motion.div 
                      key={dev.id}
                      layout
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                      onClick={() => { hapticFeedback('light'); setSelectedDevice(dev); }}
                      className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-800 relative cursor-pointer hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors flex flex-col"
                    >
                      {/* Top Header: Title & Dates */}
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1 min-w-0 text-right pr-2">
                          <h3 className="font-bold text-gray-900 dark:text-gray-100 truncate text-sm sm:text-base leading-tight">{dev.title || dev.model}</h3>
                          {dev.title && <p className="text-[11px] text-gray-500 truncate mt-0.5">{dev.model}</p>}
                        </div>
                        <div className="flex items-start gap-2 shrink-0">
                          <div className="flex flex-col items-end text-[10px] text-gray-400 leading-[1.3] pt-0.5" dir="ltr">
                            <div>Buy: {formatDate(dev.buyDate)}</div>
                            {dev.sellDate && <div>Sell: {formatDate(dev.sellDate)}</div>}
                          </div>
                          <button 
                            onClick={(e) => { e.stopPropagation(); hapticFeedback('heavy'); setDeviceToDelete(dev); }} 
                            className="text-gray-400 hover:text-red-500 transition-colors -mt-0.5"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Extras Badges */}
                      {dev.extras && dev.extras.length > 0 && (
                        <div className="flex flex-wrap justify-end gap-1.5 mb-3">
                           {dev.extras.map((extra, idx) => (
                             <span key={idx} className="bg-indigo-50 text-indigo-700 border border-indigo-100 dark:bg-indigo-900/30 dark:border-indigo-800/50 dark:text-indigo-400 text-[10px] px-2 py-0.5 rounded-md font-medium">
                               {translateExtra(extra, language)}
                             </span>
                           ))}
                        </div>
                      )}

                      {/* Contact Info (From / To) */}
                      {(dev.sellerPhone || dev.buyerPhone) && (
                        <div className="flex justify-between items-center text-[11px] bg-gray-50/80 dark:bg-gray-900/40 rounded-xl p-2 mb-3 border border-gray-100 dark:border-gray-800/60">
                           <div className="flex flex-col gap-0.5">
                             <span className="text-gray-400">{language === 'ar' ? 'البائع:' : 'Seller:'}</span>
                             {dev.sellerPhone ? (
                               <a onClick={e=>e.stopPropagation()} href={getWhatsAppLink(dev.sellerPhone)} className="font-semibold text-gray-700 dark:text-gray-300 flex items-center transition-colors hover:text-indigo-600" dir="ltr">
                                 <Phone className="w-3 h-3 mx-0.5"/>{dev.sellerPhone}
                               </a>
                             ) : <span className="text-gray-400">-</span>}
                           </div>
                           
                           <ArrowLeftRight className="w-3.5 h-3.5 text-gray-300 mx-1 shrink-0" />
                           
                           <div className="flex flex-col gap-0.5 text-left">
                             <span className="text-gray-400 text-right">{language === 'ar' ? 'المشتري:' : 'Buyer:'}</span>
                             {dev.buyerPhone ? (
                               <a onClick={e=>e.stopPropagation()} href={getWhatsAppLink(dev.buyerPhone)} className="font-semibold text-gray-700 dark:text-gray-300 flex items-center justify-end transition-colors hover:text-indigo-600" dir="ltr">
                                 {dev.buyerPhone}<Phone className="w-3 h-3 mx-0.5"/>
                               </a>
                             ) : <span className="text-gray-400 text-right">-</span>}
                           </div>
                        </div>
                      )}

                      {/* Pricing Footer */}
                      <div className="flex justify-between items-end pt-3 border-t border-gray-100 dark:border-gray-800/60">
                        <div className="flex gap-4">
                          <div className="text-right">
                            <p className="text-[10px] text-gray-500 mb-0.5">{language === 'ar' ? 'الشراء' : 'Buy'}</p>
                            <p className="text-xs font-bold text-gray-900 dark:text-gray-100">{formatBHD(dev.buyPrice)}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-[10px] text-gray-500 mb-0.5">{language === 'ar' ? 'البيع' : 'Sell'}</p>
                            <p className="text-xs font-bold text-gray-900 dark:text-gray-100">{formatBHD(dev.sellPrice || 0)}</p>
                          </div>
                        </div>
                        
                        <div className="text-left">
                          <p className="text-[10px] text-indigo-500/80 dark:text-indigo-400 mb-0.5 font-medium">{language === 'ar' ? 'الربح الصافي' : 'Net Profit'}</p>
                          <p className={`text-sm font-bold ${totalProfit >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500'}`}>{formatBHD(totalProfit)}</p>
                        </div>
                      </div>
                    </motion.div>
                  );
                }

                return (
                  <motion.div 
                    key={dev.id}
                    layout
                    initial={{ opacity: 0, y: 20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                    onClick={() => { hapticFeedback('light'); setSelectedDevice(dev); }}
                    className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-800 relative cursor-pointer hover:border-blue-200 transition-colors"
                  >
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <h3 className="font-bold text-gray-900 dark:text-gray-100 text-lg">{dev.title || dev.model}</h3>
                        {dev.title && <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{dev.model}</p>}
                        
                        {dev.status === 'in_stock' && dev.extras && dev.extras.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1.5">
                            {dev.extras.map((extra, idx) => (
                              <span key={idx} className="bg-purple-50 text-purple-700 border border-purple-100 text-[10px] px-2 py-0.5 rounded-full font-medium">
                                {translateExtra(extra, language)}
                              </span>
                            ))}
                          </div>
                        )}
                        
                        <div className="flex items-center text-xs text-gray-500 dark:text-gray-400 mt-2 space-x-3 space-x-reverse">
                          <span className="flex items-center">
                            <Calendar className="w-3 h-3 me-1" />
                            {t('buy_date', language)}: {formatDate(dev.buyDate)}
                          </span>
                        </div>
                      </div>
                      <button 
                        onClick={(e) => { e.stopPropagation(); hapticFeedback('heavy'); setDeviceToDelete(dev); }} 
                        className="p-2 text-gray-400 dark:text-gray-500 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {(dev.sellerName || dev.sellerPhone || dev.chatImage || dev.area) && (
                      <div className="mb-6 pt-2 border-t border-gray-50 dark:border-gray-800 flex flex-wrap items-center gap-2">
                        <span className="text-xs text-gray-400 dark:text-gray-500 w-full mb-0.5">{t('bought_from', language)}</span>
                        {dev.area && (
                          <span className="flex items-center text-xs text-gray-600 dark:text-gray-300 bg-gray-50 dark:bg-gray-700 px-2 py-1 rounded-md border border-gray-100 dark:border-gray-800">
                            <MapPin className="w-3 h-3 me-1.5" /> {dev.area}
                          </span>
                        )}
                        
                        {dev.sellerName && (
                          <span className="flex items-center text-xs text-gray-600 dark:text-gray-300 bg-gray-50 dark:bg-gray-700 px-2 py-1 rounded-md border border-gray-100 dark:border-gray-800">
                            <User className="w-3 h-3 me-1.5" /> {dev.sellerName}
                          </span>
                        )}
                        {dev.sellerPhone && (
                          <a 
                            href={getWhatsAppLink(dev.sellerPhone)} 
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={e => e.stopPropagation()}
                            className="flex items-center text-xs text-gray-600 dark:text-gray-300 bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 px-2 py-1 rounded-md transition-colors border border-gray-100 dark:border-gray-800"
                          >
                            <Phone className="w-3 h-3 me-1.5" /> {dev.sellerPhone}
                          </a>
                        )}
                        {dev.chatImage && (
                          <button 
                            onClick={(e) => { e.stopPropagation(); setViewingImage(dev.chatImage!); }} 
                            className="flex items-center text-xs text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2 py-1 rounded-md transition-colors border border-indigo-100"
                          >
                            <ImageIcon className="w-3 h-3 me-1.5" /> {t('view_chat', language)}
                          </button>
                        )}
                      </div>
                    )}

                    <div className="flex justify-between items-end border-t border-gray-50 dark:border-gray-800 pt-3">
                      <div>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('buy_cost', language)}</p>
                        <p className="font-semibold text-gray-900 dark:text-gray-100">{formatBHD(dev.buyPrice)}</p>
                      </div>
                      
                      <button 
                        onClick={(e) => { e.stopPropagation(); onSellClick(dev); }}
                        className="bg-indigo-600 text-white px-5 py-2 rounded-xl text-sm font-medium shadow-md"
                      >
                        {t('sell_device', language)}
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </motion.div>
        )}
      </div>

      <AnimatePresence>
        {viewingImage && document.getElementById('modal-root') && createPortal(
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[100] bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm pointer-events-auto" 
            onClick={() => setViewingImage(null)}
          >
            <button className="absolute top-4 right-4 bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition-colors">
              <X className="w-6 h-6" />
            </button>
            <motion.img 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", damping: 20, stiffness: 300 }}
              src={viewingImage} 
              alt="Chat screenshot" 
              className="max-w-full max-h-[90vh] rounded-xl shadow-2xl" 
              onClick={e => e.stopPropagation()} 
            />
          </motion.div>,
          document.getElementById('modal-root')!
        )}
      </AnimatePresence>

      <AnimatePresence>
        {selectedDevice && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 pointer-events-auto"
            onClick={() => setSelectedDevice(null)}
          >
            <div className="bg-transparent w-full h-full absolute inset-0" />
            <div onClick={e => e.stopPropagation()} className="w-full max-w-[400px] h-full flex flex-col justify-end sm:justify-center z-10">
              <ErrorBoundary>
                <DeviceDetailsModal 
                  device={selectedDevice} 
                  onClose={() => setSelectedDevice(null)} 
                  onImageClick={(img) => setViewingImage(img)}
                />
              </ErrorBoundary>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deviceToDelete && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 pointer-events-auto"
            onClick={() => setDeviceToDelete(null)}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              className="bg-white dark:bg-gray-800 rounded-2xl p-6 w-full max-w-sm shadow-2xl relative z-10"
              onClick={e => e.stopPropagation()}
            >
              <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">{t('delete_device', language)}</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6 text-sm">{t('are_you_sure_delete', language)}</p>
              <div className="flex space-x-3 space-x-reverse">
                <button 
                  onClick={() => setDeviceToDelete(null)}
                  className="flex-1 py-2.5 rounded-xl font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  {t('cancel', language)}
                </button>
                <button 
                  onClick={() => {
                    deleteDevice(deviceToDelete.id);
                    setDeviceToDelete(null);
                  }}
                  className="flex-1 py-2.5 rounded-xl font-medium text-white bg-red-600 hover:bg-red-700 transition-colors shadow-sm shadow-red-200 dark:shadow-none"
                >
                  {t('delete', language)}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deviceToDelete && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 pointer-events-auto"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              className="bg-white dark:bg-gray-800 rounded-2xl p-6 w-full max-w-sm shadow-2xl"
            >
              <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">{t('delete_device', language)}</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6 text-sm">{t('are_you_sure_delete', language)}</p>
              <div className="flex space-x-3 space-x-reverse">
                <button 
                  onClick={() => setDeviceToDelete(null)}
                  className="flex-1 py-2.5 rounded-xl font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  {t('cancel', language)}
                </button>
                <button 
                  onClick={() => {
                    deleteDevice(deviceToDelete.id);
                    setDeviceToDelete(null);
                  }}
                  className="flex-1 py-2.5 rounded-xl font-medium text-white bg-red-600 hover:bg-red-700 transition-colors shadow-sm shadow-red-200 dark:shadow-none"
                >
                  {t('delete', language)}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
