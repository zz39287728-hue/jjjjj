import React, { useEffect, useState } from 'react';
import { Gamepad2 } from 'lucide-react';

export default function SplashScreen({ onComplete }: { onComplete: () => void, key?: string }) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onComplete, 500);
    }, 2500);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className={`absolute inset-0 z-[100] flex flex-col items-center justify-center bg-gradient-to-br from-indigo-950 via-purple-900 to-indigo-950 transition-opacity duration-500 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
      <div className="flex flex-col items-center animate-in zoom-in-75 fade-in duration-1000 slide-in-from-bottom-4">
        <div className="w-24 h-24 bg-white/10 rounded-3xl backdrop-blur-md flex items-center justify-center mb-6 shadow-2xl border border-white/20">
          <Gamepad2 className="w-12 h-12 text-white" strokeWidth={1.5} />
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight mb-2 uppercase">Inventory</h1>
        <p className="text-purple-200 font-medium tracking-widest text-sm uppercase">Manager</p>
      </div>
      
      <div className="absolute bottom-16 flex flex-col items-center space-y-3">
        <div className="flex space-x-1.5">
          <div className="w-2 h-2 bg-white/50 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
          <div className="w-2 h-2 bg-white/50 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
          <div className="w-2 h-2 bg-white/50 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
        </div>
      </div>
    </div>
  );
}
