import React, { useState } from 'react';
import { usePWAInstall } from '../usePWAInstall';
import { Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={install}
        className="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 rounded-xl transition-colors text-start w-full"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg">
            <Download className="w-5 h-5" />
          </div>
          <span className="font-medium text-gray-700 dark:text-gray-200">تثبيت التطبيق (Install App)</span>
        </div>
      </motion.button>
    );
  }

  if (isIOS) {
    return (
      <>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 rounded-xl transition-colors text-start w-full"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg">
              <Download className="w-5 h-5" />
            </div>
            <span className="font-medium text-gray-700 dark:text-gray-200">تثبيت التطبيق (Install on iOS)</span>
          </div>
        </motion.button>

        <AnimatePresence>
          {showIOSGuide && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
              <motion.div initial={{ scale: 0.9, y: 50 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 50 }} className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-xl dark:bg-gray-800">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">تثبيت على iPhone / iPad</h3>
                <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                  1. اضغط على زر <strong>المشاركة (Share)</strong> في الأسفل.<br /><br />
                  2. انزل للأسفل واضغط على <strong>إضافة للشاشة الرئيسية (Add to Home Screen)</strong>.
                </p>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="mt-6 w-full rounded-xl bg-gray-100 py-3 text-sm font-medium text-gray-800 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200"
                >
                  إغلاق
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </>
    );
  }

  return null;
};
