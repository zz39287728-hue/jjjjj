import React, { useRef, useState } from 'react';
import { useStore } from '../store';
import { X, Languages, Moon, Sun, Download, Upload, MonitorSmartphone, Database, Users, Share2, LogIn, LogOut, FileText, Bug, Zap } from 'lucide-react';
import { t } from '../i18n';
import { PWAInstallButton } from './PWAInstallButton';
import { motion } from 'motion/react';
import { generateTransactionsPDF } from '../utils/pdfExport';

export default function SettingsModal({ onClose }: { onClose: () => void }) {
  const { user, logOut } = useStore();
  const { language, setLanguage, theme, setTheme, turboMode, setTurboMode, devices, generalExpenses, generalDebts, importDevices, importAllData, activeWorkspaceId, generateInviteCode, joinWorkspace, clearWorkspace, errors, clearErrors, markErrorsAsSeen } = useStore();
  const [inviteLink, setInviteLink] = React.useState('');
  const [joinLink, setJoinLink] = React.useState('');
  const [isExportingPDF, setIsExportingPDF] = useState(false);
  const [showErrorLog, setShowErrorLog] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const unseenErrorsCount = errors.filter(e => !e.seen).length;

  const handleExportPDF = async () => {
    setIsExportingPDF(true);
    try {
      await generateTransactionsPDF(devices, generalExpenses, language);
    } catch (error) {
      console.error(error);
      alert('Failed to generate PDF');
    } finally {
      setIsExportingPDF(false);
    }
  };

  const handleExport = () => {
    const backupData = {
      version: 1,
      timestamp: new Date().toISOString(),
      devices,
      generalExpenses,
      generalDebts
    };
    const dataStr = JSON.stringify(backupData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    // Generate filename with date
    const date = new Date();
    const dateString = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    const exportFileDefaultName = `inventory_backup_${dateString}.json`;

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const obj = JSON.parse(event.target?.result as string);
        
        // Handle new backup format (object with devices, generalExpenses, etc.)
        if (obj && !Array.isArray(obj) && (obj.devices || obj.generalExpenses || obj.generalDebts)) {
          await importAllData({
            devices: obj.devices || [],
            generalExpenses: obj.generalExpenses || [],
            generalDebts: obj.generalDebts || []
          });
          alert(language === 'ar' ? 'تم استيراد كافة البيانات بنجاح!' : 'All data imported successfully!');
        } 
        // Handle old backup format (array of devices only)
        else if (Array.isArray(obj)) {
          await importAllData({ devices: obj });
          alert(language === 'ar' ? 'تم استيراد بيانات المخزون القديمة بنجاح!' : 'Legacy inventory data imported successfully!');
        } else {
          alert(language === 'ar' ? 'صيغة الملف غير صحيحة' : 'Invalid file format');
        }
      } catch (err) {
        alert(language === 'ar' ? 'فشل في قراءة الملف' : 'Failed to parse file');
      }
    };
    reader.readAsText(file);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[60] flex items-end justify-center sm:items-center bg-black/40 backdrop-blur-sm sm:p-4 pointer-events-auto">
      <motion.div initial={{ y: 50, scale: 0.95 }} animate={{ y: 0, scale: 1 }} exit={{ y: 50, scale: 0.95 }} className="w-full sm:w-[400px] h-[100dvh] sm:h-auto sm:max-h-[85vh] bg-gray-50 dark:bg-gray-900 rounded-none sm:rounded-3xl shadow-2xl flex flex-col">
        <div className="flex items-center justify-between p-5 border-b border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-800 rounded-none sm:rounded-t-3xl shrink-0">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center">
            {showErrorLog ? (language === 'ar' ? 'سجل الأخطاء' : 'Error Logs') : t('settings', language)}
          </h2>
          <button 
            onClick={showErrorLog ? () => setShowErrorLog(false) : onClose}
            className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {showErrorLog ? (
          <div className="flex-1 overflow-y-auto p-5 space-y-6">
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-2 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col h-full">
              {errors.length === 0 ? (
                <div className="p-4 text-center text-sm text-gray-500">
                  {language === 'ar' ? 'لا توجد أخطاء مسجلة.' : 'No errors logged.'}
                </div>
              ) : (
                <>
                  <div className="p-2 flex justify-between items-center border-b border-gray-100 dark:border-gray-700 mb-2">
                    <span className="text-xs text-gray-500">{errors.length} {language === 'ar' ? 'أخطاء' : 'Errors'}</span>
                    <button 
                      onClick={() => clearErrors()}
                      className="text-xs text-red-500 font-bold hover:text-red-700"
                    >
                      {language === 'ar' ? 'مسح السجل' : 'Clear Logs'}
                    </button>
                  </div>
                  <div className="space-y-2 overflow-y-auto">
                    {errors.map(err => (
                      <div key={err.id} className="p-2 bg-red-50 dark:bg-red-900/10 rounded-lg text-left" dir="ltr">
                        <div className="flex justify-between items-start">
                          <span className="font-mono text-xs font-bold text-red-600 dark:text-red-400">{err.code}</span>
                          <span className="text-[10px] text-gray-400">{new Date(err.timestamp).toLocaleString()}</span>
                        </div>
                        <p className="text-xs text-gray-700 dark:text-gray-300 mt-1 break-words">{err.message}</p>
                        {err.path && <p className="text-[10px] text-gray-500 mt-1 border-t border-red-100 dark:border-red-900/30 pt-1">Path: {err.path}</p>}
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-5 space-y-6">
          
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
              <MonitorSmartphone className="w-4 h-4" />
              {t('appearance', language)}
            </h3>
            
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg">
                    <Languages className="w-5 h-5" />
                  </div>
                  <span className="font-medium text-gray-700 dark:text-gray-200">{t('language', language)}</span>
                </div>
                <div className="flex bg-gray-100 dark:bg-gray-900 rounded-lg p-1">
                  <button 
                    onClick={() => setLanguage('en')}
                    className={`px-3 py-1 text-sm font-medium rounded-md transition-all ${language === 'en' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}
                  >
                    ENG
                  </button>
                  <button 
                    onClick={() => setLanguage('ar')}
                    className={`px-3 py-1 text-sm font-medium rounded-md transition-all ${language === 'ar' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}
                  >
                    عربي
                  </button>
                </div>
              </div>

              <div className="h-px bg-gray-100 dark:bg-gray-700 w-full" />

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-lg">
                    {theme === 'dark' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                  </div>
                  <span className="font-medium text-gray-700 dark:text-gray-200">{t('theme', language)}</span>
                </div>
                <div className="flex bg-gray-100 dark:bg-gray-900 rounded-lg p-1">
                  <button 
                    onClick={() => setTheme('light')}
                    className={`p-2 text-sm font-medium rounded-md transition-all flex items-center justify-center ${theme === 'light' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}
                  >
                    <Sun className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setTheme('dark')}
                    className={`p-2 text-sm font-medium rounded-md transition-all flex items-center justify-center ${theme === 'dark' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}
                  >
                    <Moon className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="h-px bg-gray-100 dark:bg-gray-700 w-full" />

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg">
                    <Zap className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col">
                    <span className="font-medium text-gray-700 dark:text-gray-200">
                      {language === 'ar' ? 'وضع التيربو' : 'Turbo Mode'}
                    </span>
                  </div>
                </div>
                <div className="flex bg-gray-100 dark:bg-gray-900 rounded-lg p-1">
                  <button 
                    onClick={() => setTurboMode(!turboMode)}
                    className={`px-3 py-1 text-sm font-medium rounded-md transition-all flex items-center gap-1 ${turboMode ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}
                  >
                    {turboMode ? (language === 'ar' ? 'مفعل' : 'On') : (language === 'ar' ? 'معطل' : 'Off')}
                  </button>
                </div>
              </div>
            </div>
          </div>



          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
              <Users className="w-4 h-4" />
              {language === 'ar' ? 'مشاركة مساحة العمل' : 'Workspace Sharing'}
            </h3>
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col gap-4">
              
              {activeWorkspaceId && activeWorkspaceId !== user?.uid ? (
                <div className="flex flex-col gap-3">
                  <div className="p-3 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl text-indigo-800 dark:text-indigo-200 text-sm">
                    {language === 'ar' ? 'أنت متصل بمساحة عمل مشتركة.' : 'You are connected to a shared workspace.'}
                  </div>
                  <button 
                    onClick={() => clearWorkspace()}
                    className="flex items-center justify-center gap-2 p-3 bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-400 hover:bg-red-200 transition-colors rounded-xl font-medium"
                  >
                    <LogOut className="w-4 h-4" />
                    {language === 'ar' ? 'الخروج من مساحة العمل' : 'Leave Workspace'}
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col gap-2">
                    <button 
                      onClick={async () => {
                        const code = await generateInviteCode();
                        if (code) {
                          setInviteLink(code);
                        }
                      }}
                      className="flex items-center justify-center gap-2 p-3 bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-400 hover:bg-indigo-200 transition-colors rounded-xl font-medium"
                    >
                      <Share2 className="w-4 h-4" />
                      {language === 'ar' ? 'إنشاء رمز دعوة' : 'Generate Invite Code'}
                    </button>
                    {inviteLink && (
                      <div className="flex flex-col gap-2">
                        <input type="text" readOnly value={inviteLink} className="w-full p-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg text-sm text-gray-600 dark:text-gray-400 text-center font-mono" />
                        <button onClick={() => { navigator.clipboard.writeText(inviteLink); alert(language === 'ar' ? 'تم النسخ!' : 'Copied!'); }} className="text-xs text-indigo-600 dark:text-indigo-400 font-medium self-end">
                          {language === 'ar' ? 'نسخ الرمز' : 'Copy Code'}
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="h-px bg-gray-100 dark:bg-gray-700" />

                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {language === 'ar' ? 'لصق رمز الدعوة للإنضمام' : 'Paste invite code to join'}
                    </label>
                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        value={joinLink} 
                        onChange={e => setJoinLink(e.target.value)}
                        placeholder="Paste code..." 
                        className="flex-1 p-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg text-sm text-gray-900 dark:text-gray-100 font-mono" 
                      />
                      <button 
                        onClick={async () => {
                          if (!joinLink.trim()) return;
                          const success = await joinWorkspace(joinLink.trim());
                          if (success) {
                            alert(language === 'ar' ? 'تم الانضمام بنجاح!' : 'Joined successfully!');
                            setJoinLink('');
                          }
                        }}
                        className="px-3 py-2 bg-gray-900 dark:bg-gray-700 text-white rounded-lg text-sm font-medium"
                      >
                        {language === 'ar' ? 'انضمام' : 'Join'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
              <Database className="w-4 h-4" />
              {language === 'ar' ? 'البيانات والتقارير' : 'Data & Reports'}
            </h3>
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-2 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col">
              <button 
                onClick={handleExportPDF}
                disabled={isExportingPDF}
                className="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 rounded-xl transition-colors text-start disabled:opacity-50"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-medium text-gray-700 dark:text-gray-200 block">
                      {isExportingPDF 
                        ? (language === 'ar' ? 'جاري التصدير...' : 'Exporting...') 
                        : (language === 'ar' ? 'تقرير المحاسبة (PDF)' : 'Accounting Report (PDF)')}
                    </span>
                    <span className="text-xs text-gray-500 dark:text-gray-400 block mt-0.5">
                      {language === 'ar' ? 'تصدير سجل المعاملات بالكامل كملف PDF' : 'Export full transaction history as PDF'}
                    </span>
                  </div>
                </div>
              </button>
            </div>
          </div>
  

          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
              <Bug className="w-4 h-4" />
              {language === 'ar' ? 'سجل الأخطاء' : 'Error Logs'}
            </h3>
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-2 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col">
              <button 
                onClick={() => {
                  markErrorsAsSeen();
                  setShowErrorLog(true);
                }}
                className="w-full text-left p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 rounded-xl transition-colors flex items-center justify-between group"
              >
                <div className="flex items-center gap-3 w-full">
                  <div className="p-2 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg group-hover:scale-110 transition-transform relative shrink-0">
                    <Bug className="w-5 h-5" />
                    {unseenErrorsCount > 0 && (
                      <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white shadow-sm ring-2 ring-white dark:ring-gray-800">
                        {unseenErrorsCount > 9 ? '9+' : unseenErrorsCount}
                      </span>
                    )}
                  </div>
                  <div className="text-start">
                    <span className="font-medium text-gray-700 dark:text-gray-200 block">
                      {language === 'ar' ? 'عرض سجل الأخطاء' : 'View Error Logs'}
                    </span>
                    <span className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 block">
                      {errors.length} {language === 'ar' ? 'أخطاء مسجلة' : 'Logged errors'}
                    </span>
                  </div>
                </div>
              </button>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
              <LogOut className="w-4 h-4" />
              {language === 'ar' ? 'الحساب' : 'Account'}
            </h3>
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-2 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col">
              <button 
                onClick={logOut}
                className="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 rounded-xl transition-colors text-start"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                    </svg>
                  </div>
                  <span className="font-medium text-red-600 dark:text-red-400">{language === 'ar' ? 'تسجيل الخروج' : 'Log Out'}</span>
                </div>
              </button>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
              <Database className="w-4 h-4" />
              {t('data_management', language)}
            </h3>
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-2 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col">
              
              <button 
                onClick={handleExport}
                className="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 rounded-xl transition-colors text-start"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg">
                    <Download className="w-5 h-5" />
                  </div>
                  <span className="font-medium text-gray-700 dark:text-gray-200">{t('export_data', language)}</span>
                </div>
              </button>

              <div className="h-px bg-gray-100 dark:bg-gray-700 mx-3" />

              <button 
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 rounded-xl transition-colors text-start"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-lg">
                    <Upload className="w-5 h-5" />
                  </div>
                  <span className="font-medium text-gray-700 dark:text-gray-200">{t('import_data', language)}</span>
                </div>
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImport} 
                accept=".json" 
                className="hidden" 
              />

            </div>
          </div>

        </div>
        )}
      </motion.div>
    </motion.div>
  );
}
