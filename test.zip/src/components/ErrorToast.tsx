import React, { useEffect, useState } from 'react';
import { useStore } from '../store';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, X } from 'lucide-react';
import { hapticFeedback } from '../utils';

export default function ErrorToast() {
  const { errors, language } = useStore();
  const [visibleErrors, setVisibleErrors] = useState<string[]>([]); // Store IDs of visible errors

  useEffect(() => {
    if (errors.length > 0) {
      const latestError = errors[0];
      // Check if we haven't shown it yet based on timestamp (simplistic check: if it's less than 2 seconds old)
      const errorAge = Date.now() - new Date(latestError.timestamp).getTime();
      if (errorAge < 2000 && !visibleErrors.includes(latestError.id)) {
        hapticFeedback('error');
        setVisibleErrors(prev => [...prev, latestError.id]);
        
        // Auto dismiss after 5 seconds
        setTimeout(() => {
          setVisibleErrors(prev => prev.filter(id => id !== latestError.id));
        }, 5000);
      }
    }
  }, [errors]);

  const dismissError = (id: string) => {
    hapticFeedback('light');
    setVisibleErrors(prev => prev.filter(eId => eId !== id));
  };

  return (
    <div className="fixed top-4 inset-x-0 z-[100] flex flex-col items-center gap-2 pointer-events-none px-4">
      <AnimatePresence>
        {visibleErrors.map(errorId => {
          const error = errors.find(e => e.id === errorId);
          if (!error) return null;
          
          return (
            <motion.div
              key={error.id}
              initial={{ opacity: 0, y: -50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              className="pointer-events-auto flex items-center justify-between gap-4 bg-red-500 text-white px-4 py-3 rounded-2xl shadow-lg w-full max-w-sm"
            >
              <div className="flex items-center gap-3">
                <div className="bg-red-600 rounded-full p-2">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div className="flex flex-col">
                  <span className="font-bold text-sm">
                    {language === 'ar' ? 'حدث خطأ' : 'Error Occurred'} ({error.code})
                  </span>
                  <span className="text-xs text-red-100 truncate max-w-[200px]">
                    {error.message}
                  </span>
                </div>
              </div>
              <button 
                onClick={() => dismissError(error.id)}
                className="p-1.5 hover:bg-red-600 rounded-full transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
