import React, { createContext, useContext, useState, useEffect } from 'react';
import { Device, GeneralExpense, GeneralDebt, AppError } from './types';
import { Language } from './i18n';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, User } from 'firebase/auth';
import { collection, query, where, onSnapshot, doc, setDoc, updateDoc, deleteDoc, writeBatch } from 'firebase/firestore';

export type Theme = 'light' | 'dark';

interface StoreContextType {
  devices: Device[];
  generalExpenses: GeneralExpense[];
  generalDebts: GeneralDebt[];
  language: Language;
  theme: Theme;
  turboMode: boolean;
  user: User | null;
  authLoading: boolean;
  signIn: () => Promise<void>;
  logOut: () => Promise<void>;
  setLanguage: (lang: Language) => void;
  setTheme: (theme: Theme) => void;
  setTurboMode: (mode: boolean) => void;
  importDevices: (devices: Device[]) => void;
  importAllData: (data: { devices?: Device[], generalExpenses?: GeneralExpense[], generalDebts?: GeneralDebt[] }) => Promise<void>;
  addDevice: (d: Omit<Device, 'id' | 'status'>) => Promise<void>;
  updateDevice: (id: string, updates: Partial<Device>) => Promise<void>;
  sellDevice: (id: string, sellPrice: number, sellDate: string, buyerName?: string, buyerPhone?: string, buyerArea?: string, soldExtras?: string[], sellMethod?: 'cash' | 'benefit' | 'mixed', cashAmount?: number, benefitAmount?: number) => Promise<void>;
  deleteDevice: (id: string) => Promise<void>;
  addGeneralExpense: (expense: Omit<GeneralExpense, 'id'>) => Promise<void>;
  updateGeneralExpense: (id: string, updates: Partial<GeneralExpense>) => Promise<void>;
  deleteGeneralExpense: (id: string) => Promise<void>;
  addGeneralDebt: (debt: Omit<GeneralDebt, 'id'>) => Promise<void>;
  updateGeneralDebt: (id: string, updates: Partial<GeneralDebt>) => Promise<void>;
  deleteGeneralDebt: (id: string) => Promise<void>;
  activeWorkspaceId: string;
  setActiveWorkspaceId: (id: string) => void;
  generateInviteCode: () => Promise<string>;
  joinWorkspace: (pairingCode: string) => Promise<boolean>;
  clearWorkspace: () => void;
  errors: AppError[];
  logError: (code: string, message: string, details?: string) => void;
  clearErrors: () => void;
  markErrorsAsSeen: () => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

export const StoreProvider = ({ children }: { children: React.ReactNode }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      


  return (
localStorage.getItem('ps_lang') as Language) || 'ar';
    } catch {
      return 'ar';
    }
  });

  const [theme, setThemeState] = useState<Theme>(() => {
    try {
      return (localStorage.getItem('ps_theme') as Theme) || 'light';
    } catch {
      return 'light';
    }
  });

  const [turboMode, setTurboModeState] = useState<boolean>(() => {
    try {
      return localStorage.getItem('ps_lite') === 'true';
    } catch {
      return false;
    }
  });

  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [errors, setErrors] = useState<AppError[]>(() => {
    try {
      const stored = localStorage.getItem('ps_errors');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const logError = async (code: string, message: string, details?: string) => {
    const errorId = Math.random().toString(36).substr(2, 9);
    const newError = {
      id: errorId,
      code,
      message,
      timestamp: new Date().toISOString(),
      details: details || '',
      path: window.location.pathname
    };

    setErrors(prev => {
      const newErrors = [newError, ...prev].slice(0, 50);
      localStorage.setItem('ps_errors', JSON.stringify(newErrors));
      return newErrors;
    });

    window.dispatchEvent(new CustomEvent('app-error', { detail: { code, message } }));

    // Async cloud logging
    if (auth.currentUser) {
      try {
        await setDoc(doc(db, 'appErrors', errorId), {
          ...newError,
          userId: auth.currentUser.uid,
          userEmail: auth.currentUser.email,
          workspaceId: activeWorkspaceId || auth.currentUser.uid,
          userAgent: navigator.userAgent
        });
      } catch (e) {
        console.warn("Failed to log error to cloud:", e);
      }
    }
  };

  useEffect(() => {
    const handleAppError = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        logError(customEvent.detail.code || 'UNKNOWN_ERROR', customEvent.detail.message || 'Unknown error occurred', customEvent.detail.details);
      }
    };
    
    const handleGlobalError = (e: ErrorEvent) => {
      logError('GLOBAL_ERROR', e.message, e.filename + ':' + e.lineno);
    };

    const handleUnhandledRejection = (e: PromiseRejectionEvent) => {
      logError('UNHANDLED_REJECTION', e.reason?.message || String(e.reason), JSON.stringify(e.reason));
    };

    window.addEventListener('app-error', handleAppError);
    window.addEventListener('error', handleGlobalError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    return () => {
      window.removeEventListener('app-error', handleAppError);
      window.removeEventListener('error', handleGlobalError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, []);

  const clearErrors = () => {
    setErrors([]);
    localStorage.removeItem('ps_errors');
  };

  const markErrorsAsSeen = () => {
    setErrors(prev => {
      const newErrors = prev.map(e => ({ ...e, seen: true }));
      localStorage.setItem('ps_errors', JSON.stringify(newErrors));
      return newErrors;
    });
  };

  const [activeWorkspaceId, setActiveWorkspaceIdState] = useState<string>(() => {
    try {
      return localStorage.getItem('activeWorkspaceId') || '';
    } catch {
      return '';
    }
  });

  const setActiveWorkspaceId = (id: string) => {
    localStorage.setItem('activeWorkspaceId', id);
    setActiveWorkspaceIdState(id);
  };
  const clearWorkspace = () => {
    localStorage.removeItem('activeWorkspaceId');
    setActiveWorkspaceIdState('');
  };
  
  const [devices, setDevices] = useState<Device[]>([]);
  const [generalExpenses, setGeneralExpenses] = useState<GeneralExpense[]>([]);
  const [generalDebts, setGeneralDebts] = useState<GeneralDebt[]>([]);

  useEffect(() => {
    localStorage.setItem('ps_lang', language);
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    localStorage.setItem('ps_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const setLanguage = (lang: Language) => setLanguageState(lang);
  const setTheme = (t: Theme) => setThemeState(t);
  const setTurboMode = (mode: boolean) => {
    setTurboModeState(mode);
    localStorage.setItem('ps_lite', String(mode));
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) {
      setDevices([]);
      setGeneralExpenses([]);
      setGeneralDebts([]);
      return;
    }

    const workspaceId = activeWorkspaceId || user.uid;
    const unsubDevices = onSnapshot(query(collection(db, 'devices'), where('userId', '==', workspaceId)), (snapshot) => {
      const devs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Device);
      setDevices(devs.sort((a, b) => (b.buyDate > a.buyDate ? 1 : -1)));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'devices'));

    const unsubExpenses = onSnapshot(query(collection(db, 'generalExpenses'), where('userId', '==', workspaceId)), (snapshot) => {
      const exps = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as GeneralExpense);
      setGeneralExpenses(exps.sort((a, b) => (b.date > a.date ? 1 : -1)));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'generalExpenses'));

    const unsubDebts = onSnapshot(query(collection(db, 'generalDebts'), where('userId', '==', workspaceId)), (snapshot) => {
      const debts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as GeneralDebt);
      setGeneralDebts(debts.sort((a, b) => (b.date > a.date ? 1 : -1)));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'generalDebts'));

    return () => {
      unsubDevices();
      unsubExpenses();
      unsubDebts();
    };
  }, [user, activeWorkspaceId]);

  const signIn = async () => {
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      await signInWithPopup(auth, provider);
      
      const localDevices = JSON.parse(localStorage.getItem('ps_devices') || '[]');
      if (localDevices.length > 0 && auth.currentUser) {
        const batch = writeBatch(db);
        localDevices.forEach((dev: any) => {
          const newDoc = doc(collection(db, 'devices'));
          const deviceToSave: Device = {
            ...dev,
            id: newDoc.id,
            userId: auth.currentUser!.uid,
            createdAt: Date.now(),
            updatedAt: Date.now()
          };
          batch.set(newDoc, deviceToSave);
        });
        await batch.commit();
        localStorage.removeItem('ps_devices');
      }
    } catch (e: any) {
      console.error("Auth Error:", e);
      if (e.code === 'auth/popup-blocked' || e.code === 'auth/popup-closed-by-user') {
        alert("فشلت عملية تسجيل الدخول لأن المتصفح منع النافذة المنبثقة. يرجى فتح التطبيق في علامة تبويب جديدة (New Tab) أعلى الشاشة.");
      } else if (e.code === 'auth/unauthorized-domain') {
        alert("نطاق غير مصرح به! يرجى إضافة رابط هذا الموقع إلى قائمة النطاقات المسموح بها (Authorized Domains) في إعدادات Firebase Authentication الخاصة بك.");
      } else {
        alert("حدث خطأ أثناء تسجيل الدخول: " + e.message + "\nيرجى محاولة فتح التطبيق في نافذة جديدة (Open in New Tab).");
      }
    }
  };

  const logOut = async () => {
    await signOut(auth);
  };

  const importDevices = async (newDevices: Device[]) => {
    if (!user) return;
    try {
      const batch = writeBatch(db);
      newDevices.forEach(d => {
        const newDoc = doc(collection(db, 'devices'));
        batch.set(newDoc, { ...d, id: newDoc.id, userId: activeWorkspaceId || user.uid, createdAt: Date.now(), updatedAt: Date.now() });
      });
      await batch.commit();
    } catch(e) {
      handleFirestoreError(e, OperationType.WRITE, 'devices');
    }
  };

  const importAllData = async (data: { devices?: Device[], generalExpenses?: GeneralExpense[], generalDebts?: GeneralDebt[] }) => {
    if (!user) return;
    try {
      const batch = writeBatch(db);
      const uid = activeWorkspaceId || user.uid;
      const now = Date.now();

      if (data.devices && Array.isArray(data.devices)) {
        data.devices.forEach(d => {
          const newDoc = doc(collection(db, 'devices'));
          batch.set(newDoc, { ...d, id: newDoc.id, userId: uid, createdAt: now, updatedAt: now });
        });
      }

      if (data.generalExpenses && Array.isArray(data.generalExpenses)) {
        data.generalExpenses.forEach(e => {
          const newDoc = doc(collection(db, 'generalExpenses'));
          batch.set(newDoc, { ...e, id: newDoc.id, userId: uid, createdAt: now, updatedAt: now });
        });
      }

      if (data.generalDebts && Array.isArray(data.generalDebts)) {
        data.generalDebts.forEach(d => {
          const newDoc = doc(collection(db, 'generalDebts'));
          batch.set(newDoc, { ...d, id: newDoc.id, userId: uid, createdAt: now, updatedAt: now });
        });
      }

      await batch.commit();
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'importAllData');
    }
  };

  const addDevice = async (d: Omit<Device, 'id' | 'status'>) => {
    if (!user) return;
    try {
      const newDoc = doc(collection(db, 'devices'));
      const deviceToSave = {
        ...d,
        id: newDoc.id,
        userId: activeWorkspaceId || user.uid,
        status: 'in_stock',
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      await setDoc(newDoc, deviceToSave);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'devices');
    }
  };

  const updateDevice = async (id: string, updates: Partial<Device>) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'devices', id), { ...updates, updatedAt: Date.now() });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'devices/' + id);
    }
  };

  const sellDevice = async (id: string, sellPrice: number, sellDate: string, buyerName?: string, buyerPhone?: string, buyerArea?: string, soldExtras?: string[], sellMethod?: 'cash' | 'benefit' | 'mixed', cashAmount?: number, benefitAmount?: number) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'devices', id), {
        sellPrice,
        sellDate,
        status: 'sold',
        buyerName: buyerName || null,
        buyerPhone: buyerPhone || null,
        buyerArea: buyerArea || null,
        soldExtras: soldExtras || [],
        sellMethod: sellMethod || null,
        cashAmount: cashAmount !== undefined ? cashAmount : null,
        benefitAmount: benefitAmount !== undefined ? benefitAmount : null,
        updatedAt: Date.now()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'devices/' + id);
    }
  };

  const deleteDevice = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'devices', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'devices/' + id);
    }
  };

  const addGeneralExpense = async (expense: Omit<GeneralExpense, 'id'>) => {
    if (!user) return;
    try {
      const newDoc = doc(collection(db, 'generalExpenses'));
      await setDoc(newDoc, { ...expense, id: newDoc.id, userId: activeWorkspaceId || user.uid, createdAt: Date.now(), updatedAt: Date.now() });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'generalExpenses');
    }
  };

  const updateGeneralExpense = async (id: string, updates: Partial<GeneralExpense>) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'generalExpenses', id), { ...updates, updatedAt: Date.now() });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'generalExpenses/' + id);
    }
  };

  const deleteGeneralExpense = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'generalExpenses', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'generalExpenses/' + id);
    }
  };

  const addGeneralDebt = async (debt: Omit<GeneralDebt, 'id'>) => {
    if (!user) return;
    try {
      const newDoc = doc(collection(db, 'generalDebts'));
      await setDoc(newDoc, { ...debt, id: newDoc.id, userId: activeWorkspaceId || user.uid, createdAt: Date.now(), updatedAt: Date.now() });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'generalDebts');
    }
  };

  const updateGeneralDebt = async (id: string, updates: Partial<GeneralDebt>) => {
    if (!user) return;
    try {
      setGeneralDebts(prev => prev.map(d => d.id === id ? { ...d, ...updates } : d));
      await updateDoc(doc(db, 'generalDebts', id), { ...updates, updatedAt: Date.now() });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'generalDebts/' + id);
    }
  };

  const deleteGeneralDebt = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'generalDebts', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'generalDebts/' + id);
    }
  };


  const generateInviteCode = async () => {
    if (!user) return "";
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    try {
      const workspaceRef = doc(db, 'workspaces', user.uid);
      await setDoc(workspaceRef, {
        inviteCode: code,
        updatedAt: Date.now()
      }, { merge: true });
      return btoa(`${user.uid}:${code}`);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'workspaces');
      return "";
    }
  };

  const joinWorkspace = async (pairingCode: string) => {
    if (!user) return false;
    try {
      let workspaceId = '';
      let inviteCode = '';
      
      if (pairingCode.includes('?invite=')) {
        const url = new URL(pairingCode);
        workspaceId = url.searchParams.get('invite') || '';
        inviteCode = url.searchParams.get('code') || '';
      } else {
        const decoded = atob(pairingCode);
        [workspaceId, inviteCode] = decoded.split(':');
      }

      if (!workspaceId || !inviteCode) {
        throw new Error("Invalid format");
      }

      const memberRef = doc(db, 'workspaces', workspaceId, 'members', user.uid);
      await setDoc(memberRef, {
        inviteCode,
        joinedAt: Date.now()
      });
      setActiveWorkspaceId(workspaceId);
      return true;
    } catch (e) {
      console.error(e);
      alert(language === 'ar' ? 'فشل الانضمام، الرمز غير صحيح.' : 'Failed to join, invalid code.');
      return false;
    }
  };


  return (
    <StoreContext.Provider value={{
      devices, generalExpenses, generalDebts, language, theme, turboMode, user, authLoading,
      signIn, logOut, setLanguage, setTheme, setTurboMode, importDevices, importAllData,
      addDevice, updateDevice, sellDevice, deleteDevice,
      addGeneralExpense, updateGeneralExpense, deleteGeneralExpense,
      addGeneralDebt, updateGeneralDebt, deleteGeneralDebt,
      activeWorkspaceId, setActiveWorkspaceId, generateInviteCode, joinWorkspace, clearWorkspace, errors, logError, clearErrors, markErrorsAsSeen
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within a StoreProvider");
  return ctx;
};
