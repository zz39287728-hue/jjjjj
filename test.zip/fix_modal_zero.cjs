const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/\{isSold && device\.sellPrice && \(/g, "{isSold && device.sellPrice ? (");
c = c.replace(/                    <\/div>\n                  \)\}/g, "                    </div>\n                  ) : null}");

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
