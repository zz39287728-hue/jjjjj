import sys

files = [
    'src/views/FormsView.tsx',
    'src/views/GeneralDebtForm.tsx',
    'src/views/GeneralExpenseForm.tsx',
    'src/components/SellModal.tsx',
    'src/components/DeviceDetailsModal.tsx'
]

for file in files:
    with open(file, 'r') as f:
        content = f.read()
    
    if "import { hapticFeedback }" not in content:
        content = content.replace("import { toLatinDigits } from '../utils';", "import { toLatinDigits, hapticFeedback } from '../utils';")
        content = content.replace("import { formatBHD, formatDate } from '../utils';", "import { formatBHD, formatDate, hapticFeedback } from '../utils';")

    if 'onSuccess();' in content:
        content = content.replace('onSuccess();', 'hapticFeedback("success");\n    onSuccess();')
    
    if 'onClose();' in content:
        content = content.replace('onClick={onClose}', 'onClick={() => { hapticFeedback("light"); onClose(); }}')

    with open(file, 'w') as f:
        f.write(content)

print("Added haptics to forms and modals")
