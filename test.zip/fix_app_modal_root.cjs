const fs = require('fs');
let c = fs.readFileSync('src/App.tsx', 'utf8');

const modalRoot = `              </AnimatePresence>
              <div id="modal-root" className="absolute inset-0 pointer-events-none z-50 [&>*]:pointer-events-auto flex flex-col justify-end sm:justify-center"></div>
            </motion.div>`;

c = c.replace(/              <\/AnimatePresence>\n            <\/motion\.div>/, modalRoot);

fs.writeFileSync('src/App.tsx', c);
