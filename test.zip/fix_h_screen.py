import sys

with open('src/App.tsx', 'r') as f:
    content = f.read()

content = content.replace("h-screen", "h-[100dvh]")

with open('src/App.tsx', 'w') as f:
    f.write(content)
print("Updated h-screen to h-[100dvh]")
