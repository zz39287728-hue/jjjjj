const fs = require('fs');
let c = fs.readFileSync('src/types.ts', 'utf8');

const newTypes = `export interface Expense {
  id: string;
  type: 'petrol_dad' | 'petrol' | 'dinner_abbas' | 'maintenance' | 'delivery' | 'other';
  amount: number;
  customName?: string;
}

export interface ExtraAction {
  extraName: string;
  action: 'sold' | 'gifted' | 'kept_personal' | 'pending';
  price?: number;
  notes?: string;
}

export interface Device {`;

c = c.replace(/export interface Expense \{[\s\S]*?\}\n\nexport interface Device \{/, newTypes);
c = c.replace(/expenses\?: Expense\[\];\n\}/, "expenses?: Expense[];\n  extraActions?: ExtraAction[];\n}");

fs.writeFileSync('src/types.ts', c);
