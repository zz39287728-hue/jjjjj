const fs = require('fs');

function updateI18n() {
  let c = fs.readFileSync('src/i18n.ts', 'utf8');
  c = c.replace(/extras_sold_with: 'Extras Sold With Device:',/g, "extras_sold_with: 'Extras Sold With Device:',\n    kept_extras: 'Kept Extras (Extra Profit):',");
  c = c.replace(/extras_sold_with: 'الإضافات المباعة مع الجهاز:',/g, "extras_sold_with: 'الإضافات المباعة مع الجهاز:',\n    kept_extras: 'الإضافات المتبقية (أرباح إضافية):',");
  fs.writeFileSync('src/i18n.ts', c);
}
updateI18n();
