import sys

with open('src/components/SellModal.tsx', 'r') as f:
    content = f.read()

if "import { hapticFeedback }" not in content:
    content = content.replace("import { toLatinDigits } from '../utils';", "import { toLatinDigits, hapticFeedback } from '../utils';")

with open('src/components/SellModal.tsx', 'w') as f:
    f.write(content)

print("Fixed haptic in sell modal")
