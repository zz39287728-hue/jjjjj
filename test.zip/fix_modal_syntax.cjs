const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/                    \) : null\}\n                  \{hasOther && \(/g, "                    )}\n                  {hasOther && (");

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
