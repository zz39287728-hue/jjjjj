const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

// 1. Add to StoreContextType
if (!c.includes('activeWorkspaceId: string;')) {
  c = c.replace(/  deleteGeneralDebt: \(id: string\) => Promise<void>;/,
    "  deleteGeneralDebt: (id: string) => Promise<void>;\n  activeWorkspaceId: string;\n  setActiveWorkspaceId: (id: string) => void;\n  generateInviteCode: () => Promise<string>;\n  joinWorkspace: (workspaceId: string, inviteCode: string) => Promise<boolean>;\n  clearWorkspace: () => void;");
}

// 2. Add state to StoreProvider
if (!c.includes('const [activeWorkspaceId, setActiveWorkspaceIdState]')) {
  c = c.replace(/  const \[authLoading, setAuthLoading\] = useState\(true\);/,
    "  const [authLoading, setAuthLoading] = useState(true);\n  const [activeWorkspaceId, setActiveWorkspaceIdState] = useState<string>(() => {\n    try {\n      return localStorage.getItem('activeWorkspaceId') || '';\n    } catch {\n      return '';\n    }\n  });\n\n  const setActiveWorkspaceId = (id: string) => {\n    localStorage.setItem('activeWorkspaceId', id);\n    setActiveWorkspaceIdState(id);\n  };\n  const clearWorkspace = () => {\n    localStorage.removeItem('activeWorkspaceId');\n    setActiveWorkspaceIdState('');\n  };");
}

// 3. Add workspace functions
const workspaceFuncs = `
  const generateInviteCode = async () => {
    if (!user) return '';
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    try {
      await setDoc(doc(db, 'workspaces', user.uid), { inviteCode: code, updatedAt: Date.now() }, { merge: true });
      return code;
    } catch (error) {
      console.error(error);
      return '';
    }
  };

  const joinWorkspace = async (workspaceId: string, inviteCode: string) => {
    if (!user) return false;
    try {
      await setDoc(doc(db, 'workspaces', workspaceId, 'members', user.uid), {
        inviteCode,
        joinedAt: Date.now()
      });
      setActiveWorkspaceId(workspaceId);
      return true;
    } catch (error) {
      console.error(error);
      return false;
    }
  };
`;
if (!c.includes('const generateInviteCode')) {
  c = c.replace(/  const importDevices = \(imported: Device\[\]\) => \{/, workspaceFuncs + "\n  const importDevices = (imported: Device[]) => {");
}

// 4. Update the context value
if (!c.includes('activeWorkspaceId,')) {
  c = c.replace(/    <StoreContext.Provider value=\{\{/,
    "    <StoreContext.Provider value={{\n      activeWorkspaceId,\n      setActiveWorkspaceId,\n      generateInviteCode,\n      joinWorkspace,\n      clearWorkspace,");
}

// 5. Fix the 'get().activeWorkspaceId || user.uid' mistakes inside the methods
c = c.replace(/get\(\)\.activeWorkspaceId \|\| user\.uid/g, "activeWorkspaceId || user.uid");
c = c.replace(/get\(\)\.activeWorkspaceId \|\| get\(\)\.user\?\.uid/g, "activeWorkspaceId || user?.uid");

fs.writeFileSync('src/store.tsx', c);
