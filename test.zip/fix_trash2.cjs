const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');
c = c.replace(/import \{ X, Calendar, Phone, MapPin, Image as ImageIcon, Pencil, Check, Briefcase, Gamepad, Disc, Headphones, Wind, MonitorUp, MoreHorizontal , User \} from 'lucide-react';/, "import { X, Calendar, Phone, MapPin, Image as ImageIcon, Pencil, Check, Briefcase, Gamepad, Disc, Headphones, Wind, MonitorUp, MoreHorizontal, User, Trash2 } from 'lucide-react';");
fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);

let c2 = fs.readFileSync('src/views/FormsView.tsx', 'utf8');
c2 = c2.replace(/import \{ Device \} from '\.\.\/types';/, "import { Device, Expense } from '../types';");
fs.writeFileSync('src/views/FormsView.tsx', c2);
