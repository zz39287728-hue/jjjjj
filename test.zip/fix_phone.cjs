const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/device\.sellerPhone\?\.replace\(\/\\D\/g, ''\)/g, "String(device.sellerPhone).replace(/\\D/g, '')");
c = c.replace(/device\.buyerPhone\?\.replace\(\/\\D\/g, ''\)/g, "String(device.buyerPhone).replace(/\\D/g, '')");
c = c.replace(/device\.buyerPhone\.replace\(\/\\D\/g, ''\)/g, "String(device.buyerPhone).replace(/\\D/g, '')");

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
