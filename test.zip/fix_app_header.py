import sys

with open('src/App.tsx', 'r') as f:
    content = f.read()

target = """                <motion.button whileTap={{ scale: 0.9 }} onClick={() => setShowSettings(true)} className="p-1.5 text-gray-400 dark:text-gray-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-full transition-colors">
                  <Settings className="w-5 h-5" />
                </motion.button>
              </header>"""

replacement = """                <div className="flex items-center gap-2">
                  <PWAInstallButton />
                  <motion.button whileTap={{ scale: 0.9 }} onClick={() => setShowSettings(true)} className="p-1.5 text-gray-400 dark:text-gray-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-full transition-colors">
                    <Settings className="w-5 h-5" />
                  </motion.button>
                </div>
              </header>"""

if target in content:
    with open('src/App.tsx', 'w') as f:
        f.write(content.replace(target, replacement))
    print("Fixed App header")
else:
    print("Target not found in App header")

# Also add import for PWAInstallButton
import_target = """import { Settings, Gamepad2, PlusCircle, LayoutDashboard, Database, Receipt, CreditCard, X, ArrowLeft, ArrowRight } from 'lucide-react';"""
import_replacement = """import { Settings, Gamepad2, PlusCircle, LayoutDashboard, Database, Receipt, CreditCard, X, ArrowLeft, ArrowRight } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';"""

if import_target in content:
    with open('src/App.tsx', 'r') as f:
        c2 = f.read()
    with open('src/App.tsx', 'w') as f:
        f.write(c2.replace(import_target, import_replacement))
    print("Added PWAInstallButton import")

