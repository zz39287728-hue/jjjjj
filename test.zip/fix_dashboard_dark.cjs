const fs = require('fs');
let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

c = c.replace(/<div className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">/g, '<div className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700">');

c = c.replace(/<p className="text-sm font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500">/g, '<p className="text-sm font-medium text-gray-500 dark:text-gray-400">');
c = c.replace(/<p className="text-lg font-bold text-gray-900 dark:text-gray-100 dark:text-gray-900">/g, '<p className="text-lg font-bold text-gray-900 dark:text-gray-100">');

c = c.replace(/<div className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 col-span-2 flex items-center justify-between">/g, '<div className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 col-span-2 flex items-center justify-between">');

c = c.replace(/<div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden">/g, '<div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">');
c = c.replace(/<div className="p-4 border-b border-gray-50 dark:border-gray-800">/g, '<div className="p-4 border-b border-gray-100 dark:border-gray-700">');

c = c.replace(/<div key=\{extra.name\} className="flex items-center bg-indigo-50 border border-indigo-100 rounded-lg px-3 py-2 text-sm text-indigo-800">/g, '<div key={extra.name} className="flex items-center bg-indigo-50 dark:bg-indigo-900/30 border border-indigo-100 dark:border-indigo-800/50 rounded-lg px-3 py-2 text-sm text-indigo-800 dark:text-indigo-300">');
c = c.replace(/<span className="bg-indigo-200 text-indigo-900 text-xs px-1.5 py-0.5 rounded-full font-bold">/g, '<span className="bg-indigo-200 dark:bg-indigo-800 text-indigo-900 dark:text-indigo-200 text-xs px-1.5 py-0.5 rounded-full font-bold">');

c = c.replace(/<div className="p-2 bg-blue-50 text-blue-600 rounded-lg">/g, '<div className="p-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg">');
c = c.replace(/<div className="p-2 bg-purple-50 text-purple-600 rounded-lg">/g, '<div className="p-2 bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-lg">');

fs.writeFileSync('src/views/Dashboard.tsx', c);
