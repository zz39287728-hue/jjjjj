import sys

with open('src/views/GeneralExpenseForm.tsx', 'r') as f:
    content = f.read()

def r(target, rep):
    global content
    content = content.replace(target, rep)

r(">إضافة مصروف جديد<", ">{language === 'ar' ? 'إضافة مصروف جديد' : 'Add New Expense'}<")
r(">نوع المصروف<", ">{language === 'ar' ? 'نوع المصروف' : 'Expense Type'}<")
r('placeholder="مثال: فاتورة إنترنت"', 'placeholder={language === "ar" ? "مثال: فاتورة إنترنت" : "e.g. Internet Bill"}')
r(">المبلغ (د.ب)<", ">{language === 'ar' ? 'المبلغ (د.ب)' : 'Amount (BHD)'}<")
r(">التاريخ<", ">{language === 'ar' ? 'التاريخ' : 'Date'}<")
r(">ملاحظات (اختياري)<", ">{language === 'ar' ? 'ملاحظات (اختياري)' : 'Notes (Optional)'}<")
r(">حفظ المصروف<", ">{language === 'ar' ? 'حفظ المصروف' : 'Save Expense'}<")

old_predef = """            {predefinedExpenses.map(p => (
              <button
                key={p}
                type="button"
                onClick={() => setTitle(p)}
                className={`px-3 py-1.5 text-xs font-medium rounded-xl border transition-all ${title === p ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300'}`}
              >
                {p}
              </button>
            ))}"""

new_predef = """            {predefinedExpenses.map(p => {
              const display = language === 'en' ? (
                p === 'بترول' ? 'Petrol' :
                p === 'عشاء' ? 'Dinner' :
                p === 'صيانة' ? 'Maintenance' :
                p === 'توصيل' ? 'Delivery' :
                p === 'أخرى' ? 'Other' : p
              ) : p;
              return (
              <button
                key={p}
                type="button"
                onClick={() => setTitle(p)}
                className={`px-3 py-1.5 text-xs font-medium rounded-xl border transition-all ${title === p ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300'}`}
              >
                {display}
              </button>
            )})}"""

r(old_predef, new_predef)

with open('src/views/GeneralExpenseForm.tsx', 'w') as f:
    f.write(content)

print("GeneralExpenseForm language updated.")
