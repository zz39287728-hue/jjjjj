const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

c = c.replace(/  const \{ user, setAuthLoading, setUser, setDevices, setGeneralExpenses, setGeneralDebts \} = useStore\(\);/, 
  "  const { user, setAuthLoading, setUser, setDevices, setGeneralExpenses, setGeneralDebts, activeWorkspaceId } = useStore();");

c = c.replace(/  \}, \[user\]\);/g, "  }, [user, activeWorkspaceId]);");

fs.writeFileSync('src/store.tsx', c);
