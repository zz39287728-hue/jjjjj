const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

c = c.replace(/animate=\{\{ \[language === 'ar' \? 'right' : 'left'\]: tab === 'in_stock' \? '4px' : 'calc\(50% \+ 0px\)' \}\}/, "animate={{ x: language === 'ar' ? (tab === 'in_stock' ? 0 : '-100%') : (tab === 'in_stock' ? 0 : '100%') }}");
c = c.replace(/className="absolute top-1 bottom-1 w-\[calc\(50%-4px\)\] bg-white dark:bg-gray-800 rounded-lg shadow-sm"/, 'className="absolute top-1 bottom-1 left-1 right-[50%] w-[calc(50%-4px)] bg-white dark:bg-gray-800 rounded-lg shadow-sm"');

fs.writeFileSync('src/views/Inventory.tsx', c);
