const fs = require('fs');

let c = fs.readFileSync('src/App.tsx', 'utf8');

if (!c.includes('OfflineIndicator')) {
  c = c.replace(/import \{ StoreProvider, useStore \} from '\.\/store';/, "import { StoreProvider, useStore } from './store';\nimport { OfflineIndicator } from './components/OfflineIndicator';");
  
  c = c.replace(/<AnimatePresence>\n                \{sellingDevice && \(/, "<OfflineIndicator />\n              <AnimatePresence>\n                {sellingDevice && (");

  fs.writeFileSync('src/App.tsx', c);
  console.log("Updated App.tsx");
}
