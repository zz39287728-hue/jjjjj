const fs = require('fs');

function fixFile(file) {
  let c = fs.readFileSync(file, 'utf8');
  // First fix any broken regexes from my previous attempts
  c = c.replace(/\.replace\(\/\\\\D\/g, ''\)/g, ".replace(/\\D/g, '')");
  
  // Now replace the tel links
  c = c.replace(/href={`tel:\$\{dev\.sellerPhone\}`}/g, "href={`https://wa.me/${dev.sellerPhone?.replace(/\\D/g, '')}`} target=\"_blank\" rel=\"noopener noreferrer\"");
  c = c.replace(/href={`tel:\$\{dev\.buyerPhone\}`}/g, "href={`https://wa.me/${dev.buyerPhone?.replace(/\\D/g, '')}`} target=\"_blank\" rel=\"noopener noreferrer\"");
  
  c = c.replace(/href={`tel:\$\{device\.sellerPhone\}`}/g, "href={`https://wa.me/${device.sellerPhone?.replace(/\\D/g, '')}`} target=\"_blank\" rel=\"noopener noreferrer\"");
  c = c.replace(/href={`tel:\$\{device\.buyerPhone\}`}/g, "href={`https://wa.me/${device.buyerPhone?.replace(/\\D/g, '')}`} target=\"_blank\" rel=\"noopener noreferrer\"");
  
  fs.writeFileSync(file, c);
}

fixFile('src/views/Inventory.tsx');
fixFile('src/components/DeviceDetailsModal.tsx');
