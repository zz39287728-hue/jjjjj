const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

const loanBlock = `              {(device.sellerName || device.sellerPhone || device.area || device.chatImage) && (
                <div className="mt-3"></div>
              )}
              {device.loanAmount ? (
                <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border border-indigo-100 dark:border-indigo-900/30 shadow-sm mt-4">
                  <h4 className="text-sm font-bold text-gray-900 dark:text-gray-100 mb-3">{t('loan_money', language)}</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('loan_amount', language)}</p>
                      <p className="font-bold text-gray-900 dark:text-gray-100 text-lg">{formatBHD(device.loanAmount)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('lender', language)}</p>
                      <p className="font-bold text-gray-900 dark:text-gray-100 text-lg">{t(device.loanLender || 'other', language)}</p>
                    </div>
                    {isEditing ? (
                      <div className="col-span-2 mt-2">
                        <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('loan_status', language)}</label>
                        <select 
                          value={loanStatus} 
                          onChange={e => setLoanStatus(e.target.value)} 
                          className="w-full p-2 text-sm bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                        >
                          <option value="unpaid">{t('unpaid', language)}</option>
                          <option value="paid">{t('paid', language)}</option>
                        </select>
                      </div>
                    ) : (
                      <div className="col-span-2 mt-2">
                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('loan_status', language)}</p>
                        <span className={\`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium \${device.loanStatus === 'paid' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400'}\`}>
                          {t(device.loanStatus || 'unpaid', language)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              ) : null}`;

// We just append it after the seller info in non-edit mode
c = c.replace(/                    <\/div>\n                  \)\}\n                <\/div>\n              \) : \(\n                  <p className="text-sm text-gray-400 dark:text-gray-500 italic">لا توجد تفاصيل شراء\.<\/p>\n                \)\}/, "                    </div>\n                  )}\n                </div>\n              ) : (\n                  <p className=\"text-sm text-gray-400 dark:text-gray-500 italic\">لا توجد تفاصيل شراء.</p>\n                )}\n" + loanBlock);

const handleSaveReplace = `      extras: currentExtrasList,\n      loanStatus,\n    };`;
c = c.replace(/      extras: currentExtrasList,\n    \};/, handleSaveReplace);

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
