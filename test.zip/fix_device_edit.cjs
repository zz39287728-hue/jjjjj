const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

const regexVars = /const \[soldExtras, setSoldExtras\] = useState<string\[\]>\(device\.soldExtras \|\| \[\]\);/;
const replaceVars = `const [soldExtras, setSoldExtras] = useState<string[]>(device.soldExtras || []);
  const [sellMethod, setSellMethod] = useState<'cash' | 'benefit' | 'mixed' | undefined>(device.sellMethod);
  const [cashAmount, setCashAmount] = useState(device.cashAmount?.toString() || '');
  const [benefitAmount, setBenefitAmount] = useState(device.benefitAmount?.toString() || '');`;

c = c.replace(regexVars, replaceVars);

const regexSave = /      const updates: Partial<Device> = \{\n        title,\n        model,\n        buyPrice: parseFloat\(buyPrice\),\n        buyDate,\n        area,\n        sellerName,\n        sellerPhone,\n        extras: currentExtrasList,\n        expenses,\n        loanStatus,\n        extraActions\n      \};/;
const replaceSave = `      const updates: Partial<Device> = {
        title,
        model,
        buyPrice: parseFloat(buyPrice),
        buyDate,
        area,
        sellerName,
        sellerPhone,
        extras: currentExtrasList,
        expenses,
        loanStatus,
        extraActions
      };`;

c = c.replace(regexSave, replaceSave);

const regexSaveSold = /        if \(sellPrice\) updates\.sellPrice = parseFloat\(sellPrice\);\n        if \(sellDate\) updates\.sellDate = sellDate;\n        updates\.buyerName = buyerName;\n        updates\.buyerPhone = buyerPhone;\n        updates\.buyerArea = buyerArea;\n        updates\.soldExtras = soldExtras;/;
const replaceSaveSold = `        if (sellPrice) updates.sellPrice = parseFloat(sellPrice);
        if (sellDate) updates.sellDate = sellDate;
        updates.buyerName = buyerName;
        updates.buyerPhone = buyerPhone;
        updates.buyerArea = buyerArea;
        updates.soldExtras = soldExtras;
        
        let finalCash = sellMethod === 'cash' ? updates.sellPrice : sellMethod === 'mixed' ? parseFloat(cashAmount || '0') : 0;
        let finalBenefit = sellMethod === 'benefit' ? updates.sellPrice : sellMethod === 'mixed' ? parseFloat(benefitAmount || '0') : 0;
        
        if (sellMethod === 'mixed' && updates.sellPrice && (finalCash! + finalBenefit! !== updates.sellPrice)) {
          return alert('يجب أن يكون مجموع مبلغ الكاش وبنفت مساوياً لسعر البيع');
        }
        
        if (sellMethod) updates.sellMethod = sellMethod;
        updates.cashAmount = finalCash;
        updates.benefitAmount = finalBenefit;`;

c = c.replace(regexSaveSold, replaceSaveSold);

const regexUiEdit = /                        <input type="text" value=\{buyerName\} onChange=\{e => setBuyerName\(e\.target\.value\)\} className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-sm dark:text-white" placeholder="اسم المشتري" \/>\n                      <\/div>/;
const replaceUiEdit = `                        <input type="text" value={buyerName} onChange={e => setBuyerName(e.target.value)} className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-sm dark:text-white" placeholder="اسم المشتري" />
                      </div>
                      
                      <div className="col-span-2">
                        <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">طريقة الدفع</label>
                        <div className="flex bg-gray-100 dark:bg-gray-800 p-1 rounded-xl">
                          <button
                            type="button"
                            onClick={() => setSellMethod('benefit')}
                            className={\`flex-1 py-1.5 text-sm font-medium rounded-lg transition-colors \${sellMethod === 'benefit' ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}\`}
                          >
                            بنفت
                          </button>
                          <button
                            type="button"
                            onClick={() => setSellMethod('cash')}
                            className={\`flex-1 py-1.5 text-sm font-medium rounded-lg transition-colors \${sellMethod === 'cash' ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}\`}
                          >
                            كاش
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setSellMethod('mixed');
                              if (sellPrice) {
                                setCashAmount((parseFloat(sellPrice) / 2).toString());
                                setBenefitAmount((parseFloat(sellPrice) / 2).toString());
                              }
                            }}
                            className={\`flex-1 py-1.5 text-sm font-medium rounded-lg transition-colors \${sellMethod === 'mixed' ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}\`}
                          >
                            مشترك
                          </button>
                        </div>
                      </div>
                      
                      {sellMethod === 'mixed' && (
                        <>
                          <div>
                            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">مبلغ بنفت</label>
                            <input
                              type="number" step="0.1"
                              value={benefitAmount}
                              onChange={e => {
                                setBenefitAmount(e.target.value);
                                if (sellPrice && e.target.value) {
                                  setCashAmount(Math.max(0, parseFloat(sellPrice) - parseFloat(e.target.value)).toString());
                                }
                              }}
                              className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-sm dark:text-white" 
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">مبلغ الكاش</label>
                            <input
                              type="number" step="0.1"
                              value={cashAmount}
                              onChange={e => {
                                setCashAmount(e.target.value);
                                if (sellPrice && e.target.value) {
                                  setBenefitAmount(Math.max(0, parseFloat(sellPrice) - parseFloat(e.target.value)).toString());
                                }
                              }}
                              className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-sm dark:text-white" 
                            />
                          </div>
                        </>
                      )}`;

c = c.replace(regexUiEdit, replaceUiEdit);

const regexUiView = /                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">معلومات البيع<\/h4>/;
const replaceUiView = `                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">معلومات البيع</h4>
                  
                  {device.sellMethod && (
                    <div className="flex flex-wrap gap-2 mb-3">
                      {device.sellMethod === 'benefit' && (
                        <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-purple-50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400">
                          الدفع عبر بنفت ({formatBHD(device.sellPrice || 0)})
                        </span>
                      )}
                      {device.sellMethod === 'cash' && (
                        <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                          دفع كاش ({formatBHD(device.sellPrice || 0)})
                        </span>
                      )}
                      {device.sellMethod === 'mixed' && (
                        <>
                          <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-purple-50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400">
                            بنفت: {formatBHD(device.benefitAmount || 0)}
                          </span>
                          <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                            كاش: {formatBHD(device.cashAmount || 0)}
                          </span>
                        </>
                      )}
                    </div>
                  )}`;

c = c.replace(regexUiView, replaceUiView);

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
