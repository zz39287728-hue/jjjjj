import sys

with open('src/views/Dashboard.tsx', 'r') as f:
    content = f.read()

target = "(يتضمن مبلغ {formatBHD(totalLoans)} تم إقراضه)"
replacement = "{language === 'ar' ? `(يتضمن مبلغ ${formatBHD(totalLoans)} تم إقراضه)` : `(Includes ${formatBHD(totalLoans)} lent out)`}"

if target in content:
    with open('src/views/Dashboard.tsx', 'w') as f:
        f.write(content.replace(target, replacement))
    print("Fixed Dashboard language string.")
else:
    print("Target not found.")
