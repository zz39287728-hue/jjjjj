const fs = require('fs');
let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

// Add imports
if (!c.includes('recharts')) {
  c = c.replace(/import \{ TrendingUp, Package, ShoppingCart, Headset, HardDrive, Gamepad2, Blocks \} from 'lucide-react';/,
    `import { TrendingUp, Package, ShoppingCart, Headset, HardDrive, Gamepad2, Blocks } from 'lucide-react';\nimport { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer } from 'recharts';`);
}

// Add chart data memo
const chartDataMemo = `  const chartData = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const dataMap = new Map();
    
    for (let i = 1; i <= daysInMonth; i++) {
      dataMap.set(i, { name: \`\${i}\`, buy: 0, sell: 0 });
    }
    
    transactions.forEach(tx => {
      const txDate = new Date(tx.date);
      if (txDate.getMonth() === currentMonth && txDate.getFullYear() === currentYear) {
        const day = txDate.getDate();
        const dayData = dataMap.get(day);
        if (dayData) {
          if (tx.type === 'buy') dayData.buy += tx.amount;
          if (tx.type === 'sell') dayData.sell += tx.amount;
        }
      }
    });
    
    return Array.from(dataMap.values());
  }, [transactions]);

  const formatDateLabel = (dateStr: string) => {`;

c = c.replace(/  const formatDateLabel = \(dateStr: string\) => \{/, chartDataMemo);

// Add the chart UI before inStockExtras
const chartUI = `      <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-gray-100 dark:border-gray-700">
          <h3 className="font-bold text-gray-800 dark:text-gray-200">{language === 'ar' ? 'نظرة عامة على الشهر الحالي' : 'Current Month Overview'}</h3>
        </div>
        <div className="p-5 sm:p-6 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#374151" opacity={0.2} />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} dy={10} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} tickFormatter={(value) => \`\${value >= 1000 ? (value / 1000) + 'k' : value}\`} />
              <RechartsTooltip 
                cursor={{ fill: 'rgba(107, 114, 128, 0.1)' }}
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)', backgroundColor: 'rgba(31, 41, 55, 0.9)', color: '#fff' }}
                itemStyle={{ fontSize: '14px', fontWeight: 'bold' }}
                formatter={(value: number, name: string) => [formatBHD(value), name === 'buy' ? (language === 'ar' ? 'المشتريات' : 'Purchases') : (language === 'ar' ? 'المبيعات' : 'Sales')]}
                labelFormatter={(label) => \`\${language === 'ar' ? 'يوم' : 'Day'} \${label}\`}
              />
              <Legend 
                iconType="circle" 
                formatter={(value) => <span style={{ color: '#9CA3AF', fontSize: '14px', marginLeft: '8px' }}>{value === 'buy' ? (language === 'ar' ? 'المشتريات' : 'Purchases') : (language === 'ar' ? 'المبيعات' : 'Sales')}</span>} 
              />
              <Bar dataKey="buy" fill="#3B82F6" radius={[4, 4, 0, 0]} maxBarSize={40} />
              <Bar dataKey="sell" fill="#8B5CF6" radius={[4, 4, 0, 0]} maxBarSize={40} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {inStockExtras.length > 0 && (`;

c = c.replace(/      \{inStockExtras.length > 0 && \(/, chartUI);

fs.writeFileSync('src/views/Dashboard.tsx', c);
