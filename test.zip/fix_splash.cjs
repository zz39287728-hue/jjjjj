const fs = require('fs');
let c = fs.readFileSync('src/components/SplashScreen.tsx', 'utf8');
c = c.replace(/export default function SplashScreen\(\{ onComplete \}: \{ onComplete: \(\) => void \}\)/, 'export default function SplashScreen({ onComplete }: { onComplete: () => void, key?: string })');
fs.writeFileSync('src/components/SplashScreen.tsx', c);
