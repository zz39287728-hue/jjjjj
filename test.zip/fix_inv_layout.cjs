const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

c = c.replace(/<div className="flex flex-col h-full">/, '<div className="flex flex-col">');
c = c.replace(/<div className="p-4 bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-800 shrink-0">/, '<div className="p-4 bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-800 shrink-0 sticky top-0 z-20 shadow-sm">');
c = c.replace(/<div className="flex-1 overflow-y-auto p-4">/, '<div className="p-4">');

fs.writeFileSync('src/views/Inventory.tsx', c);
