const fs = require('fs');

function addMotionToFormsView() {
  let c = fs.readFileSync('src/views/FormsView.tsx', 'utf8');
  if (!c.includes('motion/react')) {
    c = c.replace(/import \{ Device \} from '\.\.\/types';/, "import { Device } from '../types';\nimport { motion } from 'motion/react';");
    
    // Add staggered animations for form fields
    // Find all `<div className="space-y-1">` and replace with `<motion.div variants={{hidden: {opacity:0, y:20}, show: {opacity:1, y:0}}} className="space-y-1">`
    c = c.replace(/<div className="space-y-1">/g, '<motion.div variants={{hidden: {opacity:0, y:20}, show: {opacity:1, y:0}}} className="space-y-1">');
    
    // Add initial="hidden" animate="show" variants={{show: {transition: {staggerChildren: 0.1}}}} to the form wrapping div
    c = c.replace(/<div className="flex flex-col gap-4">/, '<motion.div initial="hidden" animate="show" variants={{show: {transition: {staggerChildren: 0.1}}}} className="flex flex-col gap-4">');
    
    // Close motion.div instead of div for that parent
    // The `<div className="flex flex-col gap-4">` ends just before `</div>\n      <div className="h-20" />`
    c = c.replace(/<\/div>\n      <div className="h-20" \/>/g, '</motion.div>\n      <div className="h-20" />');

    // Add motion to save button
    c = c.replace(/<button\n          onClick=\{handleSave\}/g, '<motion.button\n          whileTap={{ scale: 0.95 }}\n          onClick={handleSave}');
    c = c.replace(/\{t\('save', language\)\}\n        <\/button>/g, "{t('save', language)}\n        </motion.button>");

    fs.writeFileSync('src/views/FormsView.tsx', c);
    console.log("Updated FormsView");
  }
}

addMotionToFormsView();
