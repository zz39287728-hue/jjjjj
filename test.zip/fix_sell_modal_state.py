import sys

with open('src/components/SellModal.tsx', 'r') as f:
    content = f.read()

# Add isSold state
if "const [isSold, setIsSold] = useState(false);" not in content:
    content = content.replace("const [benefitAmount, setBenefitAmount] = useState('');", "const [benefitAmount, setBenefitAmount] = useState('');\n  const [isSold, setIsSold] = useState(false);")

# Update handleSubmit to delay close
target = """    sellDevice(
      device.id, 
      parsedSellPrice, 
      sellDate, 
      toLatinDigits(buyerName).trim(), 
      toLatinDigits(buyerPhone).trim(), 
      toLatinDigits(buyerArea).trim(), 
      soldExtras, 
      sellMethod, 
      finalCash, 
      finalBenefit
    );

    hapticFeedback('celebration');
    
    // Celebrate!
    const duration = 2000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#4f46e5', '#a855f7', '#fbbf24']
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#4f46e5', '#a855f7', '#fbbf24']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    onClose();"""

replacement = """    sellDevice(
      device.id, 
      parsedSellPrice, 
      sellDate, 
      toLatinDigits(buyerName).trim(), 
      toLatinDigits(buyerPhone).trim(), 
      toLatinDigits(buyerArea).trim(), 
      soldExtras, 
      sellMethod, 
      finalCash, 
      finalBenefit
    );

    hapticFeedback('celebration');
    setIsSold(true);
    
    // Celebrate!
    const duration = 2500;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 8,
        angle: 60,
        spread: 60,
        origin: { x: 0 },
        colors: ['#4f46e5', '#a855f7', '#fbbf24', '#10b981', '#ef4444']
      });
      confetti({
        particleCount: 8,
        angle: 120,
        spread: 60,
        origin: { x: 1 },
        colors: ['#4f46e5', '#a855f7', '#fbbf24', '#10b981', '#ef4444']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    setTimeout(() => {
      onClose();
    }, 2500);"""

content = content.replace(target, replacement)

# Add the interactive success UI to the modal
ui_target = "return ("
ui_replacement = """  if (isSold) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          className="absolute inset-0 bg-black/60 backdrop-blur-md"
        />
        <motion.div 
          initial={{ scale: 0.5, opacity: 0, y: 50 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
          className="relative bg-white dark:bg-gray-800 rounded-3xl p-8 max-w-sm w-full shadow-2xl flex flex-col items-center text-center overflow-hidden"
        >
          {/* Animated Background Rays */}
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="absolute -inset-[100%] bg-[conic-gradient(from_0deg,transparent_0_340deg,rgba(79,70,229,0.1)_360deg)]"
          />
          
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1, rotate: [0, 10, -10, 0] }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 200, damping: 10 }}
            className="w-24 h-24 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center mb-6 shadow-lg shadow-emerald-500/30 relative z-10"
          >
            <svg className="w-12 h-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-3xl font-black bg-gradient-to-r from-emerald-600 to-indigo-600 bg-clip-text text-transparent mb-2 relative z-10"
          >
            {language === 'ar' ? 'تم البيع بنجاح!' : 'Successfully Sold!'}
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-gray-500 dark:text-gray-400 font-medium relative z-10"
          >
            {language === 'ar' ? 'مبروك، تمت إضافة الأرباح إلى السجل.' : 'Congratulations, profits added to the record.'}
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.7, type: 'spring' }}
            className="mt-6 px-6 py-3 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 rounded-2xl font-bold relative z-10 text-xl flex items-center gap-2"
          >
            <span>+</span>
            <span>{formatBHD(currentProfit)}</span>
          </motion.div>
        </motion.div>
      </div>
    );
  }

  return ("""

if ui_target in content:
    content = content.replace(ui_target, ui_replacement)
    with open('src/components/SellModal.tsx', 'w') as f:
        f.write(content)
    print("Added celebration UI to SellModal")
else:
    print("return not found")
