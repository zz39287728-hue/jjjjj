import sys

with open('src/store.tsx', 'r') as f:
    content = f.read()

target = """    } catch (e: any) {
      console.error("Auth Error:", e);
      if (e.code === 'auth/popup-blocked' || e.code === 'auth/popup-closed-by-user') {
        alert("فشلت عملية تسجيل الدخول لأن المتصفح منع النافذة المنبثقة. يرجى فتح التطبيق في علامة تبويب جديدة (New Tab) أو السماح بالنوافذ المنبثقة.");
      } else {
        alert("حدث خطأ أثناء تسجيل الدخول: " + e.message + "\\nيرجى محاولة فتح التطبيق في نافذة جديدة (Open in New Tab).");
      }
    }"""

replacement = """    } catch (e: any) {
      console.error("Auth Error:", e);
      if (e.code === 'auth/popup-blocked' || e.code === 'auth/popup-closed-by-user') {
        alert("فشلت عملية تسجيل الدخول لأن المتصفح منع النافذة المنبثقة. يرجى فتح التطبيق في علامة تبويب جديدة (New Tab) أعلى الشاشة.");
      } else if (e.code === 'auth/unauthorized-domain') {
        alert("نطاق غير مصرح به! يرجى إضافة رابط هذا الموقع إلى قائمة النطاقات المسموح بها (Authorized Domains) في إعدادات Firebase Authentication الخاصة بك.");
      } else {
        alert("حدث خطأ أثناء تسجيل الدخول: " + e.message + "\\nيرجى محاولة فتح التطبيق في نافذة جديدة (Open in New Tab).");
      }
    }"""

if target in content:
    with open('src/store.tsx', 'w') as f:
        f.write(content.replace(target, replacement))
    print("Fixed signIn errors in store.tsx")
else:
    print("Target not found in store")

