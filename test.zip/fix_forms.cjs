const fs = require('fs');
let c = fs.readFileSync('src/views/FormsView.tsx', 'utf8');

const newFields = `  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [financing, setFinancing] = useState<'personal' | 'loan'>('personal');
  const [loanAmount, setLoanAmount] = useState('');
  const [loanLender, setLoanLender] = useState('lender_abbas');`;

c = c.replace(/  const \[expenses, setExpenses\] = useState<Expense\[\]>\(\[\]\);/, newFields);

const newAdd = `    const deviceToAdd: Omit<Device, 'id' | 'status'> = {
      model,
      buyPrice: parseFloat(buyPrice),
      buyDate,
      extras,
      sellerName: sellerName || undefined,
      sellerPhone: sellerPhone || undefined,
      title: title || undefined,
      area: area || undefined,
      expenses: expenses.length > 0 ? expenses : undefined,
    };

    if (financing === 'loan') {
      deviceToAdd.loanAmount = parseFloat(loanAmount) || 0;
      deviceToAdd.loanLender = loanLender;
      deviceToAdd.loanStatus = 'unpaid';
    }

    addDevice(deviceToAdd);`;

c = c.replace(/    addDevice\(\{\n      model,\n      buyPrice: parseFloat\(buyPrice\),\n      buyDate,\n      extras,\n      sellerName: sellerName \|\| undefined,\n      sellerPhone: sellerPhone \|\| undefined,\n      title: title \|\| undefined,\n      area: area \|\| undefined,\n      expenses: expenses\.length > 0 \? expenses : undefined,\n    \}\);/, newAdd);

const uiFields = `            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 shadow-sm border border-gray-100 dark:border-gray-800 space-y-4">
            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider">{t('loan_financing', language)}</h3>
            <div className="flex bg-gray-100 dark:bg-gray-700 rounded-xl p-1 mb-4">
              <button
                type="button"
                onClick={() => setFinancing('personal')}
                className={\`flex-1 py-2 text-sm font-medium rounded-lg transition-colors \${financing === 'personal' ? 'bg-white dark:bg-gray-800 shadow-sm text-indigo-600 dark:text-indigo-400' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}\`}
              >
                {t('personal_money', language)}
              </button>
              <button
                type="button"
                onClick={() => setFinancing('loan')}
                className={\`flex-1 py-2 text-sm font-medium rounded-lg transition-colors \${financing === 'loan' ? 'bg-white dark:bg-gray-800 shadow-sm text-indigo-600 dark:text-indigo-400' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}\`}
              >
                {t('loan_money', language)}
              </button>
            </div>
            
            {financing === 'loan' && (
              <div className="space-y-4 pt-2">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('loan_amount', language)}</label>
                  <input
                    type="number"
                    value={loanAmount}
                    onChange={e => setLoanAmount(e.target.value)}
                    className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-3 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-left"
                    dir="ltr"
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('lender', language)}</label>
                  <select
                    value={loanLender}
                    onChange={e => setLoanLender(e.target.value)}
                    className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-3 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                  >
                    <option value="lender_abbas">{t('lender_abbas', language)}</option>
                    <option value="lender_ali">{t('lender_ali', language)}</option>
                    <option value="lender_mother">{t('lender_mother', language)}</option>
                    <option value="lender_father">{t('lender_father', language)}</option>
                    <option value="lender_hussain">{t('lender_hussain', language)}</option>
                    <option value="lender_om_hamood">{t('lender_om_hamood', language)}</option>
                    <option value="lender_om_hussain">{t('lender_om_hussain', language)}</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 shadow-sm border border-gray-100 dark:border-gray-800 space-y-4">`;

c = c.replace(/            <\/div>\n          <\/div>\n\n          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 shadow-sm border border-gray-100 dark:border-gray-800 space-y-4">/, uiFields);

fs.writeFileSync('src/views/FormsView.tsx', c);
