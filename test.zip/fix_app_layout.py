import sys

with open('src/App.tsx', 'r') as f:
    content = f.read()

target = """  return (
    <div className="flex justify-center bg-gray-200 dark:bg-gray-950 sm:p-4 min-h-screen font-sans text-gray-900 dark:text-gray-100 selection:bg-indigo-200">
      <div className="w-full sm:w-[400px] bg-gray-50 dark:bg-gray-900 sm:h-[800px] h-screen flex flex-col relative sm:rounded-[40px] sm:shadow-2xl sm:border-[8px] border-gray-800 dark:border-gray-800 overflow-hidden transition-colors">"""

replacement = """  return (
    <div className="flex justify-center bg-gray-200 dark:bg-gray-950 min-h-screen font-sans text-gray-900 dark:text-gray-100 selection:bg-indigo-200">
      <div className="w-full max-w-3xl bg-gray-50 dark:bg-gray-900 min-h-screen h-[100dvh] flex flex-col relative overflow-hidden transition-colors shadow-2xl">"""

if target in content:
    with open('src/App.tsx', 'w') as f:
        f.write(content.replace(target, replacement))
    print("Fixed App layout")
else:
    print("Target not found")
