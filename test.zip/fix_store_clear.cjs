const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

const regex = /  const clearWorkspace = \(\) => \{\n    setActiveWorkspaceId\(''\);\n  \};\n/;

// Make sure we only remove the last one or exactly one of them.
c = c.replace(regex, "");

fs.writeFileSync('src/store.tsx', c);
