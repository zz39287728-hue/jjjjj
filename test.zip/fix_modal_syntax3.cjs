const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/\) : null\}/g, ")}");
c = c.replace(/\{isSold && device\.sellPrice \? \(/, "{isSold && device.sellPrice ? (");
c = c.replace(/                      <\/p>\n                    <\/div>\n                  \)\}/, "                      </p>\n                    </div>\n                  ) : null}");

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
