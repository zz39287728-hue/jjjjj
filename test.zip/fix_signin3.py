import sys

with open('src/store.tsx', 'r') as f:
    content = f.read()

target = """  const signIn = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);"""

replacement = """  const signIn = async () => {
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      await signInWithPopup(auth, provider);"""

if target in content:
    with open('src/store.tsx', 'w') as f:
        f.write(content.replace(target, replacement))
    print("Fixed signIn params in store.tsx")
else:
    print("Target not found in store")

