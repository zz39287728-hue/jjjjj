import sys, json

with open('tsconfig.json', 'r') as f:
    config = json.load(f)

config['compilerOptions']['types'] = ["vite/client", "vite-plugin-pwa/client"]

with open('tsconfig.json', 'w') as f:
    json.dump(config, f, indent=2)

print("Updated tsconfig.json")
