const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');
c = c.replace(/\} , User \} from 'lucide-react';/, ', User } from \'lucide-react\';');
fs.writeFileSync('src/views/Inventory.tsx', c);
