import sys

with open('vite.config.ts', 'r') as f:
    content = f.read()

content = content.replace("display: 'standalone'", "display: 'fullscreen'")

with open('vite.config.ts', 'w') as f:
    f.write(content)
print("Updated PWA manifest display to fullscreen")
