import sys

with open('src/components/SellModal.tsx', 'r') as f:
    content = f.read()

if "import confetti" not in content:
    content = content.replace("import { Device } from '../types';", "import { Device } from '../types';\nimport confetti from 'canvas-confetti';")

if "hapticFeedback(\"success\");" in content:
    content = content.replace('hapticFeedback("success");', """hapticFeedback("celebration");
    
    // Celebrate!
    const duration = 2000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#4f46e5', '#a855f7', '#fbbf24']
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#4f46e5', '#a855f7', '#fbbf24']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();""")

with open('src/components/SellModal.tsx', 'w') as f:
    f.write(content)
print("Updated SellModal.tsx to include confetti and celebration sound")
