const fs = require('fs');
let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

// 1. Add icons
c = c.replace(/import \{ TrendingUp, Package, ShoppingCart, Headset, HardDrive, Gamepad2, Blocks \} from 'lucide-react';/,
  "import { TrendingUp, Package, ShoppingCart, Headset, HardDrive, Gamepad2, Blocks, ArrowUpRight, ArrowDownRight, ReceiptText } from 'lucide-react';");

// 2. Add generalExpenses to destructuring
c = c.replace(/const \{ devices, language \} = useStore\(\);/,
  "const { devices, generalExpenses, language } = useStore();");

// 3. Update transactions useMemo
const newTxMemo = `const transactions = useMemo(() => {
    const txs: { id: string; deviceId?: string; type: 'buy' | 'sell' | 'expense'; title: string; amount: number; date: string; profit?: number }[] = [];
    
    devices.forEach(d => {
      // Purchase transaction
      txs.push({
        id: d.id + '_buy',
        deviceId: d.id,
        type: 'buy',
        title: d.title || d.model,
        amount: d.buyPrice,
        date: d.buyDate
      });
      
      // Sale transaction
      if (d.status === 'sold' && d.sellDate && d.sellPrice) {
        const extraProfit = d.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
        const baseProfit = d.sellPrice - d.buyPrice - (d.expenses?.reduce((eSum, e) => eSum + e.amount, 0) || 0);
        
        txs.push({
          id: d.id + '_sell',
          deviceId: d.id,
          type: 'sell',
          title: d.title || d.model,
          amount: d.sellPrice,
          date: d.sellDate,
          profit: baseProfit + extraProfit
        });
      }
    });

    if (generalExpenses) {
      generalExpenses.forEach(exp => {
        txs.push({
          id: exp.id + '_exp',
          type: 'expense',
          title: exp.title,
          amount: exp.amount,
          date: exp.date
        });
      });
    }
    
    // Sort by date descending
    return txs.sort((a, b) => (b.date > a.date ? 1 : -1));
  }, [devices, generalExpenses]);`;

c = c.replace(/const transactions = useMemo\(\(\) => \{[\s\S]*?\}, \[devices\]\);/, newTxMemo);

const oldBlock = `<div key={tx.id} className="flex items-center justify-between p-4 sm:p-5 border-b border-gray-50 dark:border-gray-800 last:border-0">
              <div>
                <p className="font-semibold text-gray-900 dark:text-gray-100">{tx.title}</p>
                <div className="flex items-center space-x-2 space-x-reverse mt-0.5">
                  <span className={\`text-xs font-medium px-1.5 py-0.5 rounded-md \${tx.type === 'sell' ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400' : 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'}\`}>
                    {tx.type === 'sell' ? t('sold', language) : t('bought', language)}
                  </span>
                  <span className="text-xs text-gray-400 dark:text-gray-500">{formatDateLabel(tx.date)}</span>
                </div>
              </div>
              <div className="text-end">
                <p className={\`font-bold \${tx.type === 'sell' ? 'text-indigo-600 dark:text-indigo-400' : 'text-blue-600 dark:text-blue-400'}\`}>
                  {tx.type === 'sell' ? '+' + formatBHD(tx.amount) : '-' + formatBHD(tx.amount)}
                </p>
                {tx.type === 'sell' && tx.profit !== undefined && (
                  <p className={\`text-xs mt-0.5 \${tx.profit >= 0 ? 'text-emerald-500' : 'text-red-500'}\`}>
                    {tx.profit >= 0 ? t('profit', language) : 'خسارة:'} {formatBHD(tx.profit)}
                  </p>
                )}
              </div>
            </div>`;

const newRenderBlock = `<div key={tx.id} className="flex items-center justify-between p-4 sm:p-5 border-b border-gray-50 dark:border-gray-800 last:border-0">
              <div className="flex items-center gap-3">
                <div className={\`p-2 rounded-xl flex-shrink-0 \${
                  tx.type === 'sell' ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' : 
                  tx.type === 'buy' ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400' : 
                  'bg-yellow-100 text-yellow-600 dark:bg-yellow-900/30 dark:text-yellow-400'
                }\`}>
                  {tx.type === 'sell' && <ArrowUpRight className="w-5 h-5" />}
                  {tx.type === 'buy' && <ArrowDownRight className="w-5 h-5" />}
                  {tx.type === 'expense' && <ReceiptText className="w-5 h-5" />}
                </div>
                <div>
                  <p className="font-semibold text-gray-900 dark:text-gray-100">{tx.title}</p>
                  <div className="flex items-center space-x-2 space-x-reverse mt-0.5">
                    <span className={\`text-xs font-medium px-1.5 py-0.5 rounded-md \${
                      tx.type === 'sell' ? 'bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-300' : 
                      tx.type === 'buy' ? 'bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-300' : 
                      'bg-yellow-50 text-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-300'
                    }\`}>
                      {tx.type === 'sell' ? t('sold', language) : tx.type === 'buy' ? t('bought', language) : (language === 'ar' ? 'مصروف' : 'Expense')}
                    </span>
                    <span className="text-xs text-gray-400 dark:text-gray-500">{formatDateLabel(tx.date)}</span>
                  </div>
                </div>
              </div>
              <div className="text-end">
                <p className={\`font-bold \${
                  tx.type === 'sell' ? 'text-green-600 dark:text-green-400' : 
                  tx.type === 'buy' ? 'text-red-600 dark:text-red-400' : 
                  'text-yellow-600 dark:text-yellow-400'
                }\`}>
                  {tx.type === 'sell' ? '+' : '-'}{formatBHD(tx.amount)}
                </p>
                {tx.type === 'sell' && tx.profit !== undefined && (
                  <p className={\`text-xs mt-0.5 \${tx.profit >= 0 ? 'text-emerald-500' : 'text-red-500'}\`}>
                    {tx.profit >= 0 ? t('profit', language) : (language === 'ar' ? 'خسارة:' : 'Loss:')} {formatBHD(tx.profit)}
                  </p>
                )}
              </div>
            </div>`;

c = c.replace(oldBlock, newRenderBlock);

fs.writeFileSync('src/views/Dashboard.tsx', c);
