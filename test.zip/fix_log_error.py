import sys

with open('src/store.tsx', 'r') as f:
    content = f.read()

target = """  const logError = (code: string, message: string, details?: string) => {
    setErrors(prev => {
      const newErrors = [{
        id: Math.random().toString(36).substr(2, 9),
        code,
        message,
        timestamp: new Date().toISOString(),
        details,
        path: window.location.pathname
      }, ...prev].slice(0, 50); // Keep last 50
      localStorage.setItem('ps_errors', JSON.stringify(newErrors));
      
      // Also show a toast/alert or dispatch event
      window.dispatchEvent(new CustomEvent('app-error', { detail: { code, message } }));
      
      return newErrors;
    });
  };"""

replacement = """  const logError = async (code: string, message: string, details?: string) => {
    const errorId = Math.random().toString(36).substr(2, 9);
    const newError = {
      id: errorId,
      code,
      message,
      timestamp: new Date().toISOString(),
      details: details || '',
      path: window.location.pathname
    };

    setErrors(prev => {
      const newErrors = [newError, ...prev].slice(0, 50);
      localStorage.setItem('ps_errors', JSON.stringify(newErrors));
      return newErrors;
    });

    window.dispatchEvent(new CustomEvent('app-error', { detail: { code, message } }));

    // Async cloud logging
    if (auth.currentUser) {
      try {
        await setDoc(doc(db, 'appErrors', errorId), {
          ...newError,
          userId: auth.currentUser.uid,
          userEmail: auth.currentUser.email,
          workspaceId: activeWorkspaceId || auth.currentUser.uid,
          userAgent: navigator.userAgent
        });
      } catch (e) {
        console.warn("Failed to log error to cloud:", e);
      }
    }
  };"""

if target in content:
    content = content.replace(target, replacement)
    with open('src/store.tsx', 'w') as f:
        f.write(content)
    print("Updated logError for cloud sync")
else:
    print("target not found")
