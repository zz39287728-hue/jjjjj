const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

c = c.replace(
  /\{dev\.status === 'sold' && dev\.soldExtras && dev\.soldExtras\.length > 0 && \([\s\S]*?<\/div>\s*\)\}/,
  `{dev.status === 'sold' && dev.extras && dev.extras.filter(e => !dev.soldExtras?.includes(e)).length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1.5">
                          <span className="text-[10px] text-gray-500 dark:text-gray-400 my-auto me-1">{t('kept_extras', language)}</span>
                          {dev.extras.filter(e => !dev.soldExtras?.includes(e)).map((extra, idx) => (
                            <span key={idx} className="bg-green-50 text-green-700 border border-green-100 dark:bg-green-900/30 dark:border-green-800/50 dark:text-green-400 text-[10px] px-2 py-0.5 rounded-full font-medium">
                              {translateExtra(extra)}
                            </span>
                          ))}
                        </div>
                      )}`
);

fs.writeFileSync('src/views/Inventory.tsx', c);
