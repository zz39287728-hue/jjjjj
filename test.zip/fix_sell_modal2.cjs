const fs = require('fs');
const file = 'src/components/SellModal.tsx';
const lines = fs.readFileSync(file, 'utf8').split('\n');

let insideBadBlock = false;
let outLines = [];
let i = 0;
while (i < lines.length) {
    if (lines[i].includes('const isSelected = soldExtras.includes(extra);') && lines[i+1] && lines[i+1].includes('if (isSold) {') && lines[i+2] && lines[i+2].includes('return (')) {
        outLines.push(lines[i]); // push the isSelected line
        i++;
        // now skip lines until we hit the "return (" for the button
        while (i < lines.length) {
            if (lines[i].includes('return (') && lines[i+1] && lines[i+1].includes('<button')) {
                break;
            }
            i++;
        }
        // we are at the "return (" for the button, push it and continue
        outLines.push(lines[i]);
    } else {
        outLines.push(lines[i]);
    }
    i++;
}

fs.writeFileSync(file, outLines.join('\n'));
console.log('Fixed SellModal.tsx');
