const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

if (!c.includes('activeWorkspaceId: string;')) {
  // 1. Add activeWorkspaceId to StoreState
  c = c.replace(/  exportData: \(\) => void;\n  importData: \(data: any\[\]\) => void;/,
    "  exportData: () => void;\n  importData: (data: any[]) => void;\n  activeWorkspaceId: string;\n  setActiveWorkspaceId: (id: string) => void;\n  generateInviteCode: () => Promise<string>;\n  joinWorkspace: (workspaceId: string, inviteCode: string) => Promise<boolean>;\n  clearWorkspace: () => void;");

  // 2. Add properties to useStore
  c = c.replace(/export const useStore = create<StoreState>\(\(set, get\) => \(\{/,
    "export const useStore = create<StoreState>((set, get) => ({\n  activeWorkspaceId: localStorage.getItem('activeWorkspaceId') || '',\n  setActiveWorkspaceId: (id: string) => {\n    localStorage.setItem('activeWorkspaceId', id);\n    set({ activeWorkspaceId: id });\n    // Re-trigger listeners\n    const state = get();\n    if (state.user) {\n       // a simple hack to re-init listeners is to call auth state change manually but since we can't easily, we just reload the page\n       window.location.reload();\n    }\n  },\n  clearWorkspace: () => {\n    localStorage.removeItem('activeWorkspaceId');\n    set({ activeWorkspaceId: '' });\n    window.location.reload();\n  },");

  // 3. Update activeWorkspaceId usage in queries and creates
  // We need to change where('userId', '==', user.uid) to where('userId', '==', workspaceIdToUse)
  // And newDoc... userId: user.uid to userId: workspaceIdToUse
  c = c.replace(/const unsubDevices = onSnapshot\(query\(collection\(db, 'devices'\), where\('userId', '==', user\.uid\)\), \(snapshot\) => \{/g,
    "const workspaceId = get().activeWorkspaceId || user.uid;\n    const unsubDevices = onSnapshot(query(collection(db, 'devices'), where('userId', '==', workspaceId)), (snapshot) => {");

  c = c.replace(/const unsubExpenses = onSnapshot\(query\(collection\(db, 'generalExpenses'\), where\('userId', '==', user\.uid\)\), \(snapshot\) => \{/g,
    "const workspaceId = get().activeWorkspaceId || user.uid;\n    const unsubExpenses = onSnapshot(query(collection(db, 'generalExpenses'), where('userId', '==', workspaceId)), (snapshot) => {");

  c = c.replace(/const unsubDebts = onSnapshot\(query\(collection\(db, 'generalDebts'\), where\('userId', '==', user\.uid\)\), \(snapshot\) => \{/g,
    "const workspaceId = get().activeWorkspaceId || user.uid;\n    const unsubDebts = onSnapshot(query(collection(db, 'generalDebts'), where('userId', '==', workspaceId)), (snapshot) => {");

  c = c.replace(/userId: user\.uid/g, "userId: get().activeWorkspaceId || get().user?.uid");

  // 4. Implement generateInviteCode and joinWorkspace
  const workspaceFuncs = `
  generateInviteCode: async () => {
    const { user } = get();
    if (!user) return '';
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    try {
      await setDoc(doc(db, 'workspaces', user.uid), { inviteCode: code, updatedAt: Date.now() }, { merge: true });
      return code;
    } catch (error) {
      console.error(error);
      return '';
    }
  },
  joinWorkspace: async (workspaceId: string, inviteCode: string) => {
    const { user } = get();
    if (!user) return false;
    try {
      await setDoc(doc(db, 'workspaces', workspaceId, 'members', user.uid), {
        inviteCode,
        joinedAt: Date.now()
      });
      get().setActiveWorkspaceId(workspaceId);
      return true;
    } catch (error) {
      console.error(error);
      return false;
    }
  },`;
  c = c.replace(/  exportData: \(\) => \{/, workspaceFuncs + "\n  exportData: () => {");
  
  fs.writeFileSync('src/store.tsx', c);
  console.log("Updated store.tsx");
}
