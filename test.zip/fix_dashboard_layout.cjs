const fs = require('fs');
let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

const debtBlock = `        <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 col-span-2 flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="p-3 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-xl">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{t('total_debt', language)}</p>
              <p className="text-xl font-bold text-gray-900 dark:text-gray-100">{formatBHD(totalDebt)}</p>
            </div>
          </div>
        </div>
      </div>`;

c = c.replace(/          <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">\{soldDevices\.length\} \{t\('sold_devices', language\)\}<\/p>\n        <\/div>\n      <\/div>/, `          <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{soldDevices.length} {t('sold_devices', language)}</p>\n        </div>\n${debtBlock}`);

fs.writeFileSync('src/views/Dashboard.tsx', c);
