const fs = require('fs');
let c = fs.readFileSync('index.html', 'utf8');

if (!c.includes('apple-touch-icon')) {
  c = c.replace(/<\/head>/, `
  <meta name="theme-color" content="#ffffff" />
  <meta name="mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="default" />
  <meta name="apple-mobile-web-app-title" content="PSInv" />
  <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
  <link rel="icon" type="image/svg+xml" href="/icon.svg" />
  </head>`);
  fs.writeFileSync('index.html', c);
  console.log("Updated index.html");
}
