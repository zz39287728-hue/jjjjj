const fs = require('fs');
let c = fs.readFileSync('index.html', 'utf8');
c = c.replace(/<html lang="ar" dir="rtl">/, '<html lang="ar">');
fs.writeFileSync('index.html', c);
