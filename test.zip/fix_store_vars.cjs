const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

const badChunk = `        const [activeWorkspaceId, setActiveWorkspaceId] = useState<string>('');
    const generateInviteCode = async () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const joinWorkspace = async (workspaceId: string, inviteCode: string) => {
    alert("Not fully implemented yet");
    return false;
  };

  const clearWorkspace = () => {
    setActiveWorkspaceId('');
  };

  return (localStorage.getItem('ps_lang') as Language) || 'ar';`;

c = c.replace(badChunk, "      return (localStorage.getItem('ps_lang') as Language) || 'ar';");

fs.writeFileSync('src/store.tsx', c);
console.log("Fixed store.tsx");
