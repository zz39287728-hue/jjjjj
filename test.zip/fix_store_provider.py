import sys

with open('src/store.tsx', 'r') as f:
    content = f.read()

target = "activeWorkspaceId, setActiveWorkspaceId, generateInviteCode, joinWorkspace, clearWorkspace"
replacement = "activeWorkspaceId, setActiveWorkspaceId, generateInviteCode, joinWorkspace, clearWorkspace, errors, logError, clearErrors"

if target in content:
    content = content.replace(target, replacement)
    with open('src/store.tsx', 'w') as f:
        f.write(content)
    print("Fixed StoreProvider value")
