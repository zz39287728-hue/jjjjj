import sys

with open('src/App.tsx', 'r') as f:
    content = f.read()

def r(target, rep):
    global content
    content = content.replace(target, rep)

r(">ديون وقروض<", ">{t('debts_and_loans', language)}<")
r(">شراء جهاز<", ">{t('buy_new_device', language)}<")
r(">المصاريف<", ">{t('expenses', language)}<")

with open('src/App.tsx', 'w') as f:
    f.write(content)

print("App language updated.")
