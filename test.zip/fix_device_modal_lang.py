import sys

with open('src/components/DeviceDetailsModal.tsx', 'r') as f:
    content = f.read()

# Make sure we can use t
if "import { t } from '../i18n';" not in content:
    content = content.replace("import { Device } from '../types';", "import { Device } from '../types';\nimport { t } from '../i18n';")

def r(target, rep):
    global content
    content = content.replace(target, rep)

r("{isEditing ? 'تعديل التفاصيل' : 'تفاصيل الجهاز'}", "{isEditing ? t('edit_details', language) : t('device_details', language)}")
r("<Check className=\"w-4 h-4 me-1\" /> حفظ", "<Check className=\"w-4 h-4 me-1\" /> {t('save', language)}")
r("{isSold ? \"المعلومات الأساسية ومعلومات البائع\" : \"المعلومات الأساسية والشراء (من البائع)\"}", "{t('main_purchase_info', language)}")
r(">العنوان<", ">{t('title', language)}<")
r(">الموديل (الإصدار - النسخة)<", ">{t('model', language)}<")
r(">سعر الشراء (د.ب)<", ">{t('buy_price', language)}<")
r(">تاريخ الشراء<", ">{t('buy_date', language)}<")
r(">المنطقة<", ">{t('area', language)}<")
r(">الإضافات الأصلية<", ">{t('original_extras', language)}<")
r(">حقيبة<", ">{t('bag', language)}<")
r(">جهاز تحكم إضافي<", ">{t('extra_controller', language)}<")
r(">شريط إضافي<", ">{t('cd', language)}<")
r(">سماعة<", ">{t('headset', language)}<")
r(">مبرد<", ">{t('cooler', language)}<")
r(">قاعدة<", ">{t('stand', language)}<")
r(">أخرى<", ">{t('other', language)}<")
r('placeholder="اسم الشريط (مثال: FIFA 24)"', 'placeholder={t("cd_name", language)}')
r('placeholder="اسم الإضافة الأخرى"', 'placeholder={t("other_name", language)}')
r(">معلومات المشتري<", ">{t('sale_info', language)}<")
r(">سعر البيع (د.ب)<", ">{t('sell_price', language)}<")
r(">تاريخ البيع<", ">{t('sell_date', language)}<")
r(">اسم المشتري<", ">{t('buyer_name', language)}<")
r(">منطقة المشتري<", ">{t('buyer_area', language)}<")
r(">رقم هاتف المشتري<", ">{t('buyer_phone', language)}<")
r(">الإضافات المباعة مع الجهاز<", ">{t('sold_extras', language)}<")
r(">لم يتم اختيار إضافات أصلية.<", ">{t('no_original_extras', language)}<")

r("الشراء: {formatDate(device.buyDate)}", "{language === 'ar' ? 'الشراء: ' : 'Buy: '}{formatDate(device.buyDate)}")
r("البيع: {formatDate(device.sellDate)}", "{language === 'ar' ? 'البيع: ' : 'Sell: '}{formatDate(device.sellDate)}")
r(">سعر الشراء<", ">{t('buy_cost', language)}<")
r(">سعر البيع<", ">{t('sell_price', language).replace(' (د.ب)', '')}<")
r("{device.sellPrice - device.buyPrice >= 0 ? 'الربح: ' : 'الخسارة: '}", "{device.sellPrice - device.buyPrice >= 0 ? t('profit', language) : t('loss', language)}")

r("{isSold ? <h4 className=\"font-semibold text-gray-900 dark:text-gray-100\">معلومات البائع</h4> : <h4 className=\"font-semibold text-gray-900 dark:text-gray-100\">معلومات الشراء (البائع)</h4>}", "<h4 className=\"font-semibold text-gray-900 dark:text-gray-100\">{t('purchase_details', language)}</h4>")

r(">إجمالي المصاريف:<", ">{language === 'ar' ? 'إجمالي المصاريف:' : 'Total Expenses:'}<")
r(">المنطقة:<", ">{language === 'ar' ? 'المنطقة:' : 'Area:'}<")
r(">الهاتف:<", ">{language === 'ar' ? 'الهاتف:' : 'Phone:'}<")
r("> عرض صورة محادثة البائع<", "> {t('view_seller_chat', language)}<")
r(">لا توجد تفاصيل شراء.<", ">{t('no_purchase_details', language)}<")
r(">الإضافات الأصلية:<", ">{t('original_extras', language)}:<")
r("معلومات المشتري", "{t('sale_details', language)}")
r("الدفع عبر بنفت", "{language === 'ar' ? 'الدفع عبر بنفت' : 'Paid via Benefit'}")
r("دفع كاش", "{language === 'ar' ? 'دفع كاش' : 'Paid in Cash'}")
r(">بنفت:<", ">{language === 'ar' ? 'بنفت:' : 'Benefit:'}<")
r(">كاش:<", ">{language === 'ar' ? 'كاش:' : 'Cash:'}<")
r(">الاسم:<", ">{language === 'ar' ? 'الاسم:' : 'Name:'}<")
r(">لا توجد تفاصيل مشتري.<", ">{t('no_sale_details', language)}<")

with open('src/components/DeviceDetailsModal.tsx', 'w') as f:
    f.write(content)

print("DeviceDetailsModal language updated.")
