const fs = require('fs');
const content = fs.readFileSync('src/store.tsx', 'utf8');
console.log(content.match(/userId: get/g));
