const fs = require('fs');
let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

const newTotalProfit = `  const totalProfit = soldDevices.reduce((sum, d) => {
    const extraProfit = d.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
    const baseProfit = (d.sellPrice || 0) - d.buyPrice - (d.expenses?.reduce((eSum, e) => eSum + e.amount, 0) || 0);
    return sum + baseProfit + extraProfit;
  }, 0);
  
  const totalSales = soldDevices.reduce((sum, d) => {
    const extraProfit = d.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
    return sum + (d.sellPrice || 0) + extraProfit;
  }, 0);`;

c = c.replace(/const totalProfit = [\s\S]*?const totalSales = [\s\S]*?, 0\);/, newTotalProfit);

fs.writeFileSync('src/views/Dashboard.tsx', c);
