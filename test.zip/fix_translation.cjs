const fs = require('fs');
let c1 = fs.readFileSync('src/views/GeneralDebtForm.tsx', 'utf8');
let c2 = fs.readFileSync('src/views/GeneralExpenseForm.tsx', 'utf8');

c1 = c1.replace(/import \{ useTranslation \} from '\.\.\/i18n';/, "import { t } from '../i18n';");
c1 = c1.replace(/const \{ t \} = useTranslation\(\);/, "");
c1 = c1.replace(/t\(/g, "t(");

c2 = c2.replace(/import \{ useTranslation \} from '\.\.\/i18n';/, "import { t } from '../i18n';");
c2 = c2.replace(/const \{ t \} = useTranslation\(\);/, "");
c2 = c2.replace(/t\(/g, "t(");

fs.writeFileSync('src/views/GeneralDebtForm.tsx', c1);
fs.writeFileSync('src/views/GeneralExpenseForm.tsx', c2);
