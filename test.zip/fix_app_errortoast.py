import sys

with open('src/App.tsx', 'r') as f:
    content = f.read()

if "import ErrorToast from" not in content:
    content = content.replace("import SettingsView from './views/SettingsView';", "import SettingsView from './views/SettingsView';\nimport ErrorToast from './components/ErrorToast';")

if "<ErrorToast />" not in content:
    content = content.replace("<div className=\"h-screen w-full", "<ErrorToast />\n    <div className=\"h-screen w-full")
    with open('src/App.tsx', 'w') as f:
        f.write(content)
    print("Added ErrorToast to App.tsx")
