const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

const newViewKept = `                  {device.extras && device.extras.filter(e => !device.soldExtras?.includes(e)).length > 0 && (
                    <div className="pt-3 border-t border-gray-50 dark:border-gray-800">
                      <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">{t('kept_extras', language)}</p>
                      <div className="flex flex-col gap-2">
                        {device.extras.filter(e => !device.soldExtras?.includes(e)).map((extra, idx) => {
                          const actionObj = device.extraActions?.find(a => a.extraName === extra);
                          let statusText = '';
                          let statusColor = 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300';
                          
                          if (actionObj?.action === 'sold') {
                            statusText = \`\${t('action_sold', language)} - \${formatBHD(actionObj.price || 0)}\`;
                            statusColor = 'bg-indigo-50 text-indigo-700 border border-indigo-100 dark:bg-indigo-900/30 dark:border-indigo-800/50 dark:text-indigo-400';
                          } else if (actionObj?.action === 'gifted') {
                            statusText = actionObj.notes ? \`\${t('action_gifted', language)} (\${actionObj.notes})\` : t('action_gifted', language);
                            statusColor = 'bg-pink-50 text-pink-700 border border-pink-100 dark:bg-pink-900/30 dark:border-pink-800/50 dark:text-pink-400';
                          } else if (actionObj?.action === 'kept_personal') {
                            statusText = actionObj.notes ? \`\${t('action_kept', language)} (\${actionObj.notes})\` : t('action_kept', language);
                            statusColor = 'bg-emerald-50 text-emerald-700 border border-emerald-100 dark:bg-emerald-900/30 dark:border-emerald-800/50 dark:text-emerald-400';
                          }
                          
                          return (
                            <div key={idx} className="flex justify-between items-center text-xs">
                              <span className="font-medium text-gray-800 dark:text-gray-200">{translateExtra(extra)}</span>
                              {statusText ? (
                                <span className={\`text-[10px] px-2 py-0.5 rounded-full font-medium \${statusColor}\`}>
                                  {statusText}
                                </span>
                              ) : (
                                <span className="bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400 text-[10px] px-2 py-0.5 rounded-full">
                                  {t('action_pending', language)}
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}`;

c = c.replace(/\{device\.extras && device\.extras\.filter\(e => !device\.soldExtras\?\.includes\(e\)\)\.length > 0 && \([\s\S]*?<\/div>\n                  \)\}/, newViewKept);

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
