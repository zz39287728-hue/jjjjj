import sys

with open('vite.config.ts', 'r') as f:
    content = f.read()

content = content.replace("name: 'PS Inventory'", "name: 'ZakiTation'")
content = content.replace("short_name: 'PSInv'", "short_name: 'ZakiTation'")
content = content.replace("description: 'PlayStation Inventory App'", "description: 'ZakiTation App for Playstation Stores'")

content = content.replace("""        icons: [
          {
            src: '/icon.png',
            sizes: '192x192',
            type: 'image/png',
            purpose: 'any',
          },
          {
            src: '/icon.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'any',
          },
          {
            src: '/icon.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable',
          }
        ],""", """        icons: [
          {
            src: '/pwa-192x192.png',
            sizes: '192x192',
            type: 'image/png',
            purpose: 'any',
          },
          {
            src: '/pwa-512x512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'any',
          },
          {
            src: '/pwa-maskable-512x512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable',
          }
        ],""")

with open('vite.config.ts', 'w') as f:
    f.write(content)
print("Updated vite.config.ts")
