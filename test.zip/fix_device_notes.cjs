const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/placeholder=\{t\('extra_notes', language\)\}/, "placeholder={actionObj.action === 'gifted' ? t('extra_notes', language) : (language === 'ar' ? 'ملاحظات' : 'Notes')}");

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
