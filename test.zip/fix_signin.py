import sys

with open('src/store.tsx', 'r') as f:
    content = f.read()

target = """  const signIn = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      
      const localDevices = JSON.parse(localStorage.getItem('ps_devices') || '[]');
      if (localDevices.length > 0 && auth.currentUser) {
        const batch = writeBatch(db);
        localDevices.forEach((dev: any) => {
          const newDoc = doc(collection(db, 'devices'));
          const deviceToSave: Device = {
            ...dev,
            id: newDoc.id,
            userId: auth.currentUser!.uid,
            createdAt: Date.now(),
            updatedAt: Date.now()
          };
          batch.set(newDoc, deviceToSave);
        });
        await batch.commit();
        localStorage.removeItem('ps_devices');
      }
    } catch (e) {
      console.error(e);
    }
  };"""

replacement = """  const signIn = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      
      const localDevices = JSON.parse(localStorage.getItem('ps_devices') || '[]');
      if (localDevices.length > 0 && auth.currentUser) {
        const batch = writeBatch(db);
        localDevices.forEach((dev: any) => {
          const newDoc = doc(collection(db, 'devices'));
          const deviceToSave: Device = {
            ...dev,
            id: newDoc.id,
            userId: auth.currentUser!.uid,
            createdAt: Date.now(),
            updatedAt: Date.now()
          };
          batch.set(newDoc, deviceToSave);
        });
        await batch.commit();
        localStorage.removeItem('ps_devices');
      }
    } catch (e: any) {
      console.error("Auth Error:", e);
      if (e.code === 'auth/popup-blocked' || e.code === 'auth/popup-closed-by-user') {
        alert("فشلت عملية تسجيل الدخول لأن المتصفح منع النافذة المنبثقة. يرجى فتح التطبيق في علامة تبويب جديدة (New Tab) أو السماح بالنوافذ المنبثقة.");
      } else {
        alert("حدث خطأ أثناء تسجيل الدخول: " + e.message + "\\nيرجى محاولة فتح التطبيق في نافذة جديدة (Open in New Tab).");
      }
    }
  };"""

if target in content:
    with open('src/store.tsx', 'w') as f:
        f.write(content.replace(target, replacement))
    print("Fixed signIn in store.tsx")
else:
    print("Target not found in store")

