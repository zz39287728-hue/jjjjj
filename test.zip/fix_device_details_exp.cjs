const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/import \{ Device \} from '\.\.\/types';/, "import { Device, Expense } from '../types';\nimport { Receipt } from 'lucide-react';");

c = c.replace(/const \[area, setArea\] = useState\(device\.area \|\| ''\);/, "const [area, setArea] = useState(device.area || '');\n  const [expenses, setExpenses] = useState<Expense[]>(device.expenses || []);");

const newSave = `      area,
      sellerName,
      sellerPhone,
      expenses,`;
c = c.replace(/area,\n\s*sellerName,\n\s*sellerPhone,/, newSave);

const addExpenseSection = `                <div>
                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">{t('expenses', language)}</label>
                  {expenses.map((exp, idx) => (
                    <div key={exp.id} className="flex gap-2 mb-2 items-center bg-gray-50 dark:bg-gray-700/50 p-2 rounded-lg border border-gray-100 dark:border-gray-700">
                      <select 
                        value={exp.type}
                        onChange={(e) => {
                          const newExp = [...expenses];
                          newExp[idx].type = e.target.value as any;
                          setExpenses(newExp);
                        }}
                        className="flex-1 p-1.5 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md outline-none"
                      >
                        <option value="petrol_dad">{t('exp_petrol_dad', language)}</option>
                        <option value="petrol">{t('exp_petrol', language)}</option>
                        <option value="dinner_abbas">{t('exp_dinner_abbas', language)}</option>
                        <option value="maintenance">{t('exp_maintenance', language)}</option>
                        <option value="delivery">{t('exp_delivery', language)}</option>
                        <option value="other">{t('exp_other', language)}</option>
                      </select>
                      {exp.type === 'other' && (
                        <input 
                          type="text"
                          placeholder={t('expense_custom_name', language)}
                          value={exp.customName || ''}
                          onChange={(e) => {
                            const newExp = [...expenses];
                            newExp[idx].customName = e.target.value;
                            setExpenses(newExp);
                          }}
                          className="flex-1 p-1.5 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md outline-none w-20"
                        />
                      )}
                      <input 
                        type="number"
                        placeholder={t('expense_amount', language)}
                        value={exp.amount || ''}
                        onChange={(e) => {
                          const newExp = [...expenses];
                          newExp[idx].amount = parseFloat(e.target.value) || 0;
                          setExpenses(newExp);
                        }}
                        className="w-16 p-1.5 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md outline-none"
                      />
                      <button type="button" onClick={() => setExpenses(expenses.filter((_, i) => i !== idx))} className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 p-1.5 rounded-md transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => setExpenses([...expenses, { id: Date.now().toString(), type: 'other', amount: 0 }])}
                    className="mt-1 w-full py-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-xs font-medium rounded-lg border border-indigo-100 dark:border-indigo-800 hover:bg-indigo-100 transition-colors"
                  >
                    + {t('add_expense', language)}
                  </button>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 mb-2">الإضافات الأصلية</label>`;

c = c.replace(/<div>\n\s*<label className="block text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 mb-2">الإضافات الأصلية<\/label>/, addExpenseSection);

const viewExpenseSection = `              <div className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm space-y-4">
                <h4 className="font-semibold text-gray-900 dark:text-gray-100 dark:text-gray-900">معلومات الشراء</h4>
                
                {device.expenses && device.expenses.length > 0 && (
                  <div className="space-y-2 mb-3 pb-3 border-b border-gray-50 dark:border-gray-800">
                    <div className="flex items-center text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      <Receipt className="w-4 h-4 me-2 text-indigo-500" />
                      {t('expenses', language)}
                    </div>
                    {device.expenses.map((exp, idx) => (
                      <div key={idx} className="flex justify-between items-center text-xs bg-gray-50 dark:bg-gray-700/50 p-2 rounded-lg border border-gray-100 dark:border-gray-700">
                        <span className="text-gray-600 dark:text-gray-300">
                          {exp.type === 'other' ? exp.customName || t('exp_other', language) : t(\`exp_\${exp.type}\` as any, language)}
                        </span>
                        <span className="font-bold text-gray-900 dark:text-gray-100">{formatBHD(exp.amount)}</span>
                      </div>
                    ))}
                    <div className="flex justify-between items-center text-xs pt-1 px-1">
                      <span className="text-gray-500 dark:text-gray-400 font-medium">إجمالي المصاريف:</span>
                      <span className="font-bold text-indigo-600 dark:text-indigo-400">{formatBHD(device.expenses.reduce((s, e) => s + e.amount, 0))}</span>
                    </div>
                  </div>
                )}
`;

c = c.replace(/<div className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm space-y-4">\n\s*<h4 className="font-semibold text-gray-900 dark:text-gray-100 dark:text-gray-900">معلومات الشراء<\/h4>/, viewExpenseSection);

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
