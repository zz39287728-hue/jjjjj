const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

const imagePortal = `      <AnimatePresence>
        {viewingImage && document.getElementById('modal-root') && createPortal(
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[100] bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm pointer-events-auto" 
            onClick={() => setViewingImage(null)}
          >
            <button className="absolute top-4 right-4 bg-white/20 hover:bg-white/30 text-white rounded-full p-2 transition-colors">
              <X className="w-6 h-6" />
            </button>
            <motion.img 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", damping: 20, stiffness: 300 }}
              src={viewingImage} 
              alt="Chat screenshot" 
              className="max-w-full max-h-[90vh] rounded-xl shadow-2xl" 
              onClick={e => e.stopPropagation()} 
            />
          </motion.div>,
          document.getElementById('modal-root')!
        )}
      </AnimatePresence>`;

c = c.replace(/      <AnimatePresence>\n        \{viewingImage && \([\s\S]*?<\/AnimatePresence>/, imagePortal);

fs.writeFileSync('src/views/Inventory.tsx', c);
