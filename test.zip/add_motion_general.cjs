const fs = require('fs');

function addMotion(file) {
  let c = fs.readFileSync(file, 'utf8');
  if (!c.includes('motion/react')) {
    c = c.replace(/import \{ t \} from '\.\.\/i18n';/, "import { t } from '../i18n';\nimport { motion } from 'motion/react';");
    
    // Add staggered animations for form fields
    c = c.replace(/<div className="space-y-1">/g, '<motion.div variants={{hidden: {opacity:0, y:20}, show: {opacity:1, y:0}}} className="space-y-1">');
    
    c = c.replace(/<div className="flex flex-col gap-4">/, '<motion.div initial="hidden" animate="show" variants={{show: {transition: {staggerChildren: 0.1}}}} className="flex flex-col gap-4">');
    
    c = c.replace(/<\/div>\n      <div className="h-20" \/>/g, '</motion.div>\n      <div className="h-20" />');

    // Button
    c = c.replace(/<button\n          onClick=\{handleSave\}/g, '<motion.button\n          whileTap={{ scale: 0.95 }}\n          onClick={handleSave}');
    c = c.replace(/\{t\('save', language\)\}\n        <\/button>/g, "{t('save', language)}\n        </motion.button>");

    fs.writeFileSync(file, c);
    console.log("Updated " + file);
  }
}

addMotion('src/views/GeneralDebtForm.tsx');
addMotion('src/views/GeneralExpenseForm.tsx');
