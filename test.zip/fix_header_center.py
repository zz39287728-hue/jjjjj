import sys

with open('src/App.tsx', 'r') as f:
    content = f.read()

target = """              <header className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-800 p-4 shrink-0 shadow-sm z-10 relative pt-safe flex justify-between items-center transition-colors">
                <div className="flex items-center">
                  {(activeTab === 'add' || activeTab === 'add_debt' || activeTab === 'add_expense') ? (
                    <button onClick={() => { hapticFeedback('light'); setActiveTab('inventory'); }} className="flex items-center text-sm font-medium text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                       {t('cancel', language)}
                    </button>
                  ) : (activeTab === 'borrowed_list' || activeTab === 'lent_list') ? (
                    <button onClick={() => { hapticFeedback('light'); setActiveTab('home'); }} className="flex items-center text-sm font-medium text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                       {language === 'ar' ? <ArrowRight className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
                    </button>
                  ) : (
                    <h1 className="text-xl sm:text-2xl font-black bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 dark:from-indigo-400 dark:via-purple-400 dark:to-indigo-400 bg-clip-text text-transparent drop-shadow-sm truncate">
                      تجارة حمازك وعبازك
                    </h1>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <PWAInstallButton />
                  <motion.button whileTap={{ scale: 0.9 }} onClick={() => { hapticFeedback('medium'); setShowSettings(true); }} className="p-1.5 text-gray-400 dark:text-gray-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-full transition-colors">
                    <Settings className="w-5 h-5" />
                  </motion.button>
                </div>
              </header>"""

replacement = """              <header className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-800 p-4 shrink-0 shadow-sm z-10 relative pt-safe flex justify-between items-center transition-colors min-h-[72px]">
                <div className="flex items-center z-10 w-16">
                  {(activeTab === 'add' || activeTab === 'add_debt' || activeTab === 'add_expense') ? (
                    <button onClick={() => { hapticFeedback('light'); setActiveTab('inventory'); }} className="flex items-center text-sm font-medium text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                       {t('cancel', language)}
                    </button>
                  ) : (activeTab === 'borrowed_list' || activeTab === 'lent_list') ? (
                    <button onClick={() => { hapticFeedback('light'); setActiveTab('home'); }} className="flex items-center text-sm font-medium text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                       {language === 'ar' ? <ArrowRight className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
                    </button>
                  ) : null}
                </div>

                {!(activeTab === 'add' || activeTab === 'add_debt' || activeTab === 'add_expense' || activeTab === 'borrowed_list' || activeTab === 'lent_list') && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <h1 className="text-xl sm:text-2xl font-black bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 dark:from-indigo-400 dark:via-purple-400 dark:to-indigo-400 bg-clip-text text-transparent drop-shadow-sm truncate">
                      تجارة حمازك وعبازك
                    </h1>
                  </div>
                )}

                <div className="flex items-center gap-2 z-10 justify-end w-16">
                  <PWAInstallButton />
                  <motion.button whileTap={{ scale: 0.9 }} onClick={() => { hapticFeedback('medium'); setShowSettings(true); }} className="p-1.5 text-gray-400 dark:text-gray-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-full transition-colors">
                    <Settings className="w-5 h-5" />
                  </motion.button>
                </div>
              </header>"""

if target in content:
    with open('src/App.tsx', 'w') as f:
        f.write(content.replace(target, replacement))
    print("Header replaced successfully (centered).")
else:
    print("Target block not found.")
