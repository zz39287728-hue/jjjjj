const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/<motion.div\n      initial=\{\{ opacity: 0 \}\}\n      animate=\{\{ opacity: 1 \}\}\n      exit=\{\{ opacity: 0 \}\}\n      className="absolute inset-0 z-40 bg-black\/40 backdrop-blur-sm flex items-end sm:items-center justify-center" \n      onClick=\{onClose\}\n    >/, `<motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 z-40 flex items-end sm:items-center justify-center" 
    >`);

c = c.replace(/      <motion.div \n        initial=\{\{ y: 100, opacity: 0 \}\}\n        animate=\{\{ y: 0, opacity: 1 \}\}\n        exit=\{\{ y: 100, opacity: 0 \}\}\n        className="bg-white dark:bg-gray-900 w-full sm:max-w-md sm:rounded-3xl rounded-t-3xl shadow-2xl overflow-hidden flex flex-col sm:max-h-\[85vh\] max-h-\[90vh\]"\n        onClick=\{e => e.stopPropagation\(\)\}\n      >/, `      <motion.div 
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        className="bg-white dark:bg-gray-900 w-full sm:max-w-md sm:rounded-3xl rounded-t-3xl shadow-2xl overflow-hidden flex flex-col sm:max-h-[85vh] max-h-[90vh]"
      >`);

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
