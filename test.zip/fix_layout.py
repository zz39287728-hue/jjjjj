import sys

with open('src/views/Inventory.tsx', 'r') as f:
    content = f.read()

# First we need to extract the current sold map block
start_marker = "                if (dev.status === 'sold') {"
end_marker = """                  );
                }

                return (
                  <motion.div"""

start_idx = content.find(start_marker)
end_idx = content.find(end_marker) + len("""                  );
                }""")

target = content[start_idx:end_idx]

replacement = """                if (dev.status === 'sold') {
                  const extraProfit = dev.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
                  const expenses = dev.expenses?.reduce((eSum, e) => eSum + e.amount, 0) || 0;
                  const totalProfit = (dev.sellPrice || 0) - dev.buyPrice - expenses + extraProfit;
                  
                  return (
                    <motion.div 
                      key={dev.id}
                      layout
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                      onClick={() => setSelectedDevice(dev)}
                      className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-800 relative cursor-pointer hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors flex flex-col"
                    >
                      {/* Top Header: Title & Dates */}
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1 min-w-0 text-right pr-2">
                          <h3 className="font-bold text-gray-900 dark:text-gray-100 truncate text-sm sm:text-base leading-tight">{dev.title || dev.model}</h3>
                          {dev.title && <p className="text-[11px] text-gray-500 truncate mt-0.5">{dev.model}</p>}
                        </div>
                        <div className="flex items-start gap-2 shrink-0">
                          <div className="flex flex-col items-end text-[10px] text-gray-400 leading-[1.3] pt-0.5" dir="ltr">
                            <div>Buy: {formatDate(dev.buyDate)}</div>
                            {dev.sellDate && <div>Sell: {formatDate(dev.sellDate)}</div>}
                          </div>
                          <button 
                            onClick={(e) => { e.stopPropagation(); setDeviceToDelete(dev); }} 
                            className="text-gray-400 hover:text-red-500 transition-colors -mt-0.5"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Extras Badges */}
                      {dev.extras && dev.extras.length > 0 && (
                        <div className="flex flex-wrap justify-end gap-1.5 mb-3">
                           {dev.extras.map((extra, idx) => (
                             <span key={idx} className="bg-indigo-50 text-indigo-700 border border-indigo-100 dark:bg-indigo-900/30 dark:border-indigo-800/50 dark:text-indigo-400 text-[10px] px-2 py-0.5 rounded-md font-medium">
                               {translateExtra(extra)}
                             </span>
                           ))}
                        </div>
                      )}

                      {/* Contact Info (From / To) */}
                      {(dev.sellerPhone || dev.buyerPhone) && (
                        <div className="flex justify-between items-center text-[11px] bg-gray-50/80 dark:bg-gray-900/40 rounded-xl p-2 mb-3 border border-gray-100 dark:border-gray-800/60">
                           <div className="flex flex-col gap-0.5">
                             <span className="text-gray-400">{language === 'ar' ? 'البائع:' : 'Seller:'}</span>
                             {dev.sellerPhone ? (
                               <a onClick={e=>e.stopPropagation()} href={`https://wa.me/${String(dev.sellerPhone).replace(/\D/g, '')}`} className="font-semibold text-gray-700 dark:text-gray-300 flex items-center transition-colors hover:text-indigo-600" dir="ltr">
                                 <Phone className="w-3 h-3 mx-0.5"/>{dev.sellerPhone}
                               </a>
                             ) : <span className="text-gray-400">-</span>}
                           </div>
                           
                           <ArrowLeftRight className="w-3.5 h-3.5 text-gray-300 mx-1 shrink-0" />
                           
                           <div className="flex flex-col gap-0.5 text-left">
                             <span className="text-gray-400 text-right">{language === 'ar' ? 'المشتري:' : 'Buyer:'}</span>
                             {dev.buyerPhone ? (
                               <a onClick={e=>e.stopPropagation()} href={`https://wa.me/${String(dev.buyerPhone).replace(/\D/g, '')}`} className="font-semibold text-gray-700 dark:text-gray-300 flex items-center justify-end transition-colors hover:text-indigo-600" dir="ltr">
                                 {dev.buyerPhone}<Phone className="w-3 h-3 mx-0.5"/>
                               </a>
                             ) : <span className="text-gray-400 text-right">-</span>}
                           </div>
                        </div>
                      )}

                      {/* Pricing Footer */}
                      <div className="flex justify-between items-end pt-3 border-t border-gray-100 dark:border-gray-800/60">
                        <div className="flex gap-4">
                          <div className="text-right">
                            <p className="text-[10px] text-gray-500 mb-0.5">{language === 'ar' ? 'الشراء' : 'Buy'}</p>
                            <p className="text-xs font-bold text-gray-900 dark:text-gray-100">{formatBHD(dev.buyPrice)}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-[10px] text-gray-500 mb-0.5">{language === 'ar' ? 'البيع' : 'Sell'}</p>
                            <p className="text-xs font-bold text-gray-900 dark:text-gray-100">{formatBHD(dev.sellPrice || 0)}</p>
                          </div>
                        </div>
                        
                        <div className="text-left">
                          <p className="text-[10px] text-indigo-500/80 dark:text-indigo-400 mb-0.5 font-medium">{language === 'ar' ? 'الربح الصافي' : 'Net Profit'}</p>
                          <p className={`text-sm font-bold ${totalProfit >= 0 ? 'text-indigo-600 dark:text-indigo-400' : 'text-red-500'}`}>{formatBHD(totalProfit)}</p>
                        </div>
                      </div>
                    </motion.div>
                  );
                }"""

with open('src/views/Inventory.tsx', 'w') as f:
    f.write(content.replace(target, replacement))

print("Layout updated.")
