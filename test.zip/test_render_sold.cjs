const React = require('react');
const { renderToString } = require('react-dom/server');
require('ts-node').register({
  compilerOptions: { module: 'commonjs', jsx: 'react' }
});

const Inventory = require('./src/views/Inventory.tsx').default;
const StoreContext = require('./src/store').StoreContext;

const mockDevices = [
  {
    id: '1',
    status: 'sold',
    title: 'Test',
    buyPrice: 100,
    buyDate: '2023-01-01',
    sellPrice: 150,
    sellDate: '2023-02-01',
    buyerName: 'John',
    sellerPhone: '123456',
    buyerPhone: '123456',
    extras: [],
    soldExtras: []
  },
  {
    id: '2',
    status: 'sold',
    title: 'Test 2',
    buyPrice: 100,
    buyDate: '2023-01-01',
    buyerPhone: 123456 // Number type!
  }
];

const MockProvider = ({children}) => {
  return React.createElement(StoreContext.Provider, { 
    value: { devices: mockDevices, language: 'ar', deleteDevice: () => {} } 
  }, children);
};

try {
  renderToString(
    React.createElement(MockProvider, null, 
      React.createElement(Inventory, { onSellClick: () => {} })
    )
  );
  console.log("RENDER SUCCESS!");
} catch (e) {
  console.error("RENDER FAILED:", e);
}
