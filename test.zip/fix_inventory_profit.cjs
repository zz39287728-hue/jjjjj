const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

c = c.replace(/const profit = \(dev\.sellPrice \|\| 0\) - dev\.buyPrice;/, "const profit = (dev.sellPrice || 0) - dev.buyPrice - (dev.expenses?.reduce((sum, e) => sum + e.amount, 0) || 0);");

fs.writeFileSync('src/views/Inventory.tsx', c);
