import sys

with open('src/views/Inventory.tsx', 'r') as f:
    content = f.read()

target = """          <motion.div 
            className="space-y-4"
            initial="hidden"
            animate="visible"
            variants={{
              hidden: {},
              visible: { transition: { staggerChildren: 0.05 } }
            }}
          >"""

replacement = """          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
            initial="hidden"
            animate="visible"
            variants={{
              hidden: {},
              visible: { transition: { staggerChildren: 0.05 } }
            }}
          >"""

if target in content:
    with open('src/views/Inventory.tsx', 'w') as f:
        f.write(content.replace(target, replacement))
    print("Fixed Inventory grid")
else:
    print("Target not found")
