const fs = require('fs');
let types = fs.readFileSync('src/types.ts', 'utf8');
types = types.replace(/extraActions\?: ExtraAction\[\];/, "extraActions?: ExtraAction[];\n  loanAmount?: number;\n  loanLender?: string;\n  loanStatus?: 'unpaid' | 'paid';");
fs.writeFileSync('src/types.ts', types);

let bp = fs.readFileSync('firebase-blueprint.json', 'utf8');
const bpObj = JSON.parse(bp);
bpObj.entities.Device.properties.loanAmount = { type: "number" };
bpObj.entities.Device.properties.loanLender = { type: "string", maxLength: 100 };
bpObj.entities.Device.properties.loanStatus = { type: "string", enum: ["unpaid", "paid"] };
fs.writeFileSync('firebase-blueprint.json', JSON.stringify(bpObj, null, 2));

let rules = fs.readFileSync('firestore.rules', 'utf8');
rules = rules.replace(/&& \(!\('chatImage' in data\) \|\| \(data\.chatImage is string && data\.chatImage\.size\(\) <= 100000\)\);/, "&& (!('chatImage' in data) || (data.chatImage is string && data.chatImage.size() <= 100000))\n        && (!('loanAmount' in data) || (data.loanAmount is number))\n        && (!('loanLender' in data) || (data.loanLender is string && data.loanLender.size() <= 100))\n        && (!('loanStatus' in data) || (data.loanStatus == 'unpaid' || data.loanStatus == 'paid'));");
fs.writeFileSync('firestore.rules', rules);
