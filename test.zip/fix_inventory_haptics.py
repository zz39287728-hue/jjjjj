import sys

with open('src/views/Inventory.tsx', 'r') as f:
    content = f.read()

if "import { hapticFeedback }" not in content:
    content = content.replace("import { formatBHD, formatDate, translateExtra } from '../utils';", "import { formatBHD, formatDate, translateExtra, hapticFeedback } from '../utils';")

def r(target, rep):
    global content
    content = content.replace(target, rep)

# Use haptics for device deletion and clicking
r("onClick={(e) => { e.stopPropagation(); setDeviceToDelete(dev); }}", "onClick={(e) => { e.stopPropagation(); hapticFeedback('heavy'); setDeviceToDelete(dev); }}")
r("onClick={() => setSelectedDevice(dev)}", "onClick={() => { hapticFeedback('light'); setSelectedDevice(dev); }}")
r("onClick={() => setDeviceToSell(dev)}", "onClick={() => { hapticFeedback('medium'); setDeviceToSell(dev); }}")

r("onClick={() => setFilter('in-stock')}", "onClick={() => { hapticFeedback('light'); setFilter('in-stock'); }}")
r("onClick={() => setFilter('sold')}", "onClick={() => { hapticFeedback('light'); setFilter('sold'); }}")

# Fix motion variants for device cards for more bounce
r("""initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.2, delay: idx * 0.05 }}""", """initial={{ opacity: 0, y: 20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ type: 'spring', stiffness: 400, damping: 30, delay: idx * 0.05 }}
                    whileTap={{ scale: 0.98 }}""")

with open('src/views/Inventory.tsx', 'w') as f:
    f.write(content)

print("Added haptics and springs to Inventory.tsx")
