const fs = require('fs');

let c = fs.readFileSync('vite.config.ts', 'utf8');

if (!c.includes('vite-plugin-pwa')) {
  c = c.replace(/import \{defineConfig\} from 'vite';/, "import {defineConfig} from 'vite';\nimport { VitePWA } from 'vite-plugin-pwa';");
  
  const pwaConfig = `VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'icon.svg'],
      manifest: {
        id: '/',
        name: 'PS Inventory',
        short_name: 'PSInv',
        description: 'PlayStation Inventory App',
        theme_color: '#ffffff',
        background_color: '#ffffff',
        display: 'standalone',
        start_url: '/',
        scope: '/',
        icons: [
          {
            src: '/icon.png',
            sizes: '192x192',
            type: 'image/png',
            purpose: 'any',
          },
          {
            src: '/icon.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'any',
          },
          {
            src: '/icon.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable',
          }
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
        runtimeCaching: [
          {
            urlPattern: /^https:\\/\\/fonts\\.googleapis\\.com\\/.*/i,
            handler: 'CacheFirst',
            options: {
              cacheName: 'google-fonts-cache',
              expiration: { maxEntries: 10, maxAgeSeconds: 60 * 60 * 24 * 365 },
              cacheableResponse: { statuses: [0, 200] },
            },
          },
        ],
      },
      devOptions: {
        enabled: true,
        type: 'module',
      },
    })`;
    
  c = c.replace(/plugins: \[react\(\), tailwindcss\(\)\]/, "plugins: [react(), tailwindcss(), " + pwaConfig + "]");
  
  fs.writeFileSync('vite.config.ts', c);
  console.log("Updated vite.config.ts");
}
