const fs = require('fs');
let c = fs.readFileSync('src/App.tsx', 'utf8');

c = c.replace(/className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-800 pb-safe z-50"/g, 'className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 pb-safe z-50"');

c = c.replace(/className={`flex flex-col items-center py-3 px-6 rounded-2xl transition-all \$\{activeTab === tab.id \? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-gray-700' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'\}`\}/g, "className={`flex flex-col items-center py-3 px-6 rounded-2xl transition-all ${activeTab === tab.id ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`}");

fs.writeFileSync('src/App.tsx', c);
