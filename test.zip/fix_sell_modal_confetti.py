import sys

with open('src/components/SellModal.tsx', 'r') as f:
    content = f.read()

target = """    sellDevice(
      device.id, 
      parsedSellPrice, 
      sellDate, 
      toLatinDigits(buyerName).trim(), 
      toLatinDigits(buyerPhone).trim(), 
      toLatinDigits(buyerArea).trim(), 
      soldExtras, 
      sellMethod, 
      finalCash, 
      finalBenefit
    );

    onClose();"""

replacement = """    sellDevice(
      device.id, 
      parsedSellPrice, 
      sellDate, 
      toLatinDigits(buyerName).trim(), 
      toLatinDigits(buyerPhone).trim(), 
      toLatinDigits(buyerArea).trim(), 
      soldExtras, 
      sellMethod, 
      finalCash, 
      finalBenefit
    );

    hapticFeedback('celebration');
    
    // Celebrate!
    const duration = 2000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#4f46e5', '#a855f7', '#fbbf24']
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#4f46e5', '#a855f7', '#fbbf24']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    onClose();"""

if target in content:
    with open('src/components/SellModal.tsx', 'w') as f:
        f.write(content.replace(target, replacement))
    print("Added confetti and celebration to SellModal")
else:
    print("Target block not found in SellModal.tsx")
