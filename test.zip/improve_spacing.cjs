const fs = require('fs');

function updateFile(path, replacer) {
  if (fs.existsSync(path)) {
    let content = fs.readFileSync(path, 'utf8');
    const newContent = replacer(content);
    if (content !== newContent) {
      fs.writeFileSync(path, newContent);
      console.log(`Updated ${path}`);
    }
  }
}

// 1. Dashboard
updateFile('src/views/Dashboard.tsx', c => {
  return c
    .replace(/className="p-4 space-y-4"/g, 'className="p-5 sm:p-6 space-y-6 sm:space-y-8 max-w-5xl mx-auto"')
    .replace(/rounded-2xl p-5/g, 'rounded-3xl p-6 sm:p-8')
    .replace(/grid-cols-2 gap-4/g, 'grid-cols-2 gap-4 sm:gap-6')
    .replace(/p-4 rounded-2xl/g, 'p-5 sm:p-6 rounded-3xl')
    .replace(/mb-2/g, 'mb-3')
    .replace(/rounded-2xl shadow-sm border/g, 'rounded-3xl shadow-sm border')
    .replace(/className="p-4 border-b/g, 'className="p-5 sm:p-6 border-b')
    .replace(/className="p-4 flex flex-wrap/g, 'className="p-5 sm:p-6 flex flex-wrap')
    .replace(/className="p-0"/g, 'className="p-2 sm:p-4"')
    .replace(/justify-between p-4 border-b/g, 'justify-between p-4 sm:p-5 border-b')
    .replace(/className="p-8 text-center/g, 'className="p-10 sm:p-12 text-center');
});

// 2. Inventory
updateFile('src/views/Inventory.tsx', c => {
  return c
    .replace(/className="p-4 space-y-4"/g, 'className="p-5 sm:p-6 space-y-6 sm:space-y-8 max-w-5xl mx-auto"')
    .replace(/grid grid-cols-1 gap-3/g, 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6')
    .replace(/p-4 rounded-2xl/g, 'p-5 rounded-3xl')
    .replace(/space-y-3/g, 'space-y-4')
    .replace(/mb-3/g, 'mb-4')
    .replace(/mb-4/g, 'mb-6')
    .replace(/className="flex items-center gap-2 mt-3"/g, 'className="flex items-center gap-2 mt-5"')
    .replace(/className="flex items-center justify-between mt-3 pt-3/g, 'className="flex items-center justify-between mt-5 pt-4');
});

// 3. FormsView
updateFile('src/views/FormsView.tsx', c => {
  return c
    .replace(/className="p-4 space-y-4"/g, 'className="p-5 sm:p-6 space-y-6 sm:space-y-8 max-w-3xl mx-auto"')
    .replace(/p-4 rounded-2xl/g, 'p-6 sm:p-8 rounded-3xl')
    .replace(/space-y-4/g, 'space-y-6')
    .replace(/space-y-3/g, 'space-y-5');
});

// 4. SellModal
updateFile('src/components/SellModal.tsx', c => {
  return c
    .replace(/max-w-md rounded-t-2xl sm:rounded-2xl/g, 'max-w-lg rounded-t-3xl sm:rounded-3xl')
    .replace(/className="p-4 border-b/g, 'className="p-5 sm:p-6 border-b')
    .replace(/className="p-4 overflow-y-auto/g, 'className="p-5 sm:p-6 overflow-y-auto')
    .replace(/className="p-4 border-t/g, 'className="p-5 sm:p-6 border-t')
    .replace(/sm:rounded-b-2xl/g, 'sm:rounded-b-3xl')
    .replace(/space-y-4/g, 'space-y-6')
    .replace(/space-y-3/g, 'space-y-5')
    .replace(/my-4 pt-4/g, 'my-6 pt-6');
});

// 5. DeviceDetailsModal
updateFile('src/components/DeviceDetailsModal.tsx', c => {
  return c
    .replace(/max-w-md rounded-t-2xl sm:rounded-2xl/g, 'max-w-lg rounded-t-3xl sm:rounded-3xl')
    .replace(/className="p-4 border-b/g, 'className="p-5 sm:p-6 border-b')
    .replace(/className="p-4 overflow-y-auto/g, 'className="p-5 sm:p-6 overflow-y-auto')
    .replace(/className="p-4 border-t/g, 'className="p-5 sm:p-6 border-t')
    .replace(/sm:rounded-b-2xl/g, 'sm:rounded-b-3xl')
    .replace(/space-y-4/g, 'space-y-6')
    .replace(/space-y-3/g, 'space-y-5')
    .replace(/mb-3/g, 'mb-4')
    .replace(/mb-4/g, 'mb-6');
});

// 6. App (Main Layout)
updateFile('src/App.tsx', c => {
  return c
    .replace(/py-3 px-6/g, 'py-3.5 px-6') // Bottom nav buttons
    .replace(/className="fixed bottom-0/g, 'className="fixed bottom-0') // just a marker
});

