const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/import \{ Device, Expense \} from '\.\.\/types';/, "import { Device, Expense, ExtraAction } from '../types';");

c = c.replace(/const \[expenses, setExpenses\] = useState<Expense\[\]>\(device\.expenses \|\| \[\]\);/, "const [expenses, setExpenses] = useState<Expense[]>(device.expenses || []);\n  const [extraActions, setExtraActions] = useState<ExtraAction[]>(device.extraActions || []);");

const savePayload = `      area,
      sellerName,
      sellerPhone,
      expenses,
      extraActions,`;

c = c.replace(/area,\n\s*sellerName,\n\s*sellerPhone,\n\s*expenses,/, savePayload);

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
