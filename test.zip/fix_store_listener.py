import sys

with open('src/store.tsx', 'r') as f:
    content = f.read()

listener_code = """  useEffect(() => {
    const handleAppError = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        logError(customEvent.detail.code || 'UNKNOWN_ERROR', customEvent.detail.message || 'Unknown error occurred', customEvent.detail.details);
      }
    };
    
    const handleGlobalError = (e: ErrorEvent) => {
      logError('GLOBAL_ERROR', e.message, e.filename + ':' + e.lineno);
    };

    const handleUnhandledRejection = (e: PromiseRejectionEvent) => {
      logError('UNHANDLED_REJECTION', e.reason?.message || String(e.reason), JSON.stringify(e.reason));
    };

    window.addEventListener('app-error', handleAppError);
    window.addEventListener('error', handleGlobalError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    return () => {
      window.removeEventListener('app-error', handleAppError);
      window.removeEventListener('error', handleGlobalError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, []);
"""

if "window.addEventListener('app-error', handleAppError);" not in content:
    content = content.replace("  const clearErrors = () => {", listener_code + "\n  const clearErrors = () => {")
    with open('src/store.tsx', 'w') as f:
        f.write(content)
    print("Added global error listeners in store")
