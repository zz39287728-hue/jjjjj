const fs = require('fs');

let c = fs.readFileSync('src/components/SettingsModal.tsx', 'utf8');

// The bottom is broken: `</motion.div>\n    </motion.div>\n  );`
// Let's restore the bottoms first
c = c.replace(/<\/motion\.div>\s*<\/motion\.div>/, '</div>\n    </div>');

// Now we want to use motion!
c = c.replace(/<div className="absolute inset-0 z-\[60\] flex items-end justify-center sm:items-center bg-black\/40 backdrop-blur-sm sm:p-4 pointer-events-auto">/, '<motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[60] flex items-end justify-center sm:items-center bg-black/40 backdrop-blur-sm sm:p-4 pointer-events-auto">');

c = c.replace(/<div \n        className="w-full sm:w-\[400px\] h-\[85vh\] sm:h-auto sm:max-h-\[85vh\] bg-gray-50 dark:bg-gray-900 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col animate-in slide-in-from-bottom-full sm:zoom-in-95 duration-300"\n      >/, '<motion.div initial={{ y: 50, scale: 0.95 }} animate={{ y: 0, scale: 1 }} exit={{ y: 50, scale: 0.95 }} className="w-full sm:w-[400px] h-[85vh] sm:h-auto sm:max-h-[85vh] bg-gray-50 dark:bg-gray-900 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col">');

c = c.replace(/<\/div>\n    <\/div>/, '</motion.div>\n    </motion.div>');

fs.writeFileSync('src/components/SettingsModal.tsx', c);
console.log("Fixed SettingsModal");
