const fs = require('fs');
let c = fs.readFileSync('src/i18n.ts', 'utf8');

c = c.replace("extra_notes: 'Notes (e.g. gifted to brother)',", "extra_notes: 'Notes (e.g. gifted to brother)',\n    extra_notes_kept: 'Notes',");
c = c.replace("extra_notes: 'ملاحظات (مثال: هدية لأخي)',", "extra_notes: 'ملاحظات (مثال: هدية لأخي)',\n    extra_notes_kept: 'ملاحظات',");

fs.writeFileSync('src/i18n.ts', c);
