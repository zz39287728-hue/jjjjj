const fs = require('fs');
let c = fs.readFileSync('src/utils.ts', 'utf8');

c = c.replace(/return new Intl\.NumberFormat\('en-BH', \{ \n    style: 'currency', \n    currency: 'BHD',\n    maximumFractionDigits: 3 \n  \}\)\.format\(amount\);/, 
  "const formatted = new Intl.NumberFormat('en-BH', { \n    style: 'currency', \n    currency: 'BHD',\n    maximumFractionDigits: 3 \n  }).format(amount);\n  return formatted.replace('BHD', 'BD').trim();");

fs.writeFileSync('src/utils.ts', c);
