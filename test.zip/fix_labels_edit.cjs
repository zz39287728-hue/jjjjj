const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/<h3 className="font-bold text-gray-900 dark:text-gray-100 border-b border-gray-100 dark:border-gray-800 pb-2 mb-6">المعلومات الأساسية والشراء<\/h3>/g, 
              '<h3 className="font-bold text-gray-900 dark:text-gray-100 border-b border-gray-100 dark:border-gray-800 pb-2 mb-6">{isSold ? "المعلومات الأساسية ومعلومات البائع" : "المعلومات الأساسية والشراء (من البائع)"}</h3>');

c = c.replace(/<h3 className="font-bold text-gray-900 dark:text-gray-100 border-b border-gray-100 dark:border-gray-800 pb-2 mb-6">معلومات البيع<\/h3>/g, 
              '<h3 className="font-bold text-gray-900 dark:text-gray-100 border-b border-gray-100 dark:border-gray-800 pb-2 mb-6">معلومات المشتري</h3>');

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
