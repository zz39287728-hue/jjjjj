const fs = require('fs');
let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

if (!c.includes('motion')) {
  c = c.replace(/import \{ t \} from '\.\.\/i18n';/, "import { t } from '../i18n';\nimport { motion } from 'motion/react';");
  
  // Animate the main top card (Total Profit)
  c = c.replace(/<div className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">/g, 
    '<motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} whileTap={{ scale: 0.98 }} className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">');
  c = c.replace(/<\/h2>\s*<\/div>\s*<\/div>/, '</h2>\n      </div>\n    </motion.div>');

  // Animate Inventory Value & Total Sales cards
  c = c.replace(/<div className="bg-white dark:bg-gray-800 rounded-3xl p-5 sm:p-6 shadow-sm border border-gray-200 dark:border-gray-700">/g, 
    '<motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} whileTap={{ scale: 0.98 }} className="bg-white dark:bg-gray-800 rounded-3xl p-5 sm:p-6 shadow-sm border border-gray-200 dark:border-gray-700">');
  c = c.replace(/<p className="text-xs text-gray-500 dark:text-gray-400 mt-1">\{inStockDevices\.length\} In Stock Devices<\/p>\s*<\/div>/, '<p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{inStockDevices.length} In Stock Devices</p>\n        </motion.div>');
  c = c.replace(/<p className="text-xs text-gray-500 dark:text-gray-400 mt-1">\{soldDevices\.length\} Sold Devices<\/p>\s*<\/div>/, '<p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{soldDevices.length} Sold Devices</p>\n        </motion.div>');

  // Animate Total Debt card
  c = c.replace(/<div className="bg-white dark:bg-gray-800 rounded-3xl p-5 sm:p-6 shadow-sm border border-gray-200 dark:border-gray-700 col-span-2">/g, 
    '<motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} whileTap={{ scale: 0.98 }} className="bg-white dark:bg-gray-800 rounded-3xl p-5 sm:p-6 shadow-sm border border-gray-200 dark:border-gray-700 col-span-2">');
  c = c.replace(/<\/p>\s*<\/div>\s*<\/div>\s*<\/div>/, '</p>\n            </div>\n          </div>\n        </motion.div>');

  // Animate the list items (transactions)
  // Need to replace the div with key={tx.id}
  c = c.replace(/<div key=\{tx\.id\} className="flex items-center justify-between p-4 sm:p-5 border-b border-gray-50 dark:border-gray-800 last:border-0">/g,
    '<motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 * index }} key={tx.id} className="flex items-center justify-between p-4 sm:p-5 border-b border-gray-50 dark:border-gray-800 last:border-0">');
  
  // Need to add index to the map function!
  c = c.replace(/\{filteredTransactions\.slice\(0, 10\)\.map\(tx => \(/g, "{filteredTransactions.slice(0, 10).map((tx, index) => (");

  // Close motion.div
  c = c.replace(/<\/p>\n                \)\}\n              <\/div>\n            <\/div>/g, '</p>\n                )}\n              </div>\n            </motion.div>');

  fs.writeFileSync('src/views/Dashboard.tsx', c);
  console.log("Updated Dashboard");
}
