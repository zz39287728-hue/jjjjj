import sys

with open('vite.config.ts', 'r') as f:
    content = f.read()

# We need to add maximumFileSizeToCacheInBytes: 5000000 to the workbox config
target = "workbox: {"
replacement = "workbox: {\n        maximumFileSizeToCacheInBytes: 10000000,"

if target in content:
    with open('vite.config.ts', 'w') as f:
        f.write(content.replace(target, replacement))
    print("Fixed vite config workbox limit")
else:
    print("workbox block not found, looking for another place to add it")
    
