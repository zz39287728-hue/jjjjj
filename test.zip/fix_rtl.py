import sys

with open('src/views/Inventory.tsx', 'r') as f:
    content = f.read()

target = """                      <div className="flex justify-between items-start gap-2">
                        <div className="flex items-start gap-1 shrink-0">
                          <button 
                            onClick={(e) => { e.stopPropagation(); setDeviceToDelete(dev); }} 
                            className="p-1 text-gray-400 dark:text-gray-500 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <div className="text-[10px] text-gray-400 leading-tight pt-1 text-left" dir="ltr">
                            <div>{formatDate(dev.buyDate)}</div>
                            {dev.sellDate && <div>{formatDate(dev.sellDate)}</div>}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0 text-right">
                          <h3 className="font-bold text-gray-900 dark:text-gray-100 truncate text-sm">{dev.title || dev.model}</h3>
                          <p className="text-[10px] text-gray-500 truncate">{dev.model}</p>
                        </div>
                      </div>"""

replacement = """                      <div className="flex justify-between items-start gap-2">
                        <div className="flex-1 min-w-0 text-right">
                          <h3 className="font-bold text-gray-900 dark:text-gray-100 truncate text-sm">{dev.title || dev.model}</h3>
                          <p className="text-[10px] text-gray-500 truncate">{dev.model}</p>
                        </div>
                        <div className="flex items-start gap-1 shrink-0">
                          <div className="text-[9px] text-gray-400 leading-tight pt-1 text-right" dir="ltr">
                            <div>{formatDate(dev.buyDate)}</div>
                            {dev.sellDate && <div>{formatDate(dev.sellDate)}</div>}
                          </div>
                          <button 
                            onClick={(e) => { e.stopPropagation(); setDeviceToDelete(dev); }} 
                            className="p-1 text-gray-400 dark:text-gray-500 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>"""

if target in content:
    with open('src/views/Inventory.tsx', 'w') as f:
        f.write(content.replace(target, replacement))
    print("Fixed RTL")
else:
    print("Target not found")
