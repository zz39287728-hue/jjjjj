import sys

with open('src/views/GeneralDebtForm.tsx', 'r') as f:
    content = f.read()

def r(target, rep):
    global content
    content = content.replace(target, rep)

r(">نظام الديون والقروض<", ">{language === 'ar' ? 'نظام الديون والقروض' : 'Debts and Loans System'}<")
r(">المبلغ (د.ب)<", ">{language === 'ar' ? 'المبلغ (د.ب)' : 'Amount (BHD)'}<")
r(">التاريخ<", ">{language === 'ar' ? 'التاريخ' : 'Date'}<")
r(">الطرف الآخر<", ">{language === 'ar' ? 'الطرف الآخر' : 'Other Party'}<")
r(">شخص آخر<", ">{language === 'ar' ? 'شخص آخر' : 'Someone else'}<")
r('placeholder="اسم الشخص"', 'placeholder={language === "ar" ? "اسم الشخص" : "Person Name"}')
r(">نوع الدين<", ">{language === 'ar' ? 'نوع الدين' : 'Debt Type'}<")
r(">اقترضت منه (عليّ دين)<", ">{language === 'ar' ? 'اقترضت منه (عليّ دين)' : 'Borrowed (I owe)'}<")
r(">أقرضته (لي دين)<", ">{language === 'ar' ? 'أقرضته (لي دين)' : 'Lent (They owe me)'}<")
r(">ملاحظات (اختياري)<", ">{language === 'ar' ? 'ملاحظات (اختياري)' : 'Notes (Optional)'}<")
r(">حفظ الدين<", ">{language === 'ar' ? 'حفظ الدين' : 'Save Debt'}<")

# handle lenders dropdown
old_lenders_map = """            {lenders.map(l => (
              <option key={l} value={l}>{l}</option>
            ))}"""
new_lenders_map = """            {lenders.map(l => {
              const display = language === 'en' ? (
                l === 'حسابي الشخصي' ? 'My Personal Account' :
                l === 'أخي عباس' ? 'My Brother Abbas' :
                l === 'أخي حسين' ? 'My Brother Hussain' :
                l === 'الوالدة' ? 'Mother' :
                l === 'الوالد' ? 'Father' :
                l === 'علي' ? 'Ali' :
                l === 'أم حمود' ? 'Om Hamood' :
                l === 'أم حسين' ? 'Om Hussain' : l
              ) : l;
              return <option key={l} value={l}>{display}</option>;
            })}"""
r(old_lenders_map, new_lenders_map)

with open('src/views/GeneralDebtForm.tsx', 'w') as f:
    f.write(content)

print("GeneralDebtForm language updated.")
