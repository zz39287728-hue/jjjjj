const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

c = c.replace(/\{dev\.sellPrice && \(\(\) => \{/g, "{dev.sellPrice ? (() => {");
c = c.replace(/                          \);\n                        \}\)\(\)\}/g, "                          );\n                        })() : null}");

fs.writeFileSync('src/views/Inventory.tsx', c);
