const fs = require('fs');
let c = fs.readFileSync('src/components/SettingsModal.tsx', 'utf8');

if (!c.includes('activeWorkspaceId')) {
  // imports
  if (!c.includes('Users')) {
    c = c.replace(/import \{ X, Languages, Moon, Sun, Download, Upload, MonitorSmartphone, Database \} from 'lucide-react';/,
      "import { X, Languages, Moon, Sun, Download, Upload, MonitorSmartphone, Database, Users, Share2, LogIn, LogOut } from 'lucide-react';");
  }

  // extract variables
  c = c.replace(/const \{ language, setLanguage, theme, setTheme, devices, importDevices \} = useStore\(\);/,
    "const { language, setLanguage, theme, setTheme, devices, importDevices, activeWorkspaceId, generateInviteCode, joinWorkspace, clearWorkspace } = useStore();\n  const [inviteLink, setInviteLink] = React.useState('');\n  const [joinLink, setJoinLink] = React.useState('');");

  // share ui
  const shareUI = `
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
              <Users className="w-4 h-4" />
              {language === 'ar' ? 'مشاركة مساحة العمل' : 'Workspace Sharing'}
            </h3>
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col gap-4">
              
              {activeWorkspaceId && activeWorkspaceId !== user?.uid ? (
                <div className="flex flex-col gap-3">
                  <div className="p-3 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl text-indigo-800 dark:text-indigo-200 text-sm">
                    {language === 'ar' ? 'أنت متصل بمساحة عمل مشتركة.' : 'You are connected to a shared workspace.'}
                  </div>
                  <button 
                    onClick={() => clearWorkspace()}
                    className="flex items-center justify-center gap-2 p-3 bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-400 hover:bg-red-200 transition-colors rounded-xl font-medium"
                  >
                    <LogOut className="w-4 h-4" />
                    {language === 'ar' ? 'الخروج من مساحة العمل' : 'Leave Workspace'}
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col gap-2">
                    <button 
                      onClick={async () => {
                        const code = await generateInviteCode();
                        if (code) {
                          const link = \`\${window.location.origin}?invite=\${user?.uid}&code=\${code}\`;
                          setInviteLink(link);
                        }
                      }}
                      className="flex items-center justify-center gap-2 p-3 bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-400 hover:bg-indigo-200 transition-colors rounded-xl font-medium"
                    >
                      <Share2 className="w-4 h-4" />
                      {language === 'ar' ? 'إنشاء رابط دعوة' : 'Generate Invite Link'}
                    </button>
                    {inviteLink && (
                      <div className="flex flex-col gap-2">
                        <input type="text" readOnly value={inviteLink} className="w-full p-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg text-sm text-gray-600 dark:text-gray-400" />
                        <button onClick={() => { navigator.clipboard.writeText(inviteLink); alert(language === 'ar' ? 'تم النسخ!' : 'Copied!'); }} className="text-xs text-indigo-600 dark:text-indigo-400 font-medium self-end">
                          {language === 'ar' ? 'نسخ الرابط' : 'Copy Link'}
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="h-px bg-gray-100 dark:bg-gray-700" />

                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {language === 'ar' ? 'لصق رابط دعوة للإنضمام' : 'Paste invite link to join'}
                    </label>
                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        value={joinLink} 
                        onChange={e => setJoinLink(e.target.value)}
                        placeholder="https://..." 
                        className="flex-1 p-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg text-sm text-gray-900 dark:text-gray-100" 
                      />
                      <button 
                        onClick={async () => {
                          try {
                            const url = new URL(joinLink);
                            const invite = url.searchParams.get('invite');
                            const code = url.searchParams.get('code');
                            if (invite && code) {
                              const success = await joinWorkspace(invite, code);
                              if (success) {
                                alert(language === 'ar' ? 'تم الانضمام بنجاح!' : 'Joined successfully!');
                              } else {
                                alert(language === 'ar' ? 'فشل الانضمام. تأكد من الرابط.' : 'Failed to join. Check the link.');
                              }
                            } else {
                              alert(language === 'ar' ? 'رابط غير صالح' : 'Invalid link');
                            }
                          } catch (e) {
                            alert(language === 'ar' ? 'رابط غير صالح' : 'Invalid link');
                          }
                        }}
                        className="px-3 py-2 bg-gray-900 dark:bg-gray-700 text-white rounded-lg text-sm font-medium"
                      >
                        {language === 'ar' ? 'انضمام' : 'Join'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </div>
          </div>
`;
  
  c = c.replace(/          <div className="space-y-3">\n            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">\n              <Database className="w-4 h-4" \/>\n              \{language === 'ar' \? 'الحساب' : 'Account'\}/, shareUI + "\n          <div className=\"space-y-3\">\n            <h3 className=\"text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2\">\n              <Database className=\"w-4 h-4\" />\n              {language === 'ar' ? 'الحساب' : 'Account'}");

  fs.writeFileSync('src/components/SettingsModal.tsx', c);
  console.log("Updated SettingsModal");
}
