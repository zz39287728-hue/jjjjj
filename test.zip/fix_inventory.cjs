const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

// The issue is likely that `document.getElementById('modal-root')` returns null
// during the very first render, and since it doesn't trigger a re-render when the DOM node is created,
// the createPortal condition will always be false unless it happens on a later render. 
// However, since App mounts `modal-root` after `Inventory`, when the user clicks a device, `modal-root` exists.

// Let's remove the `&& document.getElementById('modal-root')` check and rely on a state or simply not check it (as it should exist after initial render)
// Actually, `document.getElementById('modal-root')` WILL exist when `selectedDevice` is true, 
// because `selectedDevice` is only set by onClick, which means the DOM is already fully mounted!

// Let's replace `document.getElementById('modal-root')` with `document.body` just to see if it fixes it. Or just rely on it without the check if it causes issues.
// But wait! If `deviceToDelete` doesn't work either, maybe the issue is that it's behind another layer?
// No, the user said they cannot see the details when they click.
// Let's remove the createPortal and just render it normally inside AnimatePresence with absolute positioning to fix the problem completely.

const modalRender = `      <AnimatePresence>
        {selectedDevice && (
          <ErrorBoundary>
            <DeviceDetailsModal 
              device={selectedDevice} 
              onClose={() => setSelectedDevice(null)} 
              onImageClick={(img) => setViewingImage(img)}
            />
          </ErrorBoundary>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deviceToDelete && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 pointer-events-auto"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              className="bg-white dark:bg-gray-800 rounded-2xl p-6 w-full max-w-sm shadow-2xl"
            >
              <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">حذف الجهاز</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6 text-sm">هل أنت متأكد من أنك تريد أن تحذف هذه العملية؟</p>
              <div className="flex space-x-3 space-x-reverse">
                <button 
                  onClick={() => setDeviceToDelete(null)}
                  className="flex-1 py-2.5 rounded-xl font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  إلغاء
                </button>
                <button 
                  onClick={() => {
                    deleteDevice(deviceToDelete.id);
                    setDeviceToDelete(null);
                  }}
                  className="flex-1 py-2.5 rounded-xl font-medium text-white bg-red-600 hover:bg-red-700 transition-colors shadow-sm shadow-red-200 dark:shadow-none"
                >
                  حذف
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>`;

c = c.replace(/      <AnimatePresence>\n        \{selectedDevice && document\.getElementById\('modal-root'\) && createPortal\([\s\S]*?        \)\}\n      <\/AnimatePresence>\n\n      <AnimatePresence>\n        \{deviceToDelete && document\.getElementById\('modal-root'\) && createPortal\([\s\S]*?        \)\}\n      <\/AnimatePresence>/, modalRender);

fs.writeFileSync('src/views/Inventory.tsx', c);
