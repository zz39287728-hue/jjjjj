const fs = require('fs');

let rules = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if false;
    }

    function isSignedIn() {
      return request.auth != null;
    }
    
    function incoming() {
      return request.resource.data;
    }
    
    function existing() {
      return resource.data;
    }
    
    function isValidId(id) {
      return id is string && id.size() <= 128 && id.matches('^[a-zA-Z0-9_\\\\-]+$');
    }

    function isWorkspaceMember(workspaceId) {
      return exists(/databases/$(database)/documents/workspaces/$(workspaceId)/members/$(request.auth.uid));
    }
    
    function canAccessWorkspace(workspaceId) {
      return workspaceId == request.auth.uid || isWorkspaceMember(workspaceId);
    }

    match /workspaces/{workspaceId} {
      allow read: if isSignedIn() && canAccessWorkspace(workspaceId);
      allow create, update: if isSignedIn() 
        && workspaceId == request.auth.uid
        && incoming().keys().hasAny(['inviteCode', 'updatedAt'])
        && (!('inviteCode' in incoming()) || (incoming().inviteCode is string && incoming().inviteCode.size() <= 50))
        && (!('updatedAt' in incoming()) || incoming().updatedAt is number);
      
      match /members/{memberId} {
        allow read: if isSignedIn() && (canAccessWorkspace(workspaceId) || memberId == request.auth.uid);
        allow create: if isSignedIn() 
          && memberId == request.auth.uid 
          && incoming().inviteCode == get(/databases/$(database)/documents/workspaces/$(workspaceId)).data.inviteCode
          && incoming().keys().hasAll(['inviteCode', 'joinedAt'])
          && incoming().keys().size() == 2
          && incoming().inviteCode is string && incoming().inviteCode.size() <= 50
          && incoming().joinedAt is number;
        allow delete: if isSignedIn() && (workspaceId == request.auth.uid || memberId == request.auth.uid);
      }
    }

    function isValidDevice(data) {
      return data.keys().hasAll(['id', 'userId', 'model', 'buyPrice', 'buyDate', 'status'])
        && data.id is string && data.id.size() <= 128
        && data.userId is string && data.userId.size() <= 128
        && canAccessWorkspace(data.userId)
        && data.model is string && data.model.size() <= 100
        && data.buyPrice is number
        && data.buyDate is string && data.buyDate.size() <= 50
        && (data.status == 'in_stock' || data.status == 'sold')
        && (!('sellPrice' in data) || data.sellPrice is number)
        && (!('sellDate' in data) || (data.sellDate is string && data.sellDate.size() <= 50))
        && (!('notes' in data) || (data.notes is string && data.notes.size() <= 2000))
        && (!('sellerName' in data) || (data.sellerName is string && data.sellerName.size() <= 100))
        && (!('sellerPhone' in data) || (data.sellerPhone is string && data.sellerPhone.size() <= 100))
        && (!('title' in data) || (data.title is string && data.title.size() <= 200))
        && (!('area' in data) || (data.area is string && data.area.size() <= 100))
        && (!('buyerName' in data) || (data.buyerName is string && data.buyerName.size() <= 100))
        && (!('buyerPhone' in data) || (data.buyerPhone is string && data.buyerPhone.size() <= 100))
        && (!('buyerArea' in data) || (data.buyerArea is string && data.buyerArea.size() <= 100))
        && (!('extras' in data) || (data.extras is list && data.extras.size() <= 50))
        && (!('soldExtras' in data) || (data.soldExtras is list && data.soldExtras.size() <= 50))
        && (!('expenses' in data) || (data.expenses is list && data.expenses.size() <= 50))
        && (!('extraActions' in data) || (data.extraActions is list && data.extraActions.size() <= 50))
        && (!('chatImage' in data) || (data.chatImage is string && data.chatImage.size() <= 100000))
        && (!('loanAmount' in data) || (data.loanAmount is number))
        && (!('loanLender' in data) || (data.loanLender is string && data.loanLender.size() <= 100))
        && (!('loanStatus' in data) || (data.loanStatus == 'unpaid' || data.loanStatus == 'paid'))
        && (!('sellMethod' in data) || (data.sellMethod is string && data.sellMethod.size() <= 20))
        && (!('cashAmount' in data) || data.cashAmount is number)
        && (!('benefitAmount' in data) || data.benefitAmount is number)
        && (!('createdAt' in data) || data.createdAt is number)
        && (!('updatedAt' in data) || data.updatedAt is number);
    }

    match /devices/{deviceId} {
      allow read: if isSignedIn() && canAccessWorkspace(existing().userId);
      allow list: if isSignedIn() && canAccessWorkspace(resource.data.userId);
      
      allow create: if isSignedIn() 
        && isValidId(deviceId) 
        && isValidDevice(incoming());
        
      allow update: if isSignedIn() 
        && isValidId(deviceId)
        && canAccessWorkspace(existing().userId)
        && incoming().userId == existing().userId
        && isValidDevice(incoming());
        
      allow delete: if isSignedIn() 
        && isValidId(deviceId)
        && canAccessWorkspace(existing().userId);
    }

    function isValidGeneralExpense(data) {
      return data.keys().hasAll(['id', 'userId', 'amount', 'date', 'title', 'createdAt', 'updatedAt'])
        && data.id is string && data.id.size() <= 128
        && data.userId is string && data.userId.size() <= 128
        && canAccessWorkspace(data.userId)
        && data.amount is number
        && data.date is string && data.date.size() <= 50
        && data.title is string && data.title.size() <= 200
        && (!('notes' in data) || (data.notes is string && data.notes.size() <= 2000))
        && data.createdAt is number
        && data.updatedAt is number;
    }

    function isValidGeneralDebt(data) {
      return data.keys().hasAll(['id', 'userId', 'amount', 'date', 'personName', 'type', 'status', 'createdAt', 'updatedAt'])
        && data.id is string && data.id.size() <= 128
        && data.userId is string && data.userId.size() <= 128
        && canAccessWorkspace(data.userId)
        && data.amount is number
        && data.date is string && data.date.size() <= 50
        && data.personName is string && data.personName.size() <= 100
        && (data.type == 'borrowed' || data.type == 'lent')
        && (data.status == 'unpaid' || data.status == 'paid')
        && (!('notes' in data) || (data.notes is string && data.notes.size() <= 2000))
        && data.createdAt is number
        && data.updatedAt is number;
    }

    match /generalExpenses/{expenseId} {
      allow read: if isSignedIn() && canAccessWorkspace(existing().userId);
      allow list: if isSignedIn() && canAccessWorkspace(resource.data.userId);
      
      allow create: if isSignedIn() 
        && isValidId(expenseId)
        && isValidGeneralExpense(incoming());
        
      allow update: if isSignedIn() 
        && isValidId(expenseId)
        && canAccessWorkspace(existing().userId)
        && incoming().userId == existing().userId
        && isValidGeneralExpense(incoming());
        
      allow delete: if isSignedIn() 
        && isValidId(expenseId)
        && canAccessWorkspace(existing().userId);
    }

    match /generalDebts/{debtId} {
      allow read: if isSignedIn() && canAccessWorkspace(existing().userId);
      allow list: if isSignedIn() && canAccessWorkspace(resource.data.userId);
      
      allow create: if isSignedIn() 
        && isValidId(debtId)
        && isValidGeneralDebt(incoming());
        
      allow update: if isSignedIn() 
        && isValidId(debtId)
        && canAccessWorkspace(existing().userId)
        && incoming().userId == existing().userId
        && isValidGeneralDebt(incoming());
        
      allow delete: if isSignedIn() 
        && isValidId(debtId)
        && canAccessWorkspace(existing().userId);
    }
  }
}
`;

fs.writeFileSync('firestore.rules', rules);
