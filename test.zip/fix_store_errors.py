import sys

with open('src/store.tsx', 'r') as f:
    content = f.read()

# Add AppError import
if "import { Device, GeneralExpense, GeneralDebt, AppError }" not in content:
    content = content.replace("import { Device, GeneralExpense, GeneralDebt } from './types';", "import { Device, GeneralExpense, GeneralDebt, AppError } from './types';")

# Add to StoreContextType
if "errors: AppError[];" not in content:
    content = content.replace("  clearWorkspace: () => void;\n}", "  clearWorkspace: () => void;\n  errors: AppError[];\n  logError: (code: string, message: string, details?: string) => void;\n  clearErrors: () => void;\n}")

# Add state to StoreProvider
if "const [errors, setErrors] = useState<AppError[]>(" not in content:
    state_code = """  const [errors, setErrors] = useState<AppError[]>(() => {
    try {
      const stored = localStorage.getItem('ps_errors');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const logError = (code: string, message: string, details?: string) => {
    setErrors(prev => {
      const newErrors = [{
        id: Math.random().toString(36).substr(2, 9),
        code,
        message,
        timestamp: new Date().toISOString(),
        details,
        path: window.location.pathname
      }, ...prev].slice(0, 50); // Keep last 50
      localStorage.setItem('ps_errors', JSON.stringify(newErrors));
      
      // Also show a toast/alert or dispatch event
      window.dispatchEvent(new CustomEvent('app-error', { detail: { code, message } }));
      
      return newErrors;
    });
  };

  const clearErrors = () => {
    setErrors([]);
    localStorage.removeItem('ps_errors');
  };
"""
    content = content.replace("  const [activeWorkspaceId, setActiveWorkspaceIdState] = useState<string>(() => {", state_code + "\n  const [activeWorkspaceId, setActiveWorkspaceIdState] = useState<string>(() => {")

# Add to context value
if "errors,\n    logError,\n    clearErrors," not in content:
    content = content.replace("    clearWorkspace\n  }}", "    clearWorkspace,\n    errors,\n    logError,\n    clearErrors\n  }}")
    content = content.replace("    clearWorkspace,\n  }}", "    clearWorkspace,\n    errors,\n    logError,\n    clearErrors\n  }}") # Just in case

# Override handleFirestoreError calls to also log
import re
# We need to find places where we catch errors and log them.
# The store has handleFirestoreError calls, let's see where they are.
# Wait, handleFirestoreError inside store.tsx already throws or shows alert?
# Let's inspect firebase.ts to see what handleFirestoreError does.

with open('src/store.tsx', 'w') as f:
    f.write(content)
print("Updated store with errors")
