const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

c = c.replace(/placeholder=\{actionObj.action === 'gifted' \? t\('extra_notes', language\) : \(language === 'ar' \? 'ملاحظات' : 'Notes'\)\}/, "placeholder={actionObj.action === 'gifted' ? t('extra_notes', language) : t('extra_notes_kept', language)}");

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
