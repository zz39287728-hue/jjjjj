const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

c = c.replace(/const devs = snapshot\.docs\.map\(doc => doc\.data\(\) as Device\);/, "const devs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Device);");

fs.writeFileSync('src/store.tsx', c);
