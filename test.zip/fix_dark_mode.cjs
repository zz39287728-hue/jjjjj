const fs = require('fs');
const path = require('path');

function replaceInFile(filePath) {
  let content = fs.readFileSync(filePath, 'utf8');
  let originalContent = content;
  
  // Replace duplicate dark:text-gray-900 that comes after dark:text-gray-100
  content = content.replace(/dark:text-gray-100 dark:text-gray-900/g, 'dark:text-gray-100');
  
  // Replace any standalone dark:text-gray-900 that should probably be dark:text-gray-100
  // when paired with text-gray-900
  content = content.replace(/text-gray-900 dark:text-gray-900/g, 'text-gray-900 dark:text-gray-100');
  
  // Replace text-gray-500 duplicate classes
  content = content.replace(/dark:text-gray-400 dark:text-gray-500/g, 'dark:text-gray-400');
  
  if (content !== originalContent) {
    fs.writeFileSync(filePath, content);
    console.log(`Updated ${filePath}`);
  }
}

function walkDir(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      walkDir(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      replaceInFile(fullPath);
    }
  }
}

walkDir('./src');
