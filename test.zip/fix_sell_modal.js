const fs = require('fs');
const file = 'src/components/SellModal.tsx';
let code = fs.readFileSync(file, 'utf8');

// 1. Remove the duplicated if (isSold) block inside the extras map
const startStr = "                      if (isSold) {";
const endStr = "    );\n  }\n  return (";

const startIndex = code.indexOf(startStr);
if (startIndex !== -1) {
    const endIndex = code.indexOf(endStr, startIndex);
    if (endIndex !== -1) {
        code = code.substring(0, startIndex) + code.substring(endIndex + 14); // 14 is length of "    );\n  }\n  "
    }
}

// 2. Fix the first if (isSold) block to ensure video has 'muted' and overlay behaves correctly
code = code.replace(
    /className="absolute inset-0 bg-black"\s*\/>\s*\{\!liteMode && \(\s*<video \s*src=\{randomVideo\}\s*autoPlay \s*playsInline\s*loop\s*className="absolute inset-0 w-full h-full object-cover z-0 opacity-80"\s*\/>/g,
    `className="absolute inset-0 bg-black"
        />
        {!liteMode && (
          <video 
            src={randomVideo}
            autoPlay 
            playsInline
            muted
            loop
            className="absolute inset-0 w-full h-full object-cover z-0 opacity-80"
          />`
);

// 3. Fix the setTimeout in handleSubmit to close the modal after celebration
code = code.replace(
    /setTimeout\(\(\) => \{\s*setShowOverlay\(false\);\s*\}, 5000\);/g,
    `setTimeout(() => {\n      onClose();\n    }, 5000);`
);

fs.writeFileSync(file, code);
console.log('Fixed SellModal.tsx');
