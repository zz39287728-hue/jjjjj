const fs = require('fs');
let c = fs.readFileSync('src/components/SellModal.tsx', 'utf8');

c = c.replace(/const currentProfit = sellPrice \? parseFloat\(sellPrice\) - device\.buyPrice : 0;/, "const currentProfit = sellPrice ? parseFloat(sellPrice) - device.buyPrice - expenses.reduce((sum, e) => sum + e.amount, 0) : 0;");

fs.writeFileSync('src/components/SellModal.tsx', c);
