const fs = require('fs');
let c = fs.readFileSync('src/App.tsx', 'utf8');
c = c.replace(/className="flex-1 overflow-y-auto pb-32 relative bg-gray-50\/50 dark:bg-gray-900\/50 transition-colors"/, 'className="flex-1 overflow-y-auto pb-[50vh] relative bg-gray-50/50 dark:bg-gray-900/50 transition-colors" id="main-scroll"');
c = c.replace(/className="h-full"/g, 'className="min-h-full"');
fs.writeFileSync('src/App.tsx', c);
