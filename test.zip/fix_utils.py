import sys

with open('src/utils.ts', 'r') as f:
    content = f.read()

import_audio = "import { playSound } from './audio';\n"
if import_audio not in content:
    content = import_audio + content

old_haptic = """export const hapticFeedback = (type: 'light' | 'medium' | 'heavy' | 'success' | 'error' = 'light') => {
  if (typeof window !== 'undefined' && window.navigator && window.navigator.vibrate) {
    try {
      switch(type) {
        case 'light': window.navigator.vibrate(10); break;
        case 'medium': window.navigator.vibrate(20); break;
        case 'heavy': window.navigator.vibrate(40); break;
        case 'success': window.navigator.vibrate([15, 50, 20]); break;
        case 'error': window.navigator.vibrate([50, 50, 50]); break;
      }
    } catch (e) {
      // ignore
    }
  }
};"""

new_haptic = """export const hapticFeedback = (type: 'light' | 'medium' | 'heavy' | 'success' | 'error' | 'celebration' = 'light') => {
  // Play sound
  if (type === 'light') playSound('tap');
  else if (type === 'medium') playSound('click');
  else if (type === 'heavy') playSound('delete');
  else if (type === 'success') playSound('success');
  else if (type === 'error') playSound('error');
  else if (type === 'celebration') playSound('celebration');

  // Play vibration
  if (typeof window !== 'undefined' && window.navigator && window.navigator.vibrate) {
    try {
      switch(type) {
        case 'light': window.navigator.vibrate(10); break;
        case 'medium': window.navigator.vibrate(20); break;
        case 'heavy': window.navigator.vibrate(40); break;
        case 'success': window.navigator.vibrate([15, 50, 20]); break;
        case 'celebration': window.navigator.vibrate([15, 50, 20, 50, 20]); break;
        case 'error': window.navigator.vibrate([50, 50, 50]); break;
      }
    } catch (e) {
      // ignore
    }
  }
};"""

if old_haptic in content:
    content = content.replace(old_haptic, new_haptic)
    with open('src/utils.ts', 'w') as f:
        f.write(content)
    print("utils.ts updated with audio feedback")
else:
    print("Could not find old hapticFeedback in utils.ts")
