import sys

with open('src/firebase.ts', 'r') as f:
    content = f.read()

target = "  console.error('Firestore Error: ', JSON.stringify(errInfo));"
replacement = """  console.error('Firestore Error: ', JSON.stringify(errInfo));
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('app-error', { detail: { code: 'FIRESTORE_ERROR', message: errInfo.error, details: JSON.stringify(errInfo) } }));
  }"""

if target in content:
    content = content.replace(target, replacement)
    with open('src/firebase.ts', 'w') as f:
        f.write(content)
    print("firebase.ts updated to dispatch app-error")
else:
    print("target not found in firebase.ts")
