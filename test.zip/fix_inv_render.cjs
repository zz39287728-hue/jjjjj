const fs = require('fs');
let c = fs.readFileSync('src/views/Inventory.tsx', 'utf8');

const newRender = `                    ) : (
                      <div className="text-right">
                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">سعر البيع</p>
                        <p className="font-semibold text-gray-900 dark:text-gray-100">{formatBHD(dev.sellPrice)}</p>
                        {dev.sellPrice && (() => {
                          const extraProfit = dev.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
                          const expenses = dev.expenses?.reduce((eSum, e) => eSum + e.amount, 0) || 0;
                          const totalProfit = dev.sellPrice - dev.buyPrice - expenses + extraProfit;
                          return (
                            <p className={\`text-xs mt-1 font-medium \${totalProfit >= 0 ? 'text-indigo-600' : 'text-red-500'}\`}>
                              {totalProfit >= 0 ? 'الربح: ' : 'الخسارة: '} 
                              {formatBHD(totalProfit)}
                            </p>
                          );
                        })()}
                      </div>
                    )}`;

c = c.replace(/                    \) : \([\s\S]*?<\/div>\n                    \)\}/, newRender);

fs.writeFileSync('src/views/Inventory.tsx', c);
