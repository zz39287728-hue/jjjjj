import sys

with open('src/views/Inventory.tsx', 'r') as f:
    content = f.read()

content = content.replace("<p>لا توجد أجهزة في هذه القائمة</p>", "<p>{t('no_devices', language)}</p>")
content = content.replace("تاريخ الشراء: {formatDate(dev.buyDate)}", "{t('buy_date', language)}: {formatDate(dev.buyDate)}")
content = content.replace("""<span className="text-xs text-gray-400 dark:text-gray-500 w-full mb-0.5">تم الشراء من:</span>""", """<span className="text-xs text-gray-400 dark:text-gray-500 w-full mb-0.5">{t('bought_from', language)}</span>""")
content = content.replace("""<ImageIcon className="w-3 h-3 me-1.5" /> عرض المحادثة""", """<ImageIcon className="w-3 h-3 me-1.5" /> {t('view_chat', language)}""")
content = content.replace("""<p className="text-xs text-gray-500 dark:text-gray-400 mb-1">سعر الشراء</p>""", """<p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('buy_cost', language)}</p>""")
content = content.replace("""بيع الجهاز""", """{t('sell_device', language)}""")
content = content.replace("""<h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">حذف الجهاز</h3>""", """<h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">{t('delete_device', language)}</h3>""")
content = content.replace("""<p className="text-gray-600 dark:text-gray-300 mb-6 text-sm">هل أنت متأكد من أنك تريد أن تحذف هذه العملية؟</p>""", """<p className="text-gray-600 dark:text-gray-300 mb-6 text-sm">{t('are_you_sure_delete', language)}</p>""")
content = content.replace("""إلغاء""", """{t('cancel', language)}""")
content = content.replace("""حذف""", """{t('delete', language)}""")
# fix up the button texts which might have been `                  حذف` 
# I will just regex replace the exact words outside of attributes if needed.
# Let's do it safer.

with open('src/views/Inventory.tsx', 'w') as f:
    f.write(content)

print("Inventory language updated.")
