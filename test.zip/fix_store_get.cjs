const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

// Inside FirebaseProvider useEffect
c = c.replace(/    const workspaceId = get\(\)\.activeWorkspaceId \|\| user\.uid;\n    const unsubDevices/g, 
  "    const workspaceId = useStore.getState().activeWorkspaceId || user.uid;\n    const unsubDevices");
  
c = c.replace(/    const workspaceId = get\(\)\.activeWorkspaceId \|\| user\.uid;\n    const unsubExpenses/g, 
  "    const unsubExpenses");

c = c.replace(/    const workspaceId = get\(\)\.activeWorkspaceId \|\| user\.uid;\n    const unsubDebts/g, 
  "    const unsubDebts");

// Fix the get().activeWorkspaceId outside Zustand actions
c = c.replace(/get\(\)\.activeWorkspaceId \|\| get\(\)\.user\?\.uid/g, "useStore.getState().activeWorkspaceId || user.uid");
c = c.replace(/userId: useStore\.getState\(\)\.activeWorkspaceId \|\| user\.uid/g, "userId: useStore.getState().activeWorkspaceId || user.uid");

fs.writeFileSync('src/store.tsx', c);
