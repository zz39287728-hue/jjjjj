const fs = require('fs');

let c = fs.readFileSync('src/components/SettingsModal.tsx', 'utf8');

if (!c.includes('PWAInstallButton')) {
  c = c.replace(/import \{ t \} from '\.\.\/i18n';/, "import { t } from '../i18n';\nimport { PWAInstallButton } from './PWAInstallButton';");
  
  const pwaSection = `
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">
              <MonitorSmartphone className="w-4 h-4" />
              {language === 'ar' ? 'التطبيق' : 'App'}
            </h3>
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-2 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col">
              <PWAInstallButton />
            </div>
          </div>
  `;
  
  c = c.replace(/          <div className="space-y-3">\n            <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2">\n              <Database className="w-4 h-4" \/>\n              \{language === 'ar' \? 'الحساب' : 'Account'\}/, pwaSection + "\n          <div className=\"space-y-3\">\n            <h3 className=\"text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider flex items-center gap-2\">\n              <Database className=\"w-4 h-4\" />\n              {language === 'ar' ? 'الحساب' : 'Account'}");

  fs.writeFileSync('src/components/SettingsModal.tsx', c);
  console.log("Updated SettingsModal");
}
