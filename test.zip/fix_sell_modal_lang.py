import sys

with open('src/components/SellModal.tsx', 'r') as f:
    content = f.read()

def r(target, rep):
    global content
    content = content.replace(target, rep)

r("alert('يرجى إدخال السعر')", "alert(t('please_enter_price', language))")
r("alert('لا يمكن أن يكون سعر البيع بالسالب')", "alert(t('price_negative', language))")
r("alert('يرجى إدخال اسم المشتري')", "alert(t('please_enter_buyer', language))")
r("alert('يجب أن يكون مجموع مبلغ الكاش وبنفت مساوياً لسعر البيع')", "alert(language === 'ar' ? 'يجب أن يكون مجموع مبلغ الكاش وبنفت مساوياً لسعر البيع' : 'The sum of Cash and Benefit must equal the Sale Price')")

r(">بيع الجهاز<", ">{t('sell_device', language)}<")
r(">الجهاز<", ">{t('device', language)}<")
r(">تكلفة الشراء<", ">{t('buy_cost', language)}<")
r(">سعر البيع (د.ب)<", ">{t('sell_price', language)}<")
r('placeholder="مثال: 180"', 'placeholder={language === "ar" ? "مثال: 180" : "e.g. 180"}')
r(">تاريخ البيع<", ">{t('sell_date', language)}<")
r(">طريقة الدفع<", ">{language === 'ar' ? 'طريقة الدفع' : 'Payment Method'}<")
r(">بنفت<", ">{language === 'ar' ? 'بنفت' : 'Benefit'}<")
r(">كاش<", ">{language === 'ar' ? 'كاش' : 'Cash'}<")
r(">مشترك<", ">{language === 'ar' ? 'مشترك' : 'Split'}<")
r(">مبلغ بنفت<", ">{language === 'ar' ? 'مبلغ بنفت' : 'Benefit Amount'}<")
r(">مبلغ الكاش<", ">{language === 'ar' ? 'مبلغ الكاش' : 'Cash Amount'}<")
r(">اسم المشتري<", ">{t('buyer_name', language)}<")
r('placeholder="مثال: محمد"', 'placeholder={language === "ar" ? "مثال: محمد" : "e.g. Mohammed"}')
r(">هاتف المشتري<", ">{t('buyer_phone', language)}<")
r('placeholder="مثال: 33334444"', 'placeholder={language === "ar" ? "مثال: 33334444" : "e.g. 33334444"}')
r(">منطقة المشتري<", ">{t('buyer_area', language)}<")
r('placeholder="مثال: المنامة"', 'placeholder={language === "ar" ? "مثال: المنامة" : "e.g. Manama"}')
r(">الإضافات المشمولة في البيع؟<", ">{t('extras_included_sale', language)}<")
r("{currentProfit >= 0 ? 'الربح المتوقع' : 'الخسارة المتوقعة'}", "{currentProfit >= 0 ? t('expected_profit', language) : t('expected_loss', language)}")
r("+ ربح إضافي (إضافات متبقية):", "{language === 'ar' ? '+ ربح إضافي (إضافات متبقية):' : '+ Extra Profit (Kept Extras):'}")
r(">تأكيد البيع<", ">{t('confirm_sale', language)}<")

with open('src/components/SellModal.tsx', 'w') as f:
    f.write(content)

print("SellModal language updated.")
