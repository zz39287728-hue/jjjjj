import sys

with open('src/i18n.ts', 'r') as f:
    content = f.read()

# I need to add debts_and_loans to en translation.
if "debts_and_loans: 'Debts and Loans'" not in content:
    content = content.replace("total_debt: 'Total Debt'", "total_debt: 'Total Debt',\n    debts_and_loans: 'Debts and Loans'")

with open('src/i18n.ts', 'w') as f:
    f.write(content)

print("Fixed i18n")
