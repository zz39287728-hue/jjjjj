const fs = require('fs');
let c = fs.readFileSync('src/views/FormsView.tsx', 'utf8');
c = c.replace(/import \{ useStore \} from '\.\.\/store';/, "import { useStore } from '../store';\nimport { Device, Expense } from '../types';");
fs.writeFileSync('src/views/FormsView.tsx', c);
