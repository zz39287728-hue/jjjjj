const fs = require('fs');
let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

const regex = /  const getExtraIcon = [\s\S]*?  return \(/;

const newCalc = `  const transactions = useMemo(() => {
    const txs: { id: string; deviceId: string; type: 'buy' | 'sell'; title: string; amount: number; date: string; profit?: number }[] = [];
    
    devices.forEach(d => {
      // Purchase transaction
      txs.push({
        id: d.id + '_buy',
        deviceId: d.id,
        type: 'buy',
        title: d.title || d.model,
        amount: d.buyPrice,
        date: d.buyDate
      });
      
      // Sale transaction
      if (d.status === 'sold' && d.sellDate && d.sellPrice) {
        const extraProfit = d.extraActions?.reduce((eSum, e) => eSum + (e.action === 'sold' ? (e.price || 0) : 0), 0) || 0;
        const baseProfit = d.sellPrice - d.buyPrice - (d.expenses?.reduce((eSum, e) => eSum + e.amount, 0) || 0);
        
        txs.push({
          id: d.id + '_sell',
          deviceId: d.id,
          type: 'sell',
          title: d.title || d.model,
          amount: d.sellPrice,
          date: d.sellDate,
          profit: baseProfit + extraProfit
        });
      }
    });
    
    // Sort by date descending
    return txs.sort((a, b) => (b.date > a.date ? 1 : -1));
  }, [devices]);

  const getExtraIcon = (name: string) => {
    const lower = name.toLowerCase();
    if (lower.includes('headset') || lower.includes('سماعة')) return <Headset className="w-4 h-4" />;
    if (lower.includes('cooler') || lower.includes('مبرد')) return <Blocks className="w-4 h-4" />;
    if (lower.includes('controller') || lower.includes('كنترولر') || lower.includes('يد')) return <Gamepad2 className="w-4 h-4" />;
    return <HardDrive className="w-4 h-4" />;
  }

  const formatDateLabel = (dateStr: string) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString(language === 'ar' ? 'ar-BH' : 'en-US', { month: 'short', day: 'numeric' });
  };

  return (`;

c = c.replace(regex, newCalc);

const uiRegex = /        <div className="p-0">\n          \{devices\.slice\(0, 5\)\.map\(dev => \([\s\S]*?          \)\}\n        <\/div>/;

const newUi = `        <div className="p-0">
          {transactions.slice(0, 10).map(tx => (
            <div key={tx.id} className="flex items-center justify-between p-4 border-b border-gray-50 dark:border-gray-800 last:border-0">
              <div>
                <p className="font-semibold text-gray-900 dark:text-gray-100">{tx.title}</p>
                <div className="flex items-center space-x-2 space-x-reverse mt-0.5">
                  <span className={\`text-xs font-medium px-1.5 py-0.5 rounded-md \${tx.type === 'sell' ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400' : 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'}\`}>
                    {tx.type === 'sell' ? t('sold', language) : t('bought', language)}
                  </span>
                  <span className="text-xs text-gray-400 dark:text-gray-500">{formatDateLabel(tx.date)}</span>
                </div>
              </div>
              <div className="text-end">
                <p className={\`font-bold \${tx.type === 'sell' ? 'text-indigo-600 dark:text-indigo-400' : 'text-blue-600 dark:text-blue-400'}\`}>
                  {tx.type === 'sell' ? '+' + formatBHD(tx.amount) : '-' + formatBHD(tx.amount)}
                </p>
                {tx.type === 'sell' && tx.profit !== undefined && (
                  <p className={\`text-xs mt-0.5 \${tx.profit >= 0 ? 'text-emerald-500' : 'text-red-500'}\`}>
                    {tx.profit >= 0 ? t('profit', language) : 'خسارة:'} {formatBHD(tx.profit)}
                  </p>
                )}
              </div>
            </div>
          ))}
          {transactions.length === 0 && (
            <div className="p-8 text-center text-gray-400 dark:text-gray-500 text-sm">
              {t('no_recent', language)}
            </div>
          )}
        </div>`;

c = c.replace(uiRegex, newUi);

fs.writeFileSync('src/views/Dashboard.tsx', c);
