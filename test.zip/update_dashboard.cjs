const fs = require('fs');
let c = fs.readFileSync('src/views/Dashboard.tsx', 'utf8');

if (!c.includes('timeFilter')) {
  // Add state
  c = c.replace(/export default function Dashboard\(\) \{/, 
    "export default function Dashboard() {\n  const [timeFilter, setTimeFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');");

  // Add filteredTransactions useMemo before chartData
  const filteredTxMemo = `  const filteredTransactions = useMemo(() => {
    const now = new Date();
    // Offset for local timezone to get accurate YYYY-MM-DD
    const offset = now.getTimezoneOffset() * 60000;
    const localNow = new Date(now.getTime() - offset);
    const todayStr = localNow.toISOString().split('T')[0];
    
    // start of week (sunday)
    const startOfWeek = new Date(localNow);
    startOfWeek.setDate(localNow.getDate() - localNow.getDay());
    const startOfWeekStr = startOfWeek.toISOString().split('T')[0];

    const currentMonthStr = localNow.toISOString().slice(0, 7); // YYYY-MM

    return transactions.filter(tx => {
      if (timeFilter === 'all') return true;
      if (timeFilter === 'today') return tx.date === todayStr;
      if (timeFilter === 'month') return tx.date.startsWith(currentMonthStr);
      if (timeFilter === 'week') {
        return tx.date >= startOfWeekStr && tx.date <= todayStr;
      }
      return true;
    });
  }, [transactions, timeFilter]);

  const chartData = useMemo(() => {`;
  c = c.replace(/  const chartData = useMemo\(\(\) => \{/, filteredTxMemo);

  // Replace Header & map
  const oldHeader = `<div className="p-5 sm:p-6 border-b border-gray-100 dark:border-gray-700">
          <h3 className="font-bold text-gray-800 dark:text-gray-200">{t('recent_transactions', language)}</h3>
        </div>
        <div className="p-2 sm:p-4">
          {transactions.slice(0, 10).map(tx => (`;

  const newHeader = `<div className="p-5 sm:p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center flex-wrap gap-3">
          <h3 className="font-bold text-gray-800 dark:text-gray-200">{t('recent_transactions', language)}</h3>
          <div className="flex bg-gray-100 dark:bg-gray-800/50 p-1 rounded-xl">
            <button onClick={() => setTimeFilter('all')} className={\`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors \${timeFilter === 'all' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}\`}>
              {language === 'ar' ? 'الكل' : 'All'}
            </button>
            <button onClick={() => setTimeFilter('today')} className={\`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors \${timeFilter === 'today' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}\`}>
              {language === 'ar' ? 'اليوم' : 'Today'}
            </button>
            <button onClick={() => setTimeFilter('week')} className={\`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors \${timeFilter === 'week' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}\`}>
              {language === 'ar' ? 'الأسبوع' : 'Week'}
            </button>
            <button onClick={() => setTimeFilter('month')} className={\`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors \${timeFilter === 'month' ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'}\`}>
              {language === 'ar' ? 'الشهر' : 'Month'}
            </button>
          </div>
        </div>
        <div className="p-2 sm:p-4">
          {filteredTransactions.slice(0, 10).map(tx => (`;

  c = c.replace(oldHeader, newHeader);

  // Replace empty state condition
  c = c.replace(/\{transactions.length === 0 && \(/, '{filteredTransactions.length === 0 && (');

  fs.writeFileSync('src/views/Dashboard.tsx', c);
  console.log("Updated Dashboard");
}
