const fs = require('fs');
let c = fs.readFileSync('src/components/DeviceDetailsModal.tsx', 'utf8');

const keptExtrasLogic = `                  </div>
                </div>
              )}

              {isSold && currentExtrasList.filter(e => !soldExtras.includes(e)).length > 0 && (
                <div className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm space-y-3 mt-3">
                  <h3 className="font-bold text-gray-900 dark:text-gray-100 border-b border-gray-100 dark:border-gray-800 pb-2 mb-3">{t('manage_extras', language)}</h3>
                  <div className="space-y-4">
                    {currentExtrasList.filter(e => !soldExtras.includes(e)).map((extra, idx) => {
                      const actionObj = extraActions.find(a => a.extraName === extra) || { extraName: extra, action: 'pending' };
                      return (
                        <div key={idx} className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-gray-100 dark:border-gray-700">
                          <div className="font-bold text-gray-800 dark:text-gray-200 text-sm mb-2">{translateExtra(extra)}</div>
                          <div className="flex gap-2 mb-2">
                            <select
                              value={actionObj.action}
                              onChange={(e) => {
                                const newAction = e.target.value as any;
                                const filtered = extraActions.filter(a => a.extraName !== extra);
                                setExtraActions([...filtered, { ...actionObj, action: newAction }]);
                              }}
                              className="flex-1 p-2 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                            >
                              <option value="pending">{t('action_pending', language)}</option>
                              <option value="sold">{t('action_sold', language)}</option>
                              <option value="gifted">{t('action_gifted', language)}</option>
                              <option value="kept_personal">{t('action_kept', language)}</option>
                            </select>
                            
                            {actionObj.action === 'sold' && (
                              <input
                                type="number"
                                placeholder={t('extra_sale_price', language)}
                                value={actionObj.price || ''}
                                onChange={(e) => {
                                  const val = parseFloat(e.target.value) || 0;
                                  const filtered = extraActions.filter(a => a.extraName !== extra);
                                  setExtraActions([...filtered, { ...actionObj, price: val }]);
                                }}
                                className="w-24 p-2 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                              />
                            )}
                          </div>
                          {(actionObj.action === 'gifted' || actionObj.action === 'kept_personal') && (
                            <input
                              type="text"
                              placeholder={t('extra_notes', language)}
                              value={actionObj.notes || ''}
                              onChange={(e) => {
                                const filtered = extraActions.filter(a => a.extraName !== extra);
                                setExtraActions([...filtered, { ...actionObj, notes: e.target.value }]);
                              }}
                              className="w-full p-2 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>`;

c = c.replace(/                  <\/div>\n                <\/div>\n              \)}\n            <\/div>/, keptExtrasLogic);

fs.writeFileSync('src/components/DeviceDetailsModal.tsx', c);
