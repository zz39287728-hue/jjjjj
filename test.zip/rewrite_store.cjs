const fs = require('fs');

const fileContent = `import React, { createContext, useContext, useState, useEffect } from 'react';
import { Device, GeneralExpense, GeneralDebt } from './types';
import { Language } from './i18n';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, User } from 'firebase/auth';
import { collection, query, where, onSnapshot, doc, setDoc, updateDoc, deleteDoc, writeBatch } from 'firebase/firestore';

export type Theme = 'light' | 'dark';

interface StoreContextType {
  devices: Device[];
  generalExpenses: GeneralExpense[];
  generalDebts: GeneralDebt[];
  language: Language;
  theme: Theme;
  user: User | null;
  authLoading: boolean;
  signIn: () => Promise<void>;
  logOut: () => Promise<void>;
  setLanguage: (lang: Language) => void;
  setTheme: (theme: Theme) => void;
  importDevices: (devices: Device[]) => void;
  addDevice: (d: Omit<Device, 'id' | 'status'>) => Promise<void>;
  updateDevice: (id: string, updates: Partial<Device>) => Promise<void>;
  sellDevice: (id: string, sellPrice: number, sellDate: string, buyerName?: string, buyerPhone?: string, buyerArea?: string, soldExtras?: string[]) => Promise<void>;
  deleteDevice: (id: string) => Promise<void>;
  addGeneralExpense: (expense: Omit<GeneralExpense, 'id'>) => Promise<void>;
  updateGeneralExpense: (id: string, updates: Partial<GeneralExpense>) => Promise<void>;
  deleteGeneralExpense: (id: string) => Promise<void>;
  addGeneralDebt: (debt: Omit<GeneralDebt, 'id'>) => Promise<void>;
  updateGeneralDebt: (id: string, updates: Partial<GeneralDebt>) => Promise<void>;
  deleteGeneralDebt: (id: string) => Promise<void>;
}

const StoreContext = createContext<StoreContextType | null>(null);

export const StoreProvider = ({ children }: { children: React.ReactNode }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      return (localStorage.getItem('ps_lang') as Language) || 'ar';
    } catch {
      return 'ar';
    }
  });

  const [theme, setThemeState] = useState<Theme>(() => {
    try {
      return (localStorage.getItem('ps_theme') as Theme) || 'light';
    } catch {
      return 'light';
    }
  });

  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  
  const [devices, setDevices] = useState<Device[]>([]);
  const [generalExpenses, setGeneralExpenses] = useState<GeneralExpense[]>([]);
  const [generalDebts, setGeneralDebts] = useState<GeneralDebt[]>([]);

  useEffect(() => {
    localStorage.setItem('ps_lang', language);
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    localStorage.setItem('ps_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const setLanguage = (lang: Language) => setLanguageState(lang);
  const setTheme = (t: Theme) => setThemeState(t);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) {
      setDevices([]);
      setGeneralExpenses([]);
      setGeneralDebts([]);
      return;
    }

    const unsubDevices = onSnapshot(query(collection(db, 'devices'), where('userId', '==', user.uid)), (snapshot) => {
      const devs = snapshot.docs.map(doc => doc.data() as Device);
      setDevices(devs.sort((a, b) => (b.buyDate > a.buyDate ? 1 : -1)));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'devices'));

    const unsubExpenses = onSnapshot(query(collection(db, 'generalExpenses'), where('userId', '==', user.uid)), (snapshot) => {
      const exps = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as GeneralExpense);
      setGeneralExpenses(exps.sort((a, b) => (b.date > a.date ? 1 : -1)));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'generalExpenses'));

    const unsubDebts = onSnapshot(query(collection(db, 'generalDebts'), where('userId', '==', user.uid)), (snapshot) => {
      const debts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as GeneralDebt);
      setGeneralDebts(debts.sort((a, b) => (b.date > a.date ? 1 : -1)));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'generalDebts'));

    return () => {
      unsubDevices();
      unsubExpenses();
      unsubDebts();
    };
  }, [user]);

  const signIn = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      
      const localDevices = JSON.parse(localStorage.getItem('ps_devices') || '[]');
      if (localDevices.length > 0 && auth.currentUser) {
        const batch = writeBatch(db);
        localDevices.forEach((dev: any) => {
          const newDoc = doc(collection(db, 'devices'));
          const deviceToSave: Device = {
            ...dev,
            id: newDoc.id,
            userId: auth.currentUser!.uid,
            createdAt: Date.now(),
            updatedAt: Date.now()
          };
          batch.set(newDoc, deviceToSave);
        });
        await batch.commit();
        localStorage.removeItem('ps_devices');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const logOut = async () => {
    await signOut(auth);
  };

  const importDevices = async (newDevices: Device[]) => {
    if (!user) return;
    try {
      const batch = writeBatch(db);
      newDevices.forEach(d => {
        const newDoc = doc(collection(db, 'devices'));
        batch.set(newDoc, { ...d, id: newDoc.id, userId: user.uid, createdAt: Date.now(), updatedAt: Date.now() });
      });
      await batch.commit();
    } catch(e) {
      handleFirestoreError(e, OperationType.WRITE, 'devices');
    }
  };

  const addDevice = async (d: Omit<Device, 'id' | 'status'>) => {
    if (!user) return;
    try {
      const newDoc = doc(collection(db, 'devices'));
      const deviceToSave = {
        ...d,
        id: newDoc.id,
        userId: user.uid,
        status: 'in_stock',
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      await setDoc(newDoc, deviceToSave);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'devices');
    }
  };

  const updateDevice = async (id: string, updates: Partial<Device>) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'devices', id), { ...updates, updatedAt: Date.now() });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'devices/' + id);
    }
  };

  const sellDevice = async (id: string, sellPrice: number, sellDate: string, buyerName?: string, buyerPhone?: string, buyerArea?: string, soldExtras?: string[]) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'devices', id), {
        sellPrice,
        sellDate,
        status: 'sold',
        buyerName: buyerName || null,
        buyerPhone: buyerPhone || null,
        buyerArea: buyerArea || null,
        soldExtras: soldExtras || [],
        updatedAt: Date.now()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'devices/' + id);
    }
  };

  const deleteDevice = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'devices', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'devices/' + id);
    }
  };

  const addGeneralExpense = async (expense: Omit<GeneralExpense, 'id'>) => {
    if (!user) return;
    try {
      const newDoc = doc(collection(db, 'generalExpenses'));
      await setDoc(newDoc, { ...expense, id: newDoc.id, userId: user.uid, createdAt: Date.now(), updatedAt: Date.now() });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'generalExpenses');
    }
  };

  const updateGeneralExpense = async (id: string, updates: Partial<GeneralExpense>) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'generalExpenses', id), { ...updates, updatedAt: Date.now() });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'generalExpenses/' + id);
    }
  };

  const deleteGeneralExpense = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'generalExpenses', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'generalExpenses/' + id);
    }
  };

  const addGeneralDebt = async (debt: Omit<GeneralDebt, 'id'>) => {
    if (!user) return;
    try {
      const newDoc = doc(collection(db, 'generalDebts'));
      await setDoc(newDoc, { ...debt, id: newDoc.id, userId: user.uid, createdAt: Date.now(), updatedAt: Date.now() });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'generalDebts');
    }
  };

  const updateGeneralDebt = async (id: string, updates: Partial<GeneralDebt>) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'generalDebts', id), { ...updates, updatedAt: Date.now() });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'generalDebts/' + id);
    }
  };

  const deleteGeneralDebt = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'generalDebts', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'generalDebts/' + id);
    }
  };

  return (
    <StoreContext.Provider value={{
      devices, generalExpenses, generalDebts, language, theme, user, authLoading,
      signIn, logOut, setLanguage, setTheme, importDevices,
      addDevice, updateDevice, sellDevice, deleteDevice,
      addGeneralExpense, updateGeneralExpense, deleteGeneralExpense,
      addGeneralDebt, updateGeneralDebt, deleteGeneralDebt
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within a StoreProvider");
  return ctx;
};
`;

fs.writeFileSync('src/store.tsx', fileContent);
