const fs = require('fs');
let c = fs.readFileSync('src/components/SettingsModal.tsx', 'utf8');

c = c.replace(/const \{ language, setLanguage, theme, setTheme, devices, importDevices, activeWorkspaceId, generateInviteCode, joinWorkspace, clearWorkspace, user \} = useStore\(\);/,
  "const { language, setLanguage, theme, setTheme, devices, importDevices, activeWorkspaceId, generateInviteCode, joinWorkspace, clearWorkspace } = useStore();");

fs.writeFileSync('src/components/SettingsModal.tsx', c);
