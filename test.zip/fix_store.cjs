const fs = require('fs');
let c = fs.readFileSync('src/store.tsx', 'utf8');

c = c.replace(/    try \{\n        const \[activeWorkspaceId, setActiveWorkspaceId\] = useState<string>\(''\);\n    \n  const generateInviteCode = async \(\) => \{\n    return Math\.random\(\)\.toString\(36\)\.substring\(2, 8\)\.toUpperCase\(\);\n  \};\n\n  const joinWorkspace = async \(workspaceId: string, inviteCode: string\) => \{\n    alert\("Not fully implemented yet"\);\n    return false;\n  \};\n\n  const clearWorkspace = \(\) => \{\n    setActiveWorkspaceId\(''\);\n  \};\n\n  return \(/, "    try {\n      return (");

const missingProps = `
  const [activeWorkspaceId, setActiveWorkspaceId] = useState<string>('');
  
  const generateInviteCode = async () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const joinWorkspace = async (workspaceId: string, inviteCode: string) => {
    alert("Not fully implemented yet");
    return false;
  };

  const clearWorkspace = () => {
    setActiveWorkspaceId('');
  };

  return (
    <StoreContext.Provider`;

c = c.replace(/  return \(\n    <StoreContext\.Provider/, missingProps);

fs.writeFileSync('src/store.tsx', c);
